export type JobStatus = 
  | 'QUEUED' 
  | 'ROUTING' 
  | 'PREPROCESSING' 
  | 'INFERENCING' 
  | 'COMPLETED' 
  | 'RETRYING' 
  | 'FAILED' 
  | 'TIMED_OUT';

export type Priority = 'CRITICAL' | 'HIGH' | 'DEFAULT' | 'BATCH';

export type ModelId = 
  | 'whisper-tiny'
  | 'whisper-base'
  | 'whisper-small'
  | 'whisper-medium'
  | 'whisper-large-v3'
  | 'distil-whisper-v3';

export type ServingEngine = 
  | 'pytorch-eager'
  | 'faster-whisper'
  | 'tensorrt-llm'
  | 'onnx-runtime';

export type Quantization = 'fp32' | 'fp16' | 'int8' | 'int4';

export interface WordTimestamp {
  word: string;
  start: number;
  end: number;
  confidence: number;
  speaker?: string;
}

export interface SegmentTranscript {
  id: number;
  seek: number;
  start: number;
  end: number;
  text: string;
  tokens: number[];
  temperature: number;
  avgLogprob: number;
  compressionRatio: number;
  noSpeechProb: number;
  speaker?: string;
  words?: WordTimestamp[];
}

export interface InferenceJob {
  id: string;
  audioName: string;
  audioDurationSec: number;
  model: ModelId;
  engine: ServingEngine;
  quantization: Quantization;
  priority: Priority;
  beamSize: number;
  temperature: number;
  vadFilter: boolean;
  diarization: boolean;
  status: JobStatus;
  progressPercent: number;
  workerId?: string;
  createdAt: number;
  startedAt?: number;
  completedAt?: number;
  queueWaitMs?: number;
  inferenceDurationMs?: number;
  retryCount: number;
  maxRetries: number;
  timeoutMs: number;
  error?: string;
  result?: {
    text: string;
    segments: SegmentTranscript[];
    words: WordTimestamp[];
    language: string;
    rtf: number;
    tokensCount: number;
    vramPeakMb: number;
  };
}

export interface WorkerInstance {
  id: string;
  name: string;
  device: string; // 'NVIDIA A100-80GB' | 'NVIDIA T4-16GB' | 'AMD EPYC CPU'
  vramTotalMb: number;
  vramUsedMb: number;
  computeLoadPercent: number;
  status: 'IDLE' | 'BUSY' | 'WARMING_CACHE' | 'OOM_RECOVERY' | 'OFFLINE';
  activeJobId?: string;
  loadedModel?: ModelId;
  totalJobsProcessed: number;
  failedJobs: number;
  uptimeSec: number;
  recentLatenciesMs: number[];
  isThrottled?: boolean;
}

export interface StructuredLog {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  service: string;
  worker_id?: string;
  job_id?: string;
  message: string;
  metadata?: Record<string, any>;
}

export interface AlignmentWord {
  type: 'match' | 'substitution' | 'deletion' | 'insertion';
  refWord?: string;
  hypWord?: string;
}

export interface WerResult {
  substitutions: number;
  deletions: number;
  insertions: number;
  hits: number;
  refWordCount: number;
  hypWordCount: number;
  wer: number; // percentage 0 - 100
  cer: number; // percentage 0 - 100
  ser: number; // sentence error rate 0 or 100
  alignments: AlignmentWord[];
}

export interface BenchmarkRun {
  id: string;
  timestamp: number;
  concurrency: number;
  requestsCount: number;
  model: ModelId;
  engine: ServingEngine;
  quantization: Quantization;
  p50Ms: number;
  p90Ms: number;
  p95Ms: number;
  p99Ms: number;
  minMs: number;
  maxMs: number;
  meanRtf: number;
  throughputRps: number;
  audioMinutesPerMinute: number;
  avgGpuLoad: number;
  avgVramMb: number;
  successRate: number;
  slaBreachedCount: number;
  slaTargetMs: number;
}

export type AutoscalingMetric = 'QUEUE_DEPTH' | 'GPU_LOAD_PERCENT';

export interface AutoscalingConfig {
  enabled: boolean;
  metric: AutoscalingMetric;
  scaleUpThreshold: number; // e.g. 15 or 50
  scaleUpDurationSec: number; // e.g. 5 or 30s
  scaleUpStep: number; // e.g. 1 or 2
  scaleUpCooldownSec: number; // e.g. 10s
  scaleDownThreshold: number; // e.g. 2 jobs or 25% load
  scaleDownDurationSec: number; // e.g. 10s
  scaleDownStep: number; // e.g. 1
  scaleDownCooldownSec: number; // e.g. 15s
  minWorkers: number;
  maxWorkers: number;
}

export interface AutoscalerState {
  currentStage: 'MONITORING' | 'EVALUATING_SCALE_UP' | 'EVALUATING_SCALE_DOWN' | 'COOLDOWN' | 'MAX_REACHED' | 'MIN_REACHED';
  conditionSustainedStartMs: number | null;
  lastScaleActionMs: number | null;
  lastAction: 'SCALE_UP' | 'SCALE_DOWN' | 'NONE';
  lastActionReason: string;
  secondsSustained: number;
}

export interface QueueHistoryPoint {
  time: string;
  timestamp: number;
  queueDepth: number;
  activeWorkers: number;
  scaleUpThreshold: number;
  scaleDownThreshold: number;
  event?: string;
}


