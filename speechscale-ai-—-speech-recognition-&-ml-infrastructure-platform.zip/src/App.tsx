import React, { useState, useEffect, useRef } from 'react';
import { Header, TabType } from './components/Header';
import { InferencePlayground } from './components/InferencePlayground';
import { WorkerOrchestrator } from './components/WorkerOrchestrator';
import { BenchmarkingSuite } from './components/BenchmarkingSuite';
import { WerEvaluation } from './components/WerEvaluation';
import { ErrorBreakdown } from './components/ErrorBreakdown';
import { InferenceJob, WorkerInstance, StructuredLog, BenchmarkRun, Priority, AutoscalingConfig, AutoscalerState, QueueHistoryPoint, ModelId } from './types';
import { SAMPLE_AUDIOS } from './data/sampleAudios';
import { calculateBackoffMs, isJobTimedOut, matchWorkerForJob, sortQueueJobs } from './utils/queueEngine';
import { simulateBenchmarkRun } from './utils/benchmarks';
import { evaluateAutoscaler, DEFAULT_AUTOSCALING_CONFIG, INITIAL_AUTOSCALER_STATE } from './utils/autoscaler';
import { addWorkerJobLatency } from './utils/workerHealth';
import { ErrorCategory } from './utils/errorBreakdown';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('inference');

  // Initial Worker Pool
  const [workers, setWorkers] = useState<WorkerInstance[]>([
    {
      id: 'worker-01',
      name: 'worker-01 (GPU-0)',
      device: 'NVIDIA A100-SXM4-80GB',
      vramTotalMb: 81920,
      vramUsedMb: 14800,
      computeLoadPercent: 42,
      status: 'IDLE',
      loadedModel: 'whisper-large-v3',
      totalJobsProcessed: 142,
      failedJobs: 0,
      uptimeSec: 36400,
      recentLatenciesMs: [240, 250, 245, 260, 255, 270, 265, 250, 245, 250],
      isThrottled: false,
    },
    {
      id: 'worker-02',
      name: 'worker-02 (GPU-1)',
      device: 'NVIDIA A100-SXM4-80GB',
      vramTotalMb: 81920,
      vramUsedMb: 12400,
      computeLoadPercent: 35,
      status: 'IDLE',
      loadedModel: 'distil-whisper-v3',
      totalJobsProcessed: 189,
      failedJobs: 0,
      uptimeSec: 36400,
      recentLatenciesMs: [180, 190, 185, 200, 195, 210, 205, 190, 185, 195],
      isThrottled: false,
    },
    {
      id: 'worker-03',
      name: 'worker-03 (GPU-2)',
      device: 'NVIDIA T4-TensorCore-16GB',
      vramTotalMb: 16384,
      vramUsedMb: 4200,
      computeLoadPercent: 28,
      status: 'IDLE',
      loadedModel: 'whisper-medium',
      totalJobsProcessed: 98,
      failedJobs: 1,
      uptimeSec: 18200,
      recentLatenciesMs: [460, 490, 520, 510, 480, 540, 530, 500, 490, 510],
      isThrottled: false,
    },
    {
      id: 'worker-04',
      name: 'worker-04 (CPU-Fallback)',
      device: 'AMD EPYC 7R13 (16 vCPU)',
      vramTotalMb: 32768,
      vramUsedMb: 1800,
      computeLoadPercent: 14,
      status: 'IDLE',
      loadedModel: 'whisper-tiny',
      totalJobsProcessed: 64,
      failedJobs: 0,
      uptimeSec: 42100,
      recentLatenciesMs: [720, 750, 780, 810, 840, 830, 790, 820, 860, 850],
      isThrottled: true,
    },
  ]);

  // Initial Jobs List
  const [jobs, setJobs] = useState<InferenceJob[]>([
    {
      id: 'job-init-1',
      audioName: SAMPLE_AUDIOS[0].title,
      audioDurationSec: SAMPLE_AUDIOS[0].durationSec,
      model: 'whisper-large-v3',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'HIGH',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: true,
      status: 'COMPLETED',
      progressPercent: 100,
      workerId: 'worker-01',
      createdAt: Date.now() - 45000,
      startedAt: Date.now() - 44000,
      completedAt: Date.now() - 43150,
      queueWaitMs: 142,
      inferenceDurationMs: 850,
      retryCount: 0,
      maxRetries: 3,
      timeoutMs: 12000,
      result: {
        text: SAMPLE_AUDIOS[0].referenceText,
        segments: SAMPLE_AUDIOS[0].segments,
        words: SAMPLE_AUDIOS[0].words,
        language: 'en',
        rtf: 0.054,
        tokensCount: 38,
        vramPeakMb: 4850,
      },
    },
    {
      id: 'job-err-timeout-1',
      audioName: 'Courtroom Multi-Speaker Deposition (540s)',
      audioDurationSec: 540,
      model: 'whisper-large-v3',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'HIGH',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: true,
      status: 'TIMED_OUT',
      progressPercent: 68,
      workerId: 'worker-04',
      createdAt: Date.now() - 180000,
      startedAt: Date.now() - 168000,
      queueWaitMs: 320,
      retryCount: 1,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'Request execution exceeded 12.0s SLA timeout deadline (wall-clock elapsed: 12042ms)',
    },
  ]);

  const [activeJobId, setActiveJobId] = useState<string>('job-init-1');
  const [dlqJobs, setDlqJobs] = useState<InferenceJob[]>([
    {
      id: 'dlq-oom-101',
      audioName: 'Radiology Dictation Session (35m Longform)',
      audioDurationSec: 2100,
      model: 'whisper-large-v3',
      engine: 'pytorch-eager',
      quantization: 'fp16',
      priority: 'CRITICAL',
      beamSize: 5,
      temperature: 0.0,
      vadFilter: false,
      diarization: true,
      status: 'FAILED',
      progressPercent: 41,
      workerId: 'worker-03',
      createdAt: Date.now() - 360000,
      startedAt: Date.now() - 355000,
      completedAt: Date.now() - 340000,
      queueWaitMs: 210,
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'CUDA out of memory. Tried to allocate 3.40 GiB (GPU 2; 15.78 GiB total capacity; 13.92 GiB already allocated; 1.22 GiB free; 14.10 GiB reserved)',
    },
    {
      id: 'dlq-decode-102',
      audioName: 'Damaged Customer Call IVR.wav',
      audioDurationSec: 42,
      model: 'whisper-medium',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'DEFAULT',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: false,
      status: 'FAILED',
      progressPercent: 12,
      workerId: 'worker-02',
      createdAt: Date.now() - 240000,
      startedAt: Date.now() - 238000,
      completedAt: Date.now() - 237500,
      queueWaitMs: 120,
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'Invalid audio header: RIFF chunk length exceeds EOF, ffmpeg returned code 183 (corrupted payload)',
    },
    {
      id: 'dlq-api-103',
      audioName: 'Quarterly Earnings Call Segment 4',
      audioDurationSec: 180,
      model: 'whisper-large-v3',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'HIGH',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: false,
      status: 'FAILED',
      progressPercent: 28,
      workerId: 'worker-01',
      createdAt: Date.now() - 190000,
      startedAt: Date.now() - 188000,
      completedAt: Date.now() - 186000,
      queueWaitMs: 155,
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'HTTP 502 Bad Gateway: Upstream inference proxy connection reset by peer during CTranslate2 forward pass',
    },
    {
      id: 'dlq-rate-104',
      audioName: 'Live Translation Podcast Stream #12',
      audioDurationSec: 320,
      model: 'distil-whisper-v3',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'BATCH',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: false,
      status: 'FAILED',
      progressPercent: 5,
      workerId: 'worker-02',
      createdAt: Date.now() - 95000,
      startedAt: Date.now() - 94000,
      completedAt: Date.now() - 93500,
      queueWaitMs: 410,
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'HTTP 429 Too Many Requests: Rate limit exceeded on HuggingFace Hub model weights shard download token bucket',
    },
  ]);

  // Logs stream
  const [logs, setLogs] = useState<StructuredLog[]>([
    {
      id: 'log-1',
      timestamp: new Date(Date.now() - 45000).toISOString().split('T')[1].replace('Z', ''),
      level: 'INFO',
      service: 'speechscale.gateway',
      message: 'Ingested audio payload for job-init-1 via multipart/form-data. XADD to stream:audio_tasks:high',
      metadata: { priority: 'HIGH', duration: 15.6 },
    },
    {
      id: 'log-2',
      timestamp: new Date(Date.now() - 44000).toISOString().split('T')[1].replace('Z', ''),
      level: 'INFO',
      service: 'speechscale.worker',
      worker_id: 'worker-01',
      job_id: 'job-init-1',
      message: 'XREADGROUP claimed job-init-1. Preprocessing Silero-VAD 16kHz audio stream.',
      metadata: { vram_free_mb: 67120 },
    },
    {
      id: 'log-3',
      timestamp: new Date(Date.now() - 43150).toISOString().split('T')[1].replace('Z', ''),
      level: 'INFO',
      service: 'speechscale.worker',
      worker_id: 'worker-01',
      job_id: 'job-init-1',
      message: 'Inference completed in 850ms. RTF: 0.054x. Aligned 25 word tokens. XACK committed.',
      metadata: { tokens: 38, rtf: 0.054 },
    },
  ]);

  // Initial Benchmark History
  const [benchmarkHistory, setBenchmarkHistory] = useState<BenchmarkRun[]>([
    simulateBenchmarkRun(20, 100, 'whisper-large-v3', 'faster-whisper', 'int8', 800),
    simulateBenchmarkRun(20, 100, 'distil-whisper-v3', 'faster-whisper', 'int8', 800),
    simulateBenchmarkRun(50, 100, 'whisper-large-v3', 'pytorch-eager', 'fp16', 800),
  ]);

  // Horizontal Pod Autoscaler (HPA) State
  const [autoscalingConfig, setAutoscalingConfig] = useState<AutoscalingConfig>(DEFAULT_AUTOSCALING_CONFIG);
  const [autoscalerState, setAutoscalerState] = useState<AutoscalerState>(INITIAL_AUTOSCALER_STATE);

  // Real-time Queue Depth & Worker Capacity Time-Series (for Recharts)
  const [queueHistory, setQueueHistory] = useState<QueueHistoryPoint[]>(() => {
    const points: QueueHistoryPoint[] = [];
    const now = Date.now();
    for (let i = 20; i >= 0; i--) {
      const t = new Date(now - i * 1500).toLocaleTimeString();
      points.push({
        time: t,
        timestamp: now - i * 1500,
        queueDepth: Math.max(0, Math.round(1 + Math.sin(i * 0.4) * 2)),
        activeWorkers: 4,
        scaleUpThreshold: 10,
        scaleDownThreshold: 1,
      });
    }
    return points;
  });

  const autoscalingConfigRef = useRef(autoscalingConfig);
  autoscalingConfigRef.current = autoscalingConfig;

  const autoscalerStateRef = useRef(autoscalerState);
  autoscalerStateRef.current = autoscalerState;

  const workersRef = useRef(workers);
  workersRef.current = workers;

  const jobsRef = useRef(jobs);
  jobsRef.current = jobs;

  // Autoscaler Evaluation & State Machine Loop (1s persistent timer)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      const currentJobs = jobsRef.current;
      const currentWorkers = workersRef.current;
      const config = autoscalingConfigRef.current;
      const state = autoscalerStateRef.current;

      const currentQueueLength = currentJobs.filter((j) => j.status === 'QUEUED' || j.status === 'RETRYING').length;
      const totalCompute = currentWorkers.reduce((acc, w) => acc + w.computeLoadPercent, 0);
      const avgGpu = Math.round(totalCompute / Math.max(1, currentWorkers.length));

      const evaluation = evaluateAutoscaler(
        currentWorkers.length,
        currentQueueLength,
        avgGpu,
        config,
        state,
        now
      );

      autoscalerStateRef.current = evaluation.updatedState;
      setAutoscalerState(evaluation.updatedState);

      if (evaluation.action === 'SCALE_UP' && evaluation.targetWorkerDelta > 0) {
        const delta = evaluation.targetWorkerDelta;
        setWorkers((prev) => {
          const currentCount = prev.length;
          const newWorkers: WorkerInstance[] = [];
          for (let i = 0; i < delta; i++) {
            const idx = currentCount + i + 1;
            newWorkers.push({
              id: `worker-0${idx}`,
              name: `worker-0${idx} (GPU-${idx - 1})`,
              device: 'NVIDIA A100-SXM4-80GB',
              vramTotalMb: 81920,
              vramUsedMb: 11800,
              computeLoadPercent: 20,
              status: 'IDLE',
              loadedModel: 'whisper-large-v3',
              totalJobsProcessed: 0,
              failedJobs: 0,
              uptimeSec: 1,
              recentLatenciesMs: [230, 245, 240, 250, 235, 240, 255, 245, 230, 240],
              isThrottled: false,
            });
          }
          return [...prev, ...newWorkers];
        });

        addLog(
          'WARN',
          'speechscale.autoscaler',
          `[HPA Auto-Scale UP] ${evaluation.reason}`,
          undefined,
          undefined,
          {
            delta,
            metric: config.metric,
            previous_workers: currentWorkers.length,
            new_worker_count: currentWorkers.length + delta,
          }
        );
      } else if (evaluation.action === 'SCALE_DOWN' && evaluation.targetWorkerDelta < 0) {
        const drainCount = Math.abs(evaluation.targetWorkerDelta);
        setWorkers((prev) => {
          if (prev.length <= config.minWorkers) return prev;
          const toKeep = prev.slice(0, Math.max(config.minWorkers, prev.length - drainCount));
          return toKeep;
        });

        addLog(
          'INFO',
          'speechscale.autoscaler',
          `[HPA Auto-Scale DOWN] ${evaluation.reason}`,
          undefined,
          undefined,
          {
            drained_count: drainCount,
            new_worker_count: Math.max(config.minWorkers, currentWorkers.length - drainCount),
          }
        );
      }

      // Record time series point for Recharts Queue Depth vs Time
      const timeLabel = new Date(now).toLocaleTimeString();
      setQueueHistory((prev) => {
        const newPoint: QueueHistoryPoint = {
          time: timeLabel,
          timestamp: now,
          queueDepth: currentQueueLength,
          activeWorkers: currentWorkers.length,
          scaleUpThreshold: config.scaleUpThreshold,
          scaleDownThreshold: config.scaleDownThreshold,
        };
        return [...prev.slice(-29), newPoint];
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const addLog = (level: 'INFO' | 'WARN' | 'ERROR', service: string, message: string, worker_id?: string, job_id?: string, metadata?: any) => {
    const newLog: StructuredLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      timestamp: new Date().toISOString().split('T')[1].replace('Z', ''),
      level,
      service,
      worker_id,
      job_id,
      message,
      metadata,
    };
    setLogs((prev) => [newLog, ...prev.slice(0, 199)]);
  };

  // Submit Job Function
  const submitJob = (jobConfig: Omit<InferenceJob, 'id' | 'status' | 'progressPercent' | 'createdAt' | 'retryCount'>) => {
    const newId = `job-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newJob: InferenceJob = {
      ...jobConfig,
      id: newId,
      status: 'QUEUED',
      progressPercent: 0,
      createdAt: Date.now(),
      retryCount: 0,
    };

    setJobs((prev) => [newJob, ...prev]);
    setActiveJobId(newId);

    addLog(
      'INFO',
      'speechscale.gateway',
      `Enqueued inference task into stream:audio_tasks:${newJob.priority.toLowerCase()}`,
      undefined,
      newId,
      { model: newJob.model, duration: newJob.audioDurationSec }
    );
  };

  // Job Scheduler & State Machine Loop
  useEffect(() => {
    const interval = setInterval(() => {
      setJobs((prevJobs) => {
        // Find queued or retrying jobs
        const queuedList = sortQueueJobs(prevJobs.filter((j) => j.status === 'QUEUED' || j.status === 'RETRYING'));
        if (queuedList.length === 0) return prevJobs;

        const nextJob = queuedList[0];

        // Match worker
        let matchedWorkerId: string | undefined;
        setWorkers((prevWorkers) => {
          const matched = matchWorkerForJob(prevWorkers, nextJob);
          if (matched) {
            matchedWorkerId = matched.id;
            return prevWorkers.map((w) =>
              w.id === matched.id
                ? {
                    ...w,
                    status: 'BUSY',
                    activeJobId: nextJob.id,
                    computeLoadPercent: Math.min(95, w.computeLoadPercent + 30),
                  }
                : w
            );
          }
          return prevWorkers;
        });

        if (!matchedWorkerId) return prevJobs;

        addLog(
          'INFO',
          'speechscale.orchestrator',
          `Dispatched job ${nextJob.id} to worker node ${matchedWorkerId}`,
          matchedWorkerId,
          nextJob.id
        );

        // Update job to ROUTING / PREPROCESSING
        return prevJobs.map((j) => {
          if (j.id === nextJob.id) {
            return {
              ...j,
              status: 'PREPROCESSING',
              workerId: matchedWorkerId,
              startedAt: Date.now(),
              queueWaitMs: Date.now() - j.createdAt,
              progressPercent: 25,
            };
          }
          return j;
        });
      });
    }, 800);

    return () => clearInterval(interval);
  }, []);

  // Active Job Progress Advancer
  useEffect(() => {
    const interval = setInterval(() => {
      setJobs((prevJobs) => {
        return prevJobs.map((j) => {
          if (j.status === 'PREPROCESSING') {
            return { ...j, status: 'INFERENCING', progressPercent: 55 };
          }
          if (j.status === 'INFERENCING') {
            if (j.progressPercent < 90) {
              return { ...j, progressPercent: j.progressPercent + 20 };
            }

            // Job Completed!
            const now = Date.now();
            const durationMs = j.startedAt ? now - j.startedAt : 720;
            const rtf = Number(((durationMs / 1000) / j.audioDurationSec).toFixed(3));

            // Matched sample data for rich output
            const sample = SAMPLE_AUDIOS.find((s) => s.title === j.audioName) || SAMPLE_AUDIOS[0];
            const resultText = (sample.modelTranscripts as any)[j.model] || sample.referenceText;

            addLog(
              'INFO',
              'speechscale.worker',
              `Completed inference successfully in ${durationMs}ms. RTF: ${rtf}x`,
              j.workerId,
              j.id,
              { rtf, latency_ms: durationMs }
            );

            // Free worker and record latency
            if (j.workerId) {
              setWorkers((prevWorkers) =>
                prevWorkers.map((w) => {
                  if (w.id === j.workerId) {
                    const effectiveDurationMs = w.isThrottled ? durationMs + 450 : durationMs;
                    const nextLatencies = addWorkerJobLatency(w.recentLatenciesMs || [], effectiveDurationMs, 10);
                    return {
                      ...w,
                      status: 'IDLE',
                      activeJobId: undefined,
                      totalJobsProcessed: w.totalJobsProcessed + 1,
                      computeLoadPercent: Math.max(15, w.computeLoadPercent - 25),
                      recentLatenciesMs: nextLatencies,
                    };
                  }
                  return w;
                })
              );
            }

            return {
              ...j,
              status: 'COMPLETED',
              progressPercent: 100,
              completedAt: now,
              inferenceDurationMs: durationMs,
              result: {
                text: resultText,
                segments: sample.segments,
                words: sample.words,
                language: 'en',
                rtf,
                tokensCount: Math.round(j.audioDurationSec * 2.8),
                vramPeakMb: 4200,
              },
            };
          }
          return j;
        });
      });
    }, 600);

    return () => clearInterval(interval);
  }, []);

  // Worker OOM simulation handler
  const handleSimulateOom = (workerId: string) => {
    const targetWorker = workers.find((w) => w.id === workerId);
    if (!targetWorker) return;

    addLog('ERROR', 'speechscale.worker', `CUDA OutOfMemoryError: Tried to allocate 1.40 GiB on ${targetWorker.device}`, workerId);

    // Set worker to OOM_RECOVERY
    setWorkers((prev) =>
      prev.map((w) =>
        w.id === workerId
          ? { ...w, status: 'OOM_RECOVERY', computeLoadPercent: 100, failedJobs: w.failedJobs + 1 }
          : w
      )
    );

    // Re-queue active job with retry count
    if (targetWorker.activeJobId) {
      const activeJob = jobs.find((j) => j.id === targetWorker.activeJobId);
      if (activeJob) {
        const nextRetry = activeJob.retryCount + 1;
        if (nextRetry > activeJob.maxRetries) {
          // Send to DLQ
          addLog('ERROR', 'speechscale.dlq', `Job ${activeJob.id} exceeded max retries (3). Moving to DLQ.`, workerId, activeJob.id);
          setJobs((prev) => prev.filter((j) => j.id !== activeJob.id));
          setDlqJobs((prev) => [{ ...activeJob, status: 'FAILED', error: 'Exceeded max retries (CUDA OOM)' }, ...prev]);
        } else {
          const backoff = calculateBackoffMs(nextRetry);
          addLog('WARN', 'speechscale.orchestrator', `Re-queuing ${activeJob.id}. Retry attempt #${nextRetry} after ${backoff}ms backoff`, workerId, activeJob.id);
          setJobs((prev) =>
            prev.map((j) =>
              j.id === activeJob.id
                ? { ...j, status: 'RETRYING', retryCount: nextRetry, workerId: undefined, progressPercent: 0 }
                : j
            )
          );
        }
      }
    }

    // Auto-recover worker after 3 seconds
    setTimeout(() => {
      addLog('INFO', 'speechscale.worker', `Worker ${workerId} cache cleared. CUDA device reset and back to IDLE.`, workerId);
      setWorkers((prev) =>
        prev.map((w) =>
          w.id === workerId
            ? { ...w, status: 'IDLE', computeLoadPercent: 20, activeJobId: undefined }
            : w
        )
      );
    }, 3000);
  };

  // Timeout simulation handler
  const handleSimulateTimeout = (workerId: string) => {
    const targetWorker = workers.find((w) => w.id === workerId);
    if (!targetWorker || !targetWorker.activeJobId) return;

    const jobId = targetWorker.activeJobId;
    addLog('ERROR', 'speechscale.gateway', `RequestTimeout: Inference job ${jobId} exceeded 12000ms SLA timeout threshold`, workerId, jobId);

    setJobs((prev) =>
      prev.map((j) =>
        j.id === jobId
          ? { ...j, status: 'TIMED_OUT', error: 'Request execution exceeded 12.0s timeout deadline' }
          : j
      )
    );

    setWorkers((prev) =>
      prev.map((w) =>
        w.id === workerId ? { ...w, status: 'IDLE', activeJobId: undefined } : w
      )
    );
  };

  // Scale worker count
  const handleScaleWorker = (delta: number) => {
    if (delta > 0 && workers.length < 8) {
      const newIdx = workers.length + 1;
      const newWorker: WorkerInstance = {
        id: `worker-0${newIdx}`,
        name: `worker-0${newIdx} (GPU-${newIdx - 1})`,
        device: 'NVIDIA A100-SXM4-80GB',
        vramTotalMb: 81920,
        vramUsedMb: 12000,
        computeLoadPercent: 15,
        status: 'IDLE',
        loadedModel: 'whisper-large-v3',
        totalJobsProcessed: 0,
        failedJobs: 0,
        uptimeSec: 10,
        recentLatenciesMs: [230, 245, 240, 250, 235, 240, 255, 245, 230, 240],
        isThrottled: false,
      };
      setWorkers((prev) => [...prev, newWorker]);
      addLog('INFO', 'speechscale.orchestrator', `Dynamically scaled up worker instance worker-0${newIdx}`);
    } else if (delta < 0 && workers.length > 2) {
      const removed = workers[workers.length - 1];
      setWorkers((prev) => prev.slice(0, prev.length - 1));
      addLog('WARN', 'speechscale.orchestrator', `Scaled down and drained worker instance ${removed.id}`);
    }
  };

  // Simulate or clear thermal throttling degradation on a worker
  const handleToggleThrottle = (workerId: string) => {
    setWorkers((prev) =>
      prev.map((w) => {
        if (w.id === workerId) {
          const nextThrottled = !w.isThrottled;
          addLog(
            nextThrottled ? 'WARN' : 'INFO',
            'speechscale.telemetry',
            nextThrottled
              ? `Thermal throttling simulated on ${w.name} (+450ms penalty injected). Performance degraded.`
              : `Thermal throttling cleared on ${w.name}. Normal inference latency restored.`,
            w.id
          );
          // If throttling turned on, simulate a high latency spike in the recent latencies
          const updatedLatencies = nextThrottled
            ? addWorkerJobLatency(w.recentLatenciesMs || [], 860, 10)
            : addWorkerJobLatency(w.recentLatenciesMs || [], 235, 10);
          return {
            ...w,
            isThrottled: nextThrottled,
            recentLatenciesMs: updatedLatencies,
          };
        }
        return w;
      })
    );
  };


  // Simulate Traffic Surge / Queue Spike
  const handleTriggerSpike = () => {
    const burstJobs: InferenceJob[] = [];
    const priorities: Priority[] = ['CRITICAL', 'HIGH', 'DEFAULT', 'BATCH'];
    const now = Date.now();

    for (let i = 0; i < 25; i++) {
      const sample = SAMPLE_AUDIOS[i % SAMPLE_AUDIOS.length];
      const prio = priorities[i % priorities.length];
      burstJobs.push({
        id: `spike-job-${now}-${i}`,
        audioName: `${sample.title} (Spike #${i + 1})`,
        audioDurationSec: sample.durationSec,
        model: 'whisper-large-v3',
        engine: 'faster-whisper',
        quantization: 'int8',
        priority: prio,
        beamSize: 1,
        temperature: 0.0,
        vadFilter: true,
        diarization: false,
        status: 'QUEUED',
        progressPercent: 0,
        createdAt: now + i * 10,
        retryCount: 0,
        maxRetries: 3,
        timeoutMs: 12000,
      });
    }

    setJobs((prev) => [...burstJobs, ...prev]);

    // Record instantaneous spike in Recharts time-series
    const timeLabel = new Date(now).toLocaleTimeString();
    setQueueHistory((prev) => [
      ...prev.slice(-29),
      {
        time: timeLabel,
        timestamp: now,
        queueDepth: queuedJobs.length + 25,
        activeWorkers: workers.length,
        scaleUpThreshold: autoscalingConfig.scaleUpThreshold,
        scaleDownThreshold: autoscalingConfig.scaleDownThreshold,
        event: 'Traffic Spike (+25)',
      },
    ]);

    addLog(
      'WARN',
      'speechscale.gateway',
      `[Traffic Surge Alert] Ingested burst of 25 concurrent audio jobs into Redis streams`,
      undefined,
      undefined,
      { spike_size: 25, new_queue_depth: queuedJobs.length + 25 }
    );
  };

  // Re-drive DLQ
  const handleRedriveDlq = () => {
    if (dlqJobs.length === 0) return;
    addLog('INFO', 'speechscale.orchestrator', `Re-driving ${dlqJobs.length} DLQ jobs back into standard ingest queue`);
    const reDriven = dlqJobs.map((j) => ({
      ...j,
      status: 'QUEUED' as const,
      retryCount: 0,
      createdAt: Date.now(),
      progressPercent: 0,
    }));
    setJobs((prev) => [...reDriven, ...prev]);
    setDlqJobs([]);
  };

  // Re-drive single failed/DLQ job
  const handleRedriveSingleJob = (jobId: string) => {
    const dlqTarget = dlqJobs.find((j) => j.id === jobId);
    if (dlqTarget) {
      setDlqJobs((prev) => prev.filter((j) => j.id !== jobId));
      const restoredJob: InferenceJob = {
        ...dlqTarget,
        status: 'QUEUED',
        retryCount: 0,
        createdAt: Date.now(),
        progressPercent: 0,
        error: undefined,
        workerId: undefined,
      };
      setJobs((prev) => [restoredJob, ...prev]);
      addLog('INFO', 'speechscale.orchestrator', `Re-driving DLQ job ${jobId} back into ingest stream`, undefined, jobId);
      return;
    }

    const jobTarget = jobs.find((j) => j.id === jobId);
    if (jobTarget) {
      setJobs((prev) =>
        prev.map((j) =>
          j.id === jobId
            ? { ...j, status: 'QUEUED', retryCount: 0, createdAt: Date.now(), progressPercent: 0, error: undefined, workerId: undefined }
            : j
        )
      );
      addLog('INFO', 'speechscale.orchestrator', `Re-queuing failed job ${jobId}`, undefined, jobId);
    }
  };

  // Inject synthetic sample error for interactive drill-down testing
  const handleSimulateSampleError = (category: ErrorCategory) => {
    const now = Date.now();
    const id = `err-${category.toLowerCase()}-${now.toString().slice(-4)}`;
    let errorMsg = '';
    let modelName: ModelId = 'whisper-large-v3';
    let audioName = 'Synthetic Test Audio';

    switch (category) {
      case 'OOM':
        errorMsg = 'CUDA out of memory. Tried to allocate 3.10 GiB (GPU 1; 16.00 GiB capacity; 14.20 GiB reserved)';
        audioName = 'High-VRAM Acoustic Beamforming 96kHz';
        modelName = 'whisper-large-v3';
        break;
      case 'TIMEOUT':
        errorMsg = 'Inference job exceeded 12000ms SLA deadline';
        audioName = 'Dense 12-Speaker Podcast Diarization';
        modelName = 'whisper-medium';
        break;
      case 'AUDIO_DECODE_ERROR':
        errorMsg = 'Failed to decode audio stream: invalid samplerate 8000Hz without upsampling filter';
        audioName = 'Legacy PSTN Phone Recording';
        modelName = 'whisper-tiny';
        break;
      case 'RATE_LIMIT':
        errorMsg = 'HTTP 429 Too Many Requests: Rate limit exceeded on HuggingFace Hub model weights shard download';
        audioName = 'Cold-Start Model Weight Ingestion';
        modelName = 'distil-whisper-v3';
        break;
      case 'API_ERROR':
      default:
        errorMsg = 'HTTP 502 Bad Gateway: Envoy upstream proxy disconnect during CTranslate2 forward pass';
        audioName = 'Microservice Gateway Hop';
        modelName = 'whisper-large-v3';
        break;
    }

    const newFailedJob: InferenceJob = {
      id,
      audioName,
      audioDurationSec: 64,
      model: modelName,
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'HIGH',
      beamSize: 1,
      temperature: 0.0,
      vadFilter: true,
      diarization: false,
      status: category === 'TIMEOUT' ? 'TIMED_OUT' : 'FAILED',
      progressPercent: 35,
      createdAt: now,
      error: errorMsg,
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
    };

    setDlqJobs((prev) => [newFailedJob, ...prev]);
    addLog('ERROR', 'speechscale.worker', `[Cluster Incident] ${category}: ${errorMsg}`, undefined, id);
  };

  const queuedJobs = jobs.filter((j) => j.status === 'QUEUED' || j.status === 'RETRYING');
  const activeJobs = jobs.filter((j) => j.status === 'INFERENCING' || j.status === 'PREPROCESSING' || j.status === 'ROUTING');
  const failedJobs = jobs.filter((j) => j.status === 'FAILED' || j.status === 'TIMED_OUT');
  const failedJobsCount = failedJobs.length + dlqJobs.length;
  const activeJob = jobs.find((j) => j.id === activeJobId) || jobs[0] || null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeWorkerCount={workers.filter((w) => w.status === 'IDLE' || w.status === 'BUSY').length}
        totalWorkerCount={workers.length}
        queueDepth={queuedJobs.length}
        activeJobsCount={activeJobs.length}
        failedJobsCount={failedJobsCount}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'inference' && (
          <InferencePlayground
            jobs={jobs}
            submitJob={submitJob}
            activeJob={activeJob}
            setActiveJobId={setActiveJobId}
          />
        )}

        {activeTab === 'orchestrator' && (
          <WorkerOrchestrator
            workers={workers}
            queuedJobs={queuedJobs}
            dlqJobs={dlqJobs}
            logs={logs}
            queueHistory={queueHistory}
            autoscalingConfig={autoscalingConfig}
            autoscalerState={autoscalerState}
            onUpdateAutoscalingConfig={(cfg) => setAutoscalingConfig((prev) => ({ ...prev, ...cfg }))}
            onTriggerSpike={handleTriggerSpike}
            onScaleWorker={handleScaleWorker}
            onSimulateOom={handleSimulateOom}
            onSimulateTimeout={handleSimulateTimeout}
            onToggleThrottle={handleToggleThrottle}
            onRedriveDlq={handleRedriveDlq}
            onClearLogs={() => setLogs([])}
          />
        )}

        {activeTab === 'benchmarks' && (
          <BenchmarkingSuite
            benchmarkHistory={benchmarkHistory}
            onAddBenchmark={(run) => setBenchmarkHistory((prev) => [run, ...prev])}
            onClearHistory={() => setBenchmarkHistory([])}
          />
        )}

        {activeTab === 'wer' && <WerEvaluation />}

        {activeTab === 'errors' && (
          <ErrorBreakdown
            failedJobs={failedJobs}
            dlqJobs={dlqJobs}
            workers={workers}
            onRedriveJob={handleRedriveSingleJob}
            onRedriveAll={handleRedriveDlq}
            onSimulateSampleError={handleSimulateSampleError}
          />
        )}
      </main>

      {/* Premium Minimalist Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/60 px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">SpeechScale</span>
            <span className="text-slate-600">&bull;</span>
            <span className="text-slate-400">High-Throughput Speech Recognition &amp; Cluster Orchestration</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
            <span>Inference: Whisper (FastAPI + CTranslate2)</span>
            <span className="text-slate-700">&bull;</span>
            <span>Redis Streams 7.2</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
