import test from 'node:test';
import assert from 'node:assert/strict';
import { computeWorkerAvgLatency, getWorkerLatencyHealth, addWorkerJobLatency } from './workerHealth';

test('computeWorkerAvgLatency computes integer average correctly', () => {
  assert.equal(computeWorkerAvgLatency([]), 0);
  assert.equal(computeWorkerAvgLatency([200, 300, 400]), 300);
  assert.equal(computeWorkerAvgLatency([250, 255, 260]), 255);
});

test('getWorkerLatencyHealth classifies healthy, degraded, and critical SLAs', () => {
  assert.equal(getWorkerLatencyHealth(250, 800), 'HEALTHY');
  assert.equal(getWorkerLatencyHealth(600, 800), 'DEGRADED');
  assert.equal(getWorkerLatencyHealth(950, 800), 'CRITICAL');
});

test('addWorkerJobLatency caps history to last 10 entries', () => {
  let list: number[] = [];
  for (let i = 1; i <= 15; i++) {
    list = addWorkerJobLatency(list, i * 10, 10);
  }
  assert.equal(list.length, 10);
  assert.equal(list[0], 60);
  assert.equal(list[9], 150);
});
