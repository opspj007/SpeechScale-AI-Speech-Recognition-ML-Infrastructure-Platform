import test from 'node:test';
import assert from 'node:assert/strict';
import { computeWER, computeCER, normalizeText, tokenizeWords } from './wer';

test('normalizeText handles punctuation, casing and extra spaces', () => {
  const raw = "  Hello, World! Here's a TEST... with    spaces. ";
  assert.equal(normalizeText(raw), "hello world here's a test with spaces");
});

test('tokenizeWords splits into array of words correctly', () => {
  const text = "Whisper is an open-source model";
  const tokens = tokenizeWords(text);
  assert.deepEqual(tokens, ["whisper", "is", "an", "open", "source", "model"]);
});

test('computeWER returns 0% on exact matching strings', () => {
  const ref = "the quick brown fox jumps over the lazy dog";
  const hyp = "The quick brown fox jumps over the lazy dog.";
  const res = computeWER(ref, hyp);
  assert.equal(res.wer, 0);
  assert.equal(res.substitutions, 0);
  assert.equal(res.deletions, 0);
  assert.equal(res.insertions, 0);
  assert.equal(res.hits, 9);
  assert.equal(res.refWordCount, 9);
});

test('computeWER correctly flags substitution, deletion, and insertion', () => {
  // Reference: "speech recognition platform with fast api" (6 words)
  // Hypothesis: "speech recognition system fast api worker"
  // Words:
  // "speech": match
  // "recognition": match
  // "platform" -> "system": substitution (1)
  // "with": deleted (1)
  // "fast": match
  // "api": match
  // "worker": inserted (1)
  // Total edits = 3. Ref count = 6. WER = (3 / 6) * 100 = 50%
  const ref = "speech recognition platform with fast api";
  const hyp = "speech recognition system fast api worker";
  const res = computeWER(ref, hyp);
  assert.equal(res.substitutions, 1);
  assert.equal(res.deletions, 1);
  assert.equal(res.insertions, 1);
  assert.equal(res.hits, 4);
  assert.equal(res.refWordCount, 6);
  assert.equal(res.wer, 50);
});

test('computeWER handles empty hypothesis (100% deletion)', () => {
  const ref = "testing speech model";
  const hyp = "";
  const res = computeWER(ref, hyp);
  assert.equal(res.wer, 100);
  assert.equal(res.deletions, 3);
  assert.equal(res.hits, 0);
});

test('computeCER calculates character error rate accurately', () => {
  const ref = "cat";
  const hyp = "hat"; // 1 sub in 3 chars = 33.33%
  const cer = computeCER(ref, hyp);
  assert.equal(cer, 33.33);
});
