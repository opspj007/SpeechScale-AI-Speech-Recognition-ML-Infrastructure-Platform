import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyError, analyzeClusterErrors, getErrorCategoryDetails } from './errorBreakdown';
import { InferenceJob } from '../types';

test('classifyError detects CUDA OOM', () => {
  assert.equal(classifyError('CUDA out of memory: tried to allocate 2.4GB VRAM'), 'OOM');
  assert.equal(classifyError('Exceeded max retries (CUDA OOM)'), 'OOM');
});

test('classifyError detects Timeout', () => {
  assert.equal(classifyError('Request execution exceeded 12.0s timeout deadline', 'TIMED_OUT'), 'TIMEOUT');
  assert.equal(classifyError(undefined, 'TIMED_OUT'), 'TIMEOUT');
});

test('classifyError detects Audio decode error', () => {
  assert.equal(classifyError('FFmpeg audio decode failed: corrupt MP3 header'), 'AUDIO_DECODE_ERROR');
});

test('classifyError detects Rate Limit', () => {
  assert.equal(classifyError('HTTP 429 Too Many Requests: concurrency cap exceeded'), 'RATE_LIMIT');
});

test('classifyError defaults to API_ERROR for unhandled runtime faults', () => {
  assert.equal(classifyError('Unexpected server exception: cuBLAS runtime failed'), 'API_ERROR');
});

test('analyzeClusterErrors aggregates counts and calculates percentages accurately', () => {
  const dummyJobs: InferenceJob[] = [
    {
      id: 'job-1',
      audioName: 'audio-1',
      audioDurationSec: 10,
      model: 'whisper-large-v3',
      engine: 'pytorch-eager',
      quantization: 'fp32',
      priority: 'HIGH',
      beamSize: 5,
      temperature: 0,
      vadFilter: true,
      diarization: false,
      status: 'FAILED',
      progressPercent: 30,
      createdAt: Date.now(),
      retryCount: 3,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'CUDA out of memory: GPU allocation failed',
    },
    {
      id: 'job-2',
      audioName: 'audio-2',
      audioDurationSec: 30,
      model: 'whisper-large-v3',
      engine: 'faster-whisper',
      quantization: 'int8',
      priority: 'DEFAULT',
      beamSize: 1,
      temperature: 0,
      vadFilter: true,
      diarization: false,
      status: 'TIMED_OUT',
      progressPercent: 65,
      createdAt: Date.now(),
      retryCount: 1,
      maxRetries: 3,
      timeoutMs: 12000,
      error: 'Request execution exceeded 12.0s timeout deadline',
    },
  ];

  const metrics = analyzeClusterErrors(dummyJobs);
  assert.equal(metrics.totalFailed, 2);
  assert.equal(metrics.oomCount, 1);
  assert.equal(metrics.timeoutCount, 1);
  assert.equal(metrics.apiErrorCount, 0);

  const oomGroup = metrics.groups.find((g) => g.category === 'OOM');
  assert.ok(oomGroup);
  assert.equal(oomGroup.count, 1);
  assert.equal(oomGroup.percentage, 50);
});
