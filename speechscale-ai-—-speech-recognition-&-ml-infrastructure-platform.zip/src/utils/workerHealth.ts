/**
 * Worker latency tracking and health diagnostics
 */

export type WorkerHealthStatus = 'HEALTHY' | 'DEGRADED' | 'CRITICAL';

export function computeWorkerAvgLatency(latencies: number[]): number {
  if (!latencies || latencies.length === 0) return 0;
  const sum = latencies.reduce((a, b) => a + b, 0);
  return Math.round(sum / latencies.length);
}

export function getWorkerLatencyHealth(avgMs: number, slaTargetMs: number = 800): WorkerHealthStatus {
  if (avgMs <= 0) return 'HEALTHY';
  if (avgMs > slaTargetMs) return 'CRITICAL';
  if (avgMs > slaTargetMs * 0.6) return 'DEGRADED';
  return 'HEALTHY';
}

export function addWorkerJobLatency(recent: number[], newLatency: number, maxHistory: number = 10): number[] {
  const updated = [...(recent || []), Math.round(newLatency)];
  return updated.slice(-maxHistory);
}
