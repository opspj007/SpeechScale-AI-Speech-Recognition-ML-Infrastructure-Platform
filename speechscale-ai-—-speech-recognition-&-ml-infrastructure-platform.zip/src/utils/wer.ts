import { WerResult, AlignmentWord } from '../types';

/**
 * Normalizes text for speech recognition evaluation.
 * Strips punctuation, collapses whitespace, converts to lowercase, handles common number/contraction cases.
 */
export function normalizeText(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\w\s']/g, ' ') // replace punctuation with spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Tokenizes text into words.
 */
export function tokenizeWords(text: string): string[] {
  const norm = normalizeText(text);
  if (!norm) return [];
  return norm.split(' ').filter(Boolean);
}

/**
 * Computes Word Error Rate (WER) using Levenshtein distance dynamic programming.
 * Backtracks the DP matrix to extract precise word alignments (match, sub, del, ins).
 */
export function computeWER(reference: string, hypothesis: string): WerResult {
  const refTokens = tokenizeWords(reference);
  const hypTokens = tokenizeWords(hypothesis);

  const n = refTokens.length;
  const m = hypTokens.length;

  if (n === 0 && m === 0) {
    return {
      substitutions: 0,
      deletions: 0,
      insertions: 0,
      hits: 0,
      refWordCount: 0,
      hypWordCount: 0,
      wer: 0,
      cer: 0,
      ser: 0,
      alignments: [],
    };
  }

  if (n === 0) {
    return {
      substitutions: 0,
      deletions: 0,
      insertions: m,
      hits: 0,
      refWordCount: 0,
      hypWordCount: m,
      wer: 100,
      cer: 100,
      ser: 100,
      alignments: hypTokens.map(word => ({ type: 'insertion', hypWord: word })),
    };
  }

  if (m === 0) {
    return {
      substitutions: 0,
      deletions: n,
      insertions: 0,
      hits: 0,
      refWordCount: n,
      hypWordCount: 0,
      wer: 100,
      cer: 100,
      ser: 100,
      alignments: refTokens.map(word => ({ type: 'deletion', refWord: word })),
    };
  }

  // Cost matrix: dp[i][j] = min edits between ref[0..i-1] and hyp[0..j-1]
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));

  for (let i = 0; i <= n; i++) dp[i][0] = i; // all deletions
  for (let j = 0; j <= m; j++) dp[0][j] = j; // all insertions

  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (refTokens[i - 1] === hypTokens[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1]; // match, cost 0
      } else {
        const substitution = dp[i - 1][j - 1] + 1;
        const deletion = dp[i - 1][j] + 1;
        const insertion = dp[i][j - 1] + 1;
        dp[i][j] = Math.min(substitution, deletion, insertion);
      }
    }
  }

  // Backtrack to extract alignment
  let i = n;
  let j = m;
  const alignments: AlignmentWord[] = [];
  let substitutions = 0;
  let deletions = 0;
  let insertions = 0;
  let hits = 0;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && refTokens[i - 1] === hypTokens[j - 1]) {
      alignments.unshift({
        type: 'match',
        refWord: refTokens[i - 1],
        hypWord: hypTokens[j - 1],
      });
      hits++;
      i--;
      j--;
    } else if (i > 0 && j > 0 && dp[i][j] === dp[i - 1][j - 1] + 1) {
      alignments.unshift({
        type: 'substitution',
        refWord: refTokens[i - 1],
        hypWord: hypTokens[j - 1],
      });
      substitutions++;
      i--;
      j--;
    } else if (i > 0 && dp[i][j] === dp[i - 1][j] + 1) {
      alignments.unshift({
        type: 'deletion',
        refWord: refTokens[i - 1],
      });
      deletions++;
      i--;
    } else {
      alignments.unshift({
        type: 'insertion',
        hypWord: hypTokens[j - 1],
      });
      insertions++;
      j--;
    }
  }

  const rawWer = ((substitutions + deletions + insertions) / n) * 100;
  const wer = Math.round(rawWer * 100) / 100;
  const cer = computeCER(reference, hypothesis);
  const ser = wer > 0 ? 100 : 0;

  return {
    substitutions,
    deletions,
    insertions,
    hits,
    refWordCount: n,
    hypWordCount: m,
    wer,
    cer,
    ser,
    alignments,
  };
}

/**
 * Character Error Rate (CER) calculation
 */
export function computeCER(reference: string, hypothesis: string): number {
  const ref = normalizeText(reference).replace(/\s+/g, '');
  const hyp = normalizeText(hypothesis).replace(/\s+/g, '');

  if (!ref.length && !hyp.length) return 0;
  if (!ref.length) return 100;
  if (!hyp.length) return 100;

  const n = ref.length;
  const m = hyp.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));

  for (let i = 0; i <= n; i++) dp[i][0] = i;
  for (let j = 0; j <= m; j++) dp[0][j] = j;

  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (ref[i - 1] === hyp[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = Math.min(
          dp[i - 1][j - 1] + 1, // sub
          dp[i - 1][j] + 1,     // del
          dp[i][j - 1] + 1      // ins
        );
      }
    }
  }

  const rawCer = (dp[n][m] / n) * 100;
  return Math.round(rawCer * 100) / 100;
}
