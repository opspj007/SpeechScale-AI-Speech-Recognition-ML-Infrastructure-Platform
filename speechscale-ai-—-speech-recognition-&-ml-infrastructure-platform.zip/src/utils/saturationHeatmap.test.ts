import test from 'node:test';
import assert from 'node:assert/strict';
import { 
  calculateHeatmapLatency, 
  generateSaturationMatrix, 
  detectModelSaturationKnee,
  HEATMAP_CONCURRENCY_LEVELS,
  HEATMAP_MODELS
} from './saturationHeatmap';

test('calculateHeatmapLatency computes latency monotonically increasing with concurrency', () => {
  const lowLoad = calculateHeatmapLatency('whisper-large-v3', 1, 'faster-whisper', 'int8', 800);
  const midLoad = calculateHeatmapLatency('whisper-large-v3', 20, 'faster-whisper', 'int8', 800);
  const highLoad = calculateHeatmapLatency('whisper-large-v3', 100, 'faster-whisper', 'int8', 800);

  assert.ok(lowLoad.avgLatencyMs < midLoad.avgLatencyMs, 'Latency should increase from 1 to 20 concurrency');
  assert.ok(midLoad.avgLatencyMs < highLoad.avgLatencyMs, 'Latency should increase from 20 to 100 concurrency');
  assert.ok(lowLoad.rtf < highLoad.rtf, 'RTF should increase under load');
  assert.ok(highLoad.isSaturated, 'Whisper Large v3 at 100 concurrency should be marked saturated');
});

test('distil-whisper-v3 achieves significantly lower latency than whisper-large-v3', () => {
  const large = calculateHeatmapLatency('whisper-large-v3', 20, 'faster-whisper', 'int8', 800);
  const distil = calculateHeatmapLatency('distil-whisper-v3', 20, 'faster-whisper', 'int8', 800);

  assert.ok(distil.avgLatencyMs < large.avgLatencyMs * 0.4, 'Distil-Whisper should be >2.5x faster than Large-v3');
  assert.ok(distil.throughputRps > large.throughputRps, 'Distil-Whisper should have higher throughput');
});

test('generateSaturationMatrix generates complete grid with all models and concurrency levels', () => {
  const matrix = generateSaturationMatrix('faster-whisper', 'int8', 800);
  const expectedCount = HEATMAP_MODELS.length * HEATMAP_CONCURRENCY_LEVELS.length;
  assert.equal(matrix.length, expectedCount, `Matrix should contain ${expectedCount} cells`);

  // Verify all cells have valid non-zero values
  for (const cell of matrix) {
    assert.ok(cell.avgLatencyMs > 0, 'Cell avg latency must be positive');
    assert.ok(cell.p95LatencyMs >= cell.avgLatencyMs, 'p95 must be >= average latency');
    assert.ok(cell.throughputRps > 0, 'Throughput must be positive');
    assert.ok(['optimal', 'moderate', 'warning', 'saturated'].includes(cell.status), 'Valid status');
  }
});

test('detectModelSaturationKnee accurately identifies saturation threshold', () => {
  const largeKnee = detectModelSaturationKnee('whisper-large-v3', 'pytorch-eager', 'fp32', 800);
  // Large on PyTorch eager FP32 has high base latency and saturates early
  assert.ok(largeKnee.saturationConcurrency <= 20, 'Whisper Large on PyTorch FP32 should saturate at or before 20 concurrency');

  const tinyKnee = detectModelSaturationKnee('whisper-tiny', 'tensorrt-llm', 'int8', 800);
  // Tiny on TensorRT-LLM has high headroom
  assert.ok(tinyKnee.saturationConcurrency >= 50, 'Whisper Tiny should handle high concurrency without early saturation');
});
