import { BenchmarkRun, ModelId, ServingEngine, Quantization } from '../types';

/**
 * Computes percentile from an array of numbers (e.g. 50, 90, 95, 99).
 */
export function calculatePercentile(values: number[], percentile: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = (percentile / 100) * (sorted.length - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  const weight = index - lower;
  if (lower === upper) return Math.round(sorted[lower]);
  return Math.round(sorted[lower] * (1 - weight) + sorted[upper] * weight);
}

/**
 * Calculates Real Time Factor (RTF)
 * RTF = processing_time_seconds / audio_duration_seconds
 * An RTF < 1.0 means faster than real-time (e.g., 0.1 = 10x real-time).
 */
export function calculateRTF(inferenceDurationMs: number, audioDurationSec: number): number {
  if (audioDurationSec <= 0) return 0;
  const inferenceSec = inferenceDurationMs / 1000;
  return Number((inferenceSec / audioDurationSec).toFixed(3));
}

/**
 * Generates synthetic benchmark results matching real Whisper benchmarks on A100 GPU
 * under different configurations (FasterWhisper INT8, PyTorch FP16, etc.)
 */
export function simulateBenchmarkRun(
  concurrency: number,
  requestsCount: number,
  model: ModelId,
  engine: ServingEngine,
  quantization: Quantization,
  slaTargetMs: number = 1000
): BenchmarkRun {
  // Base latency coefficients based on model size
  const modelBaseMs: Record<ModelId, number> = {
    'whisper-tiny': 65,
    'whisper-base': 120,
    'whisper-small': 290,
    'whisper-medium': 680,
    'whisper-large-v3': 1250,
    'distil-whisper-v3': 220,
  };

  // Speedup multipliers for engine
  const engineMultiplier: Record<ServingEngine, number> = {
    'faster-whisper': 0.42, // CTranslate2 is ~2.4x faster
    'tensorrt-llm': 0.35,   // TensorRT is ~2.8x faster
    'onnx-runtime': 0.65,
    'pytorch-eager': 1.0,
  };

  // Speedup for quantization
  const quantMultiplier: Record<Quantization, number> = {
    'fp32': 1.4,
    'fp16': 1.0,
    'int8': 0.68,
    'int4': 0.52,
  };

  const baseLatency = (modelBaseMs[model] || 300) * 
                      (engineMultiplier[engine] || 1.0) * 
                      (quantMultiplier[quantization] || 1.0);

  // Concurrency queuing penalty (Amdahl's law / queuing theory simulation)
  // At high concurrency, queuing delay increases p95/p99 significantly
  const latencies: number[] = [];
  let slaBreached = 0;

  for (let i = 0; i < requestsCount; i++) {
    // Normal distribution variance + concurrency tail latency
    const jitter = (Math.random() - 0.45) * (baseLatency * 0.25);
    const queuePenalty = Math.max(0, (concurrency - 4) * (baseLatency * 0.08) * (1 + Math.random() * 0.4));
    // Occasional tail spike (GC, GPU kernel launch, context switch)
    const isTailSpike = Math.random() < 0.05;
    const spike = isTailSpike ? baseLatency * 0.9 : 0;
    
    const latency = Math.max(20, Math.round(baseLatency + jitter + queuePenalty + spike));
    latencies.push(latency);
    if (latency > slaTargetMs) slaBreached++;
  }

  const p50 = calculatePercentile(latencies, 50);
  const p90 = calculatePercentile(latencies, 90);
  const p95 = calculatePercentile(latencies, 95);
  const p99 = calculatePercentile(latencies, 99);
  const minMs = Math.min(...latencies);
  const maxMs = Math.max(...latencies);

  // Simulated 30-second average audio chunk
  const avgAudioSec = 30;
  const meanRtf = calculateRTF(p50, avgAudioSec);
  
  // Throughput: requests per second = concurrency / (mean latency in seconds)
  const throughputRps = Number(((concurrency * 1000) / p50).toFixed(1));
  // Processed audio minutes per wall-clock minute
  const audioMinutesPerMinute = Number(((throughputRps * avgAudioSec) / 60 * 60).toFixed(0));

  // GPU Memory footprint
  const vramFootprintMb: Record<ModelId, number> = {
    'whisper-tiny': 450,
    'whisper-base': 780,
    'whisper-small': 1850,
    'whisper-medium': 4200,
    'whisper-large-v3': 9500,
    'distil-whisper-v3': 2400,
  };
  const baseVram = vramFootprintMb[model] || 2000;
  const quantVramFactor: Record<Quantization, number> = {
    'fp32': 2.0,
    'fp16': 1.0,
    'int8': 0.55,
    'int4': 0.32,
  };
  const avgVramMb = Math.round(baseVram * quantVramFactor[quantization] + (concurrency * 45));
  const avgGpuLoad = Math.min(99, Math.round(35 + (concurrency * 1.8)));

  const successRate = Number((((requestsCount - (slaBreached * 0.2)) / requestsCount) * 100).toFixed(1));

  return {
    id: `bench-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now(),
    concurrency,
    requestsCount,
    model,
    engine,
    quantization,
    p50Ms: p50,
    p90Ms: p90,
    p95Ms: p95,
    p99Ms: p99,
    minMs,
    maxMs,
    meanRtf,
    throughputRps,
    audioMinutesPerMinute,
    avgGpuLoad,
    avgVramMb,
    successRate: Math.min(100, successRate),
    slaBreachedCount: slaBreached,
    slaTargetMs,
  };
}
