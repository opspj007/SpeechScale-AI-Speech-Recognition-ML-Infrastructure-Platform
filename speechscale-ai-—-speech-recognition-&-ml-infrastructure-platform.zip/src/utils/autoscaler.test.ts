import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateAutoscaler, DEFAULT_AUTOSCALING_CONFIG, INITIAL_AUTOSCALER_STATE } from './autoscaler';
import { AutoscalingConfig, AutoscalerState } from '../types';

test('evaluateAutoscaler returns NONE when disabled', () => {
  const config: AutoscalingConfig = { ...DEFAULT_AUTOSCALING_CONFIG, enabled: false };
  const res = evaluateAutoscaler(4, 100, 95, config, INITIAL_AUTOSCALER_STATE, 1000);
  assert.equal(res.action, 'NONE');
  assert.equal(res.targetWorkerDelta, 0);
  assert.equal(res.updatedState.currentStage, 'MONITORING');
});

test('evaluateAutoscaler tracks sustained duration and triggers SCALE_UP after duration window', () => {
  const config: AutoscalingConfig = {
    ...DEFAULT_AUTOSCALING_CONFIG,
    scaleUpThreshold: 20,
    scaleUpDurationSec: 5,
    scaleUpStep: 1,
    maxWorkers: 8,
  };

  const t0 = 10000;
  // First evaluation at t0: queue depth is 25 (> 20)
  const res1 = evaluateAutoscaler(4, 25, 60, config, INITIAL_AUTOSCALER_STATE, t0);
  assert.equal(res1.action, 'NONE');
  assert.equal(res1.updatedState.currentStage, 'EVALUATING_SCALE_UP');
  assert.equal(res1.updatedState.conditionSustainedStartMs, t0);

  // 2 seconds later (not sustained enough yet)
  const res2 = evaluateAutoscaler(4, 25, 60, config, res1.updatedState, t0 + 2000);
  assert.equal(res2.action, 'NONE');
  assert.equal(res2.updatedState.secondsSustained, 2);

  // 5 seconds later (duration window reached)
  const res3 = evaluateAutoscaler(4, 25, 60, config, res2.updatedState, t0 + 5100);
  assert.equal(res3.action, 'SCALE_UP');
  assert.equal(res3.targetWorkerDelta, 1);
  assert.equal(res3.updatedState.currentStage, 'COOLDOWN');
  assert.equal(res3.updatedState.lastScaleActionMs, t0 + 5100);
});

test('evaluateAutoscaler does not scale beyond maxWorkers', () => {
  const config: AutoscalingConfig = {
    ...DEFAULT_AUTOSCALING_CONFIG,
    scaleUpThreshold: 10,
    scaleUpDurationSec: 2,
    maxWorkers: 4,
  };

  // Already at maxWorkers (4)
  const res = evaluateAutoscaler(4, 50, 99, config, INITIAL_AUTOSCALER_STATE, 1000);
  assert.equal(res.action, 'NONE');
  assert.equal(res.targetWorkerDelta, 0);
  assert.equal(res.updatedState.currentStage, 'MAX_REACHED');
});

test('evaluateAutoscaler enforces cooldown period after scaling', () => {
  const config: AutoscalingConfig = {
    ...DEFAULT_AUTOSCALING_CONFIG,
    scaleUpThreshold: 10,
    scaleUpCooldownSec: 10,
  };

  const stateWithRecentScale: AutoscalerState = {
    ...INITIAL_AUTOSCALER_STATE,
    lastScaleActionMs: 10000,
    lastAction: 'SCALE_UP',
  };

  // 4 seconds later (cooldown is 10s)
  const res = evaluateAutoscaler(4, 50, 90, config, stateWithRecentScale, 14000);
  assert.equal(res.action, 'NONE');
  assert.equal(res.updatedState.currentStage, 'COOLDOWN');
});

test('evaluateAutoscaler triggers SCALE_DOWN when workload is idle', () => {
  const config: AutoscalingConfig = {
    ...DEFAULT_AUTOSCALING_CONFIG,
    scaleDownThreshold: 1,
    scaleDownDurationSec: 5,
    minWorkers: 2,
    scaleDownStep: 1,
  };

  const t0 = 20000;
  // 4 workers currently, queue is empty (0)
  const res1 = evaluateAutoscaler(4, 0, 10, config, INITIAL_AUTOSCALER_STATE, t0);
  assert.equal(res1.action, 'NONE');
  assert.equal(res1.updatedState.currentStage, 'EVALUATING_SCALE_DOWN');

  // After 6 seconds
  const res2 = evaluateAutoscaler(4, 0, 10, config, res1.updatedState, t0 + 6000);
  assert.equal(res2.action, 'SCALE_DOWN');
  assert.equal(res2.targetWorkerDelta, -1);
});
