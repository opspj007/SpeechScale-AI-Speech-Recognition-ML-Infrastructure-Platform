import { InferenceJob, ModelId, ServingEngine, Quantization } from '../types';

export type ErrorCategory = 
  | 'OOM' 
  | 'TIMEOUT' 
  | 'API_ERROR' 
  | 'AUDIO_DECODE_ERROR' 
  | 'RATE_LIMIT';

export interface ClassifiedFailedJob {
  job: InferenceJob;
  category: ErrorCategory;
  categoryLabel: string;
  errorTitle: string;
  rootCause: string;
  recommendedRemediation: string;
  component: 'CUDA Engine' | 'HTTP Gateway' | 'Preprocessor' | 'Worker Runtime';
  timestampFormatted: string;
}

export interface ErrorGroupSummary {
  category: ErrorCategory;
  label: string;
  count: number;
  percentage: number;
  color: string;
  textColor: string;
  borderColor: string;
  bgColor: string;
  description: string;
}

export interface ClusterErrorMetrics {
  totalFailed: number;
  oomCount: number;
  timeoutCount: number;
  apiErrorCount: number;
  decodeErrorCount: number;
  rateLimitCount: number;
  dominantErrorCategory: ErrorCategory | null;
  groups: ErrorGroupSummary[];
  classifiedJobs: ClassifiedFailedJob[];
}

/**
 * Classifies an error message into standard cluster error types.
 */
export function classifyError(errorMsg?: string, status?: string): ErrorCategory {
  if (!errorMsg && status === 'TIMED_OUT') return 'TIMEOUT';
  const text = (errorMsg || '').toLowerCase();

  if (text.includes('cuda out of memory') || text.includes('oom') || text.includes('memory') || text.includes('vram')) {
    return 'OOM';
  }
  if (text.includes('timeout') || text.includes('timed out') || text.includes('deadline') || status === 'TIMED_OUT') {
    return 'TIMEOUT';
  }
  if (text.includes('audio') || text.includes('ffmpeg') || text.includes('codec') || text.includes('corrupt') || text.includes('decode')) {
    return 'AUDIO_DECODE_ERROR';
  }
  if (text.includes('rate limit') || text.includes('429') || text.includes('too many requests') || text.includes('concurrency cap')) {
    return 'RATE_LIMIT';
  }
  return 'API_ERROR';
}

/**
 * Returns human-readable diagnostic metadata for an error category.
 */
export function getErrorCategoryDetails(category: ErrorCategory): {
  label: string;
  color: string;
  textColor: string;
  borderColor: string;
  bgColor: string;
  component: 'CUDA Engine' | 'HTTP Gateway' | 'Preprocessor' | 'Worker Runtime';
  rootCause: string;
  recommendedRemediation: string;
} {
  switch (category) {
    case 'OOM':
      return {
        label: 'CUDA Out of Memory (OOM)',
        color: '#f43f5e',
        textColor: 'text-rose-400',
        borderColor: 'border-rose-800/60',
        bgColor: 'bg-rose-950/30',
        component: 'CUDA Engine',
        rootCause: 'Autoregressive decoder KV-cache allocation exceeded physical GPU VRAM limit on the worker.',
        recommendedRemediation: 'Switch to INT8 quantization, reduce beam size from 5 to 1, or upgrade worker to A100-80GB.',
      };
    case 'TIMEOUT':
      return {
        label: 'SLA Request Timeout (12.0s)',
        color: '#f59e0b',
        textColor: 'text-amber-400',
        borderColor: 'border-amber-800/60',
        bgColor: 'bg-amber-950/30',
        component: 'HTTP Gateway',
        rootCause: 'Execution time exceeded 12,000ms deadline due to queue backlog or long audio duration without chunking.',
        recommendedRemediation: 'Enable horizontal pod autoscaling (HPA) or partition audio files into ≤15s segments.',
      };
    case 'API_ERROR':
      return {
        label: 'Inference Backend Error (500)',
        color: '#a855f7',
        textColor: 'text-purple-400',
        borderColor: 'border-purple-800/60',
        bgColor: 'bg-purple-950/30',
        component: 'Worker Runtime',
        rootCause: 'Worker process crashed or cuBLAS kernel invocation threw an unhandled runtime exception.',
        recommendedRemediation: 'Check CUDA driver compatibility, inspect worker container logs, or trigger worker self-healing restart.',
      };
    case 'AUDIO_DECODE_ERROR':
      return {
        label: 'Audio Decode / Format Error',
        color: '#06b6d4',
        textColor: 'text-cyan-400',
        borderColor: 'border-cyan-800/60',
        bgColor: 'bg-cyan-950/30',
        component: 'Preprocessor',
        rootCause: 'Corrupt audio stream header, unsupported container codec, or zero-byte payload rejected by FFmpeg/Silero-VAD.',
        recommendedRemediation: 'Validate client audio encoding before upload; ensure 16kHz mono PCM/WAV or Opus formatting.',
      };
    case 'RATE_LIMIT':
      return {
        label: 'Concurrency Rate Limit (429)',
        color: '#eab308',
        textColor: 'text-yellow-400',
        borderColor: 'border-yellow-800/60',
        bgColor: 'bg-yellow-950/30',
        component: 'HTTP Gateway',
        rootCause: 'Inbound requests exceeded maximum Redis Stream buffer capacity under burst traffic.',
        recommendedRemediation: 'Apply token-bucket rate limiting upstream or increase worker concurrency limits.',
      };
  }
}

/**
 * Analyzes an array of failed and DLQ jobs to produce grouping metrics and detailed drill-down data.
 */
export function analyzeClusterErrors(failedJobs: InferenceJob[]): ClusterErrorMetrics {
  const classifiedJobs: ClassifiedFailedJob[] = failedJobs.map((job) => {
    const category = classifyError(job.error, job.status);
    const details = getErrorCategoryDetails(category);
    return {
      job,
      category,
      categoryLabel: details.label,
      errorTitle: job.error || (job.status === 'TIMED_OUT' ? 'Request SLA timeout' : 'Inference execution failure'),
      rootCause: details.rootCause,
      recommendedRemediation: details.recommendedRemediation,
      component: details.component,
      timestampFormatted: new Date(job.completedAt || job.createdAt).toLocaleTimeString(),
    };
  });

  const totalFailed = classifiedJobs.length;
  const oomCount = classifiedJobs.filter((j) => j.category === 'OOM').length;
  const timeoutCount = classifiedJobs.filter((j) => j.category === 'TIMEOUT').length;
  const apiErrorCount = classifiedJobs.filter((j) => j.category === 'API_ERROR').length;
  const decodeErrorCount = classifiedJobs.filter((j) => j.category === 'AUDIO_DECODE_ERROR').length;
  const rateLimitCount = classifiedJobs.filter((j) => j.category === 'RATE_LIMIT').length;

  const categories: ErrorCategory[] = ['OOM', 'TIMEOUT', 'API_ERROR', 'AUDIO_DECODE_ERROR', 'RATE_LIMIT'];
  
  const groups: ErrorGroupSummary[] = categories.map((cat) => {
    const details = getErrorCategoryDetails(cat);
    const count = classifiedJobs.filter((j) => j.category === cat).length;
    const percentage = totalFailed > 0 ? Number(((count / totalFailed) * 100).toFixed(1)) : 0;
    return {
      category: cat,
      label: details.label,
      count,
      percentage,
      color: details.color,
      textColor: details.textColor,
      borderColor: details.borderColor,
      bgColor: details.bgColor,
      description: details.rootCause,
    };
  });

  // Find dominant error category
  const activeGroups = groups.filter((g) => g.count > 0);
  activeGroups.sort((a, b) => b.count - a.count);
  const dominantErrorCategory = activeGroups.length > 0 ? activeGroups[0].category : null;

  return {
    totalFailed,
    oomCount,
    timeoutCount,
    apiErrorCount,
    decodeErrorCount,
    rateLimitCount,
    dominantErrorCategory,
    groups,
    classifiedJobs,
  };
}
