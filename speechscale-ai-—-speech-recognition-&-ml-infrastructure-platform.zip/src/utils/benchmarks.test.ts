import test from 'node:test';
import assert from 'node:assert/strict';
import { calculatePercentile, calculateRTF } from './benchmarks';

test('calculatePercentile computes p50, p90, p95, p99 correctly', () => {
  // Array from 1 to 100
  const values = Array.from({ length: 100 }, (_, i) => i + 1);
  assert.equal(calculatePercentile(values, 50), 51);
  assert.equal(calculatePercentile(values, 90), 90);
  assert.equal(calculatePercentile(values, 95), 95);
  assert.equal(calculatePercentile(values, 99), 99);
});

test('calculateRTF computes real time factor accurately', () => {
  // 3000ms inference for 30s audio = 3 / 30 = 0.1 RTF (10x faster than real-time)
  const rtf = calculateRTF(3000, 30);
  assert.equal(rtf, 0.1);

  // 15000ms inference for 10s audio = 15 / 10 = 1.5 RTF (slower than real-time)
  const rtfSlow = calculateRTF(15000, 10);
  assert.equal(rtfSlow, 1.5);
});
