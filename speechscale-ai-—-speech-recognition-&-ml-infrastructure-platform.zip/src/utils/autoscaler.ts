import { AutoscalingConfig, AutoscalerState } from '../types';

export interface AutoscalerEvaluationResult {
  targetWorkerDelta: number;
  action: 'SCALE_UP' | 'SCALE_DOWN' | 'NONE';
  reason: string;
  updatedState: AutoscalerState;
}

export const DEFAULT_AUTOSCALING_CONFIG: AutoscalingConfig = {
  enabled: true,
  metric: 'QUEUE_DEPTH',
  scaleUpThreshold: 10,
  scaleUpDurationSec: 5,
  scaleUpStep: 1,
  scaleUpCooldownSec: 10,
  scaleDownThreshold: 1,
  scaleDownDurationSec: 10,
  scaleDownStep: 1,
  scaleDownCooldownSec: 15,
  minWorkers: 2,
  maxWorkers: 8,
};

export const INITIAL_AUTOSCALER_STATE: AutoscalerState = {
  currentStage: 'MONITORING',
  conditionSustainedStartMs: null,
  lastScaleActionMs: null,
  lastAction: 'NONE',
  lastActionReason: 'Autoscaler initialized and monitoring telemetry',
  secondsSustained: 0,
};

/**
 * Pure function evaluating horizontal worker autoscaling rules.
 */
export function evaluateAutoscaler(
  currentWorkers: number,
  queueDepth: number,
  avgGpuLoad: number,
  config: AutoscalingConfig,
  state: AutoscalerState,
  nowMs: number
): AutoscalerEvaluationResult {
  if (!config.enabled) {
    return {
      targetWorkerDelta: 0,
      action: 'NONE',
      reason: 'HPA Autoscaler is currently disabled',
      updatedState: {
        ...state,
        currentStage: 'MONITORING',
        conditionSustainedStartMs: null,
        secondsSustained: 0,
      },
    };
  }

  // Check Cooldown Period
  if (state.lastScaleActionMs !== null) {
    const elapsedSinceLastScaleMs = nowMs - state.lastScaleActionMs;
    const cooldownMs = (state.lastAction === 'SCALE_UP' 
      ? config.scaleUpCooldownSec 
      : config.scaleDownCooldownSec) * 1000;

    if (elapsedSinceLastScaleMs < cooldownMs) {
      const remainingSec = Math.ceil((cooldownMs - elapsedSinceLastScaleMs) / 1000);
      return {
        targetWorkerDelta: 0,
        action: 'NONE',
        reason: `In cooldown period (${remainingSec}s remaining)`,
        updatedState: {
          ...state,
          currentStage: 'COOLDOWN',
          secondsSustained: 0,
          conditionSustainedStartMs: null,
        },
      };
    }
  }

  const metricVal = config.metric === 'QUEUE_DEPTH' ? queueDepth : avgGpuLoad;

  // 1. Evaluate Scale Up
  if (metricVal >= config.scaleUpThreshold) {
    if (currentWorkers >= config.maxWorkers) {
      return {
        targetWorkerDelta: 0,
        action: 'NONE',
        reason: `Max worker limit (${config.maxWorkers}) reached`,
        updatedState: {
          ...state,
          currentStage: 'MAX_REACHED',
          conditionSustainedStartMs: null,
          secondsSustained: 0,
        },
      };
    }

    const sustainedStart = state.conditionSustainedStartMs ?? nowMs;
    const elapsedSec = Math.max(0, Math.floor((nowMs - sustainedStart) / 1000));

    if (elapsedSec >= config.scaleUpDurationSec) {
      const delta = Math.min(config.scaleUpStep, config.maxWorkers - currentWorkers);
      const reason = `Auto-scale UP: ${config.metric} (${metricVal}) >= ${config.scaleUpThreshold} sustained for ${elapsedSec}s (added +${delta} worker)`;
      return {
        targetWorkerDelta: delta,
        action: 'SCALE_UP',
        reason,
        updatedState: {
          currentStage: 'COOLDOWN',
          conditionSustainedStartMs: null,
          lastScaleActionMs: nowMs,
          lastAction: 'SCALE_UP',
          lastActionReason: reason,
          secondsSustained: 0,
        },
      };
    }

    return {
      targetWorkerDelta: 0,
      action: 'NONE',
      reason: `Evaluating scale up: sustained for ${elapsedSec}s / ${config.scaleUpDurationSec}s`,
      updatedState: {
        ...state,
        currentStage: 'EVALUATING_SCALE_UP',
        conditionSustainedStartMs: sustainedStart,
        secondsSustained: elapsedSec,
      },
    };
  }

  // 2. Evaluate Scale Down
  if (metricVal <= config.scaleDownThreshold && currentWorkers > config.minWorkers) {
    const sustainedStart = state.conditionSustainedStartMs ?? nowMs;
    const elapsedSec = Math.max(0, Math.floor((nowMs - sustainedStart) / 1000));

    if (elapsedSec >= config.scaleDownDurationSec) {
      const delta = Math.min(config.scaleDownStep, currentWorkers - config.minWorkers);
      const reason = `Auto-scale DOWN: ${config.metric} (${metricVal}) <= ${config.scaleDownThreshold} idle for ${elapsedSec}s (drained -${delta} worker)`;
      return {
        targetWorkerDelta: -delta,
        action: 'SCALE_DOWN',
        reason,
        updatedState: {
          currentStage: 'COOLDOWN',
          conditionSustainedStartMs: null,
          lastScaleActionMs: nowMs,
          lastAction: 'SCALE_DOWN',
          lastActionReason: reason,
          secondsSustained: 0,
        },
      };
    }

    return {
      targetWorkerDelta: 0,
      action: 'NONE',
      reason: `Evaluating scale down: idle for ${elapsedSec}s / ${config.scaleDownDurationSec}s`,
      updatedState: {
        ...state,
        currentStage: 'EVALUATING_SCALE_DOWN',
        conditionSustainedStartMs: sustainedStart,
        secondsSustained: elapsedSec,
      },
    };
  }

  // 3. Stable State (Metric within acceptable threshold band)
  return {
    targetWorkerDelta: 0,
    action: 'NONE',
    reason: `Cluster workload nominal (${metricVal} ${config.metric.toLowerCase()})`,
    updatedState: {
      ...state,
      currentStage: currentWorkers <= config.minWorkers && metricVal <= config.scaleDownThreshold ? 'MIN_REACHED' : 'MONITORING',
      conditionSustainedStartMs: null,
      secondsSustained: 0,
    },
  };
}
