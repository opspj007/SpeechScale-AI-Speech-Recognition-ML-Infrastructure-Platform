import { WerResult, AlignmentWord } from '../types';
import { computeWER } from './wer';

export type ComparisonAlignmentWord = 
  | { type: 'match'; wordA: string; wordB: string; refWord: string }
  | { type: 'divergence'; wordA: string; wordB: string; refWord?: string; reason: string }
  | { type: 'a_only'; wordA: string; wordB?: undefined; refWord?: string }
  | { type: 'b_only'; wordA?: undefined; wordB: string; refWord?: string };

export interface ModelComparisonAnalysis {
  werA: WerResult;
  werB: WerResult;
  werDelta: number; // werA - werB (negative means Model A has lower error / better accuracy)
  cerDelta: number;
  winner: 'modelA' | 'modelB' | 'tie';
  winnerMargin: number;
  agreementRate: number; // percentage of words where Model A and Model B agree
  sharedErrorsCount: number; // errors made by both models
  uniqueErrorsA: number; // errors made only by model A
  uniqueErrorsB: number; // errors made only by model B
  detailedDifferences: {
    index: number;
    refFragment?: string;
    transcriptA: string;
    transcriptB: string;
    classification: 'both_correct' | 'a_superior' | 'b_superior' | 'both_errored';
    analysisNote: string;
  }[];
}

/**
 * Compares two model transcripts against a ground truth reference transcript.
 * Provides quantitative deltas, agreement metrics, and token-level alignment differences.
 */
export function compareModelTranscriptions(
  referenceText: string,
  transcriptA: string,
  transcriptB: string
): ModelComparisonAnalysis {
  const werA = computeWER(referenceText, transcriptA);
  const werB = computeWER(referenceText, transcriptB);

  const werDelta = Number((werA.wer - werB.wer).toFixed(2));
  const cerDelta = Number((werA.cer - werB.cer).toFixed(2));

  let winner: 'modelA' | 'modelB' | 'tie' = 'tie';
  if (werA.wer < werB.wer) {
    winner = 'modelA';
  } else if (werB.wer < werA.wer) {
    winner = 'modelB';
  }
  const winnerMargin = Math.abs(werDelta);

  // Compare alignments relative to reference
  // Extract reference-indexed error maps
  let sharedErrorsCount = 0;
  let uniqueErrorsA = 0;
  let uniqueErrorsB = 0;

  const maxAlignLen = Math.max(werA.alignments.length, werB.alignments.length);
  const detailedDifferences: ModelComparisonAnalysis['detailedDifferences'] = [];

  // Match aligned tokens by reference index
  let matchAgreements = 0;
  let totalEvaluatedTokens = Math.max(werA.refWordCount, 1);

  const aMap = new Map<number, AlignmentWord>();
  const bMap = new Map<number, AlignmentWord>();

  let refIdxA = 0;
  for (const item of werA.alignments) {
    if (item.refWord) {
      aMap.set(refIdxA, item);
      refIdxA++;
    }
  }

  let refIdxB = 0;
  for (const item of werB.alignments) {
    if (item.refWord) {
      bMap.set(refIdxB, item);
      refIdxB++;
    }
  }

  for (let r = 0; r < werA.refWordCount; r++) {
    const itemA = aMap.get(r);
    const itemB = bMap.get(r);

    const isMatchA = itemA?.type === 'match';
    const isMatchB = itemB?.type === 'match';

    const wordA = itemA?.hypWord || (itemA?.type === 'deletion' ? '[omitted]' : itemA?.refWord || '');
    const wordB = itemB?.hypWord || (itemB?.type === 'deletion' ? '[omitted]' : itemB?.refWord || '');
    const refW = itemA?.refWord || itemB?.refWord || '';

    if (isMatchA && isMatchB) {
      matchAgreements++;
      // both match reference
      if (r < 10 || r % 3 === 0) {
        detailedDifferences.push({
          index: r,
          refFragment: refW,
          transcriptA: wordA,
          transcriptB: wordB,
          classification: 'both_correct',
          analysisNote: 'Both models transcribed accurately.',
        });
      }
    } else if (isMatchA && !isMatchB) {
      uniqueErrorsB++;
      detailedDifferences.push({
        index: r,
        refFragment: refW,
        transcriptA: wordA,
        transcriptB: wordB,
        classification: 'a_superior',
        analysisNote: `Model A transcribed correctly as "${wordA}", while Model B had ${itemB?.type || 'error'}.`,
      });
    } else if (!isMatchA && isMatchB) {
      uniqueErrorsA++;
      detailedDifferences.push({
        index: r,
        refFragment: refW,
        transcriptA: wordA,
        transcriptB: wordB,
        classification: 'b_superior',
        analysisNote: `Model B transcribed correctly as "${wordB}", while Model A had ${itemA?.type || 'error'}.`,
      });
    } else {
      sharedErrorsCount++;
      detailedDifferences.push({
        index: r,
        refFragment: refW,
        transcriptA: wordA,
        transcriptB: wordB,
        classification: 'both_errored',
        analysisNote: `Acoustic difficulty: both models errored on reference "${refW}".`,
      });
    }
  }

  const agreementRate = Number(((matchAgreements / totalEvaluatedTokens) * 100).toFixed(1));

  return {
    werA,
    werB,
    werDelta,
    cerDelta,
    winner,
    winnerMargin,
    agreementRate,
    sharedErrorsCount,
    uniqueErrorsA,
    uniqueErrorsB,
    detailedDifferences,
  };
}
