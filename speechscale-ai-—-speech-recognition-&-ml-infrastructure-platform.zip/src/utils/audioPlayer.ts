/**
 * Audio synthesis and playback helper using Web Audio API and SpeechSynthesis
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioCtxClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Speaks text using browser SpeechSynthesis API, synchronized with a callback
 */
export function playSyntheticSpeech(
  text: string, 
  onBoundary?: (charIndex: number) => void, 
  onEnd?: () => void
): { stop: () => void } {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported');
    return { stop: () => {} };
  }

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.0;
  utterance.pitch = 1.0;

  if (onBoundary) {
    utterance.onboundary = (event) => {
      onBoundary(event.charIndex);
    };
  }

  if (onEnd) {
    utterance.onend = () => {
      onEnd();
    };
  }

  window.speechSynthesis.speak(utterance);

  return {
    stop: () => {
      window.speechSynthesis.cancel();
      if (onEnd) onEnd();
    }
  };
}

/**
 * Extracts a normalized 60-bar waveform array from an audio File or Blob
 */
export async function extractWaveformFromFile(file: File | Blob): Promise<number[]> {
  try {
    const ctx = getAudioContext();
    const arrayBuffer = await file.arrayBuffer();
    const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
    const rawData = audioBuffer.getChannelData(0);
    const samples = 60;
    const blockSize = Math.floor(rawData.length / samples);
    const waveform: number[] = [];

    for (let i = 0; i < samples; i++) {
      let blockStart = blockSize * i;
      let sum = 0;
      for (let j = 0; j < blockSize; j++) {
        sum += Math.abs(rawData[blockStart + j]);
      }
      waveform.push(Math.min(1.0, (sum / blockSize) * 2.5));
    }
    return waveform;
  } catch (err) {
    console.warn('Failed to decode waveform from audio file, using fallback pattern', err);
    return Array.from({ length: 60 }, (_, i) => 
      Math.abs(Math.sin(i * 0.2) * 0.7 + Math.random() * 0.3)
    );
  }
}
