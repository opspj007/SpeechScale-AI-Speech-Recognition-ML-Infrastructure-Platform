import test from 'node:test';
import assert from 'node:assert/strict';
import { compareModelTranscriptions } from './modelComparison';

test('compareModelTranscriptions identifies identical transcripts as tie', () => {
  const ref = 'cloud infrastructure revenue grew by thirty eight percent';
  const a = 'cloud infrastructure revenue grew by thirty eight percent';
  const b = 'cloud infrastructure revenue grew by thirty eight percent';

  const analysis = compareModelTranscriptions(ref, a, b);
  assert.equal(analysis.winner, 'tie');
  assert.equal(analysis.werA.wer, 0);
  assert.equal(analysis.werB.wer, 0);
  assert.equal(analysis.werDelta, 0);
  assert.equal(analysis.agreementRate, 100);
});

test('compareModelTranscriptions correctly designates winner and computes delta', () => {
  const ref = 'international wire transfer of four thousand dollars that has not cleared yet';
  const modelA = 'international wire transfer of four thousand dollars that has not cleared yet'; // 0% WER
  const modelB = 'international wire transfer of for thousand dollar that has not cleared yet'; // 2 subs

  const analysis = compareModelTranscriptions(ref, modelA, modelB);
  assert.equal(analysis.winner, 'modelA');
  assert.ok(analysis.werA.wer < analysis.werB.wer);
  assert.ok(analysis.werDelta < 0);
  assert.ok(analysis.uniqueErrorsB > 0);
});

test('compareModelTranscriptions calculates unique and shared errors accurately', () => {
  const ref = 'alpha beta gamma delta epsilon';
  const a = 'alpha beta wrong delta epsilon'; // 1 error (gamma->wrong)
  const b = 'alpha beta gamma missing epsilon'; // 1 error (delta->missing)

  const analysis = compareModelTranscriptions(ref, a, b);
  assert.equal(analysis.winner, 'tie');
  assert.equal(analysis.uniqueErrorsA, 1);
  assert.equal(analysis.uniqueErrorsB, 1);
});
