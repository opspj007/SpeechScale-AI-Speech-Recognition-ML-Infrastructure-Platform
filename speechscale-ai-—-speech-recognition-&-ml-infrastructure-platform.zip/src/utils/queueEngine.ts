import { InferenceJob, Priority, WorkerInstance } from '../types';

export const PRIORITY_WEIGHTS: Record<Priority, number> = {
  CRITICAL: 100,
  HIGH: 75,
  DEFAULT: 50,
  BATCH: 25,
};

/**
 * Calculates exponential backoff with jitter in milliseconds for retrying failed inference jobs.
 * Formula: baseDelay * 2^(retryCount - 1) + jitter
 */
export function calculateBackoffMs(retryCount: number, baseDelayMs: number = 200, maxDelayMs: number = 5000): number {
  if (retryCount <= 0) return 0;
  const exponential = baseDelayMs * Math.pow(2, retryCount - 1);
  const capped = Math.min(exponential, maxDelayMs);
  // deterministic base with slight jitter window
  const jitter = (retryCount * 37) % 50; 
  return capped + jitter;
}

/**
 * Sorts jobs by priority weight descending, then by creation timestamp ascending (FIFO within priority)
 */
export function sortQueueJobs(jobs: InferenceJob[]): InferenceJob[] {
  return [...jobs].sort((a, b) => {
    const weightA = PRIORITY_WEIGHTS[a.priority] || 0;
    const weightB = PRIORITY_WEIGHTS[b.priority] || 0;
    if (weightB !== weightA) {
      return weightB - weightA;
    }
    return a.createdAt - b.createdAt;
  });
}

/**
 * Checks if a running job has exceeded its execution timeout threshold.
 */
export function isJobTimedOut(job: InferenceJob, now: number): boolean {
  if (job.status !== 'INFERENCING' && job.status !== 'PREPROCESSING' && job.status !== 'ROUTING') {
    return false;
  }
  if (!job.startedAt) return false;
  return (now - job.startedAt) > job.timeoutMs;
}

/**
 * Finds the optimal worker for a job based on device capabilities, current load, and memory headroom.
 */
export function matchWorkerForJob(workers: WorkerInstance[], job: InferenceJob): WorkerInstance | null {
  const eligibleWorkers = workers.filter(w => w.status === 'IDLE');
  if (eligibleWorkers.length === 0) return null;

  // If job is large or critical, prioritize GPU worker with highest free VRAM
  return eligibleWorkers.sort((a, b) => {
    // Model match preference (avoids re-loading weights into VRAM)
    const aModelMatch = a.loadedModel === job.model ? 1 : 0;
    const bModelMatch = b.loadedModel === job.model ? 1 : 0;
    if (bModelMatch !== aModelMatch) return bModelMatch - aModelMatch;

    // Prefer GPU workers over CPU for medium/large models
    const aIsGpu = a.device.includes('NVIDIA') ? 1 : 0;
    const bIsGpu = b.device.includes('NVIDIA') ? 1 : 0;
    if (bIsGpu !== aIsGpu) return bIsGpu - aIsGpu;

    // Highest free VRAM
    const aFree = a.vramTotalMb - a.vramUsedMb;
    const bFree = b.vramTotalMb - b.vramUsedMb;
    return bFree - aFree;
  })[0];
}
