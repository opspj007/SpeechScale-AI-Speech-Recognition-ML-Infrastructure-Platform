import { ModelId, ServingEngine, Quantization } from '../types';
import { MODELS_CONFIG } from '../data/modelsConfig';

export interface HeatmapCellData {
  modelId: ModelId;
  modelName: string;
  concurrency: number;
  avgLatencyMs: number;
  p95LatencyMs: number;
  rtf: number;
  throughputRps: number;
  gpuMemoryMb: number;
  isSaturated: boolean;
  saturationRatio: number; // > 1.0 means saturated beyond capacity
  status: 'optimal' | 'moderate' | 'warning' | 'saturated';
  statusLabel: string;
  bottleneckReason: string;
}

export interface ModelSaturationKnee {
  modelId: ModelId;
  modelName: string;
  saturationConcurrency: number;
  kneeLatencyMs: number;
  isBreachedAtMaxLoad: boolean;
  maxThroughputRps: number;
  recommendedMaxConcurrency: number;
  insight: string;
}

export const HEATMAP_CONCURRENCY_LEVELS = [1, 5, 10, 20, 50, 100] as const;

export const HEATMAP_MODELS: ModelId[] = [
  'whisper-large-v3',
  'distil-whisper-v3',
  'whisper-medium',
  'whisper-small',
  'whisper-base',
  'whisper-tiny',
];

// Base latencies for single sequential stream (ms) on reference hardware (NVIDIA A100 / L40S)
const MODEL_BASE_LATENCY_MS: Record<ModelId, number> = {
  'whisper-large-v3': 1180,
  'distil-whisper-v3': 210,
  'whisper-medium': 640,
  'whisper-small': 275,
  'whisper-base': 115,
  'whisper-tiny': 55,
};

// Engine efficiency multipliers
const ENGINE_MULTIPLIERS: Record<ServingEngine, number> = {
  'tensorrt-llm': 0.38,  // TensorRT with in-flight batching & fused kernels
  'faster-whisper': 0.48, // CTranslate2 INT8/FP16 optimized runtime
  'onnx-runtime': 0.72,   // ONNX Runtime EP
  'pytorch-eager': 1.0,   // Baseline PyTorch SDPA
};

// Quantization multipliers
const QUANT_MULTIPLIERS: Record<Quantization, number> = {
  'int4': 0.58,
  'int8': 0.70,
  'fp16': 1.0,
  'fp32': 1.55,
};

// Concurrency capacity scale factor per model (how many parallel streams before queuing delay kicks in)
const MODEL_CONCURRENCY_HEADROOM: Record<ModelId, number> = {
  'whisper-tiny': 65,
  'whisper-base': 45,
  'whisper-small': 30,
  'whisper-medium': 16,
  'distil-whisper-v3': 38,
  'whisper-large-v3': 10,
};

/**
 * Computes deterministic latency and throughput for a specific model & concurrency.
 */
export function calculateHeatmapLatency(
  model: ModelId,
  concurrency: number,
  engine: ServingEngine = 'faster-whisper',
  quantization: Quantization = 'int8',
  slaTargetMs: number = 800
): HeatmapCellData {
  const modelSpec = MODELS_CONFIG[model];
  const modelName = modelSpec ? modelSpec.name : model;

  const baseLatency = MODEL_BASE_LATENCY_MS[model] * 
                      ENGINE_MULTIPLIERS[engine] * 
                      QUANT_MULTIPLIERS[quantization];

  // Headroom adjusted for engine batching efficiency
  const engineHeadroomBoost = engine === 'tensorrt-llm' ? 1.8 : engine === 'faster-whisper' ? 1.35 : 1.0;
  const quantHeadroomBoost = (quantization === 'int8' || quantization === 'int4') ? 1.3 : 1.0;
  const effectiveHeadroom = MODEL_CONCURRENCY_HEADROOM[model] * engineHeadroomBoost * quantHeadroomBoost;

  // Saturation dynamics:
  // When concurrency <= headroom: near-linear scaling, mild overhead ~1.5% per concurrency
  // When concurrency > headroom: queue delay dominates according to queueing theory
  let avgLatency: number;
  let p95Latency: number;
  let saturationRatio: number;

  if (concurrency <= effectiveHeadroom) {
    const loadFactor = concurrency / effectiveHeadroom;
    avgLatency = Math.round(baseLatency * (1 + loadFactor * 0.28));
    p95Latency = Math.round(avgLatency * 1.22);
    saturationRatio = Number((concurrency / effectiveHeadroom).toFixed(2));
  } else {
    // Queuing delay takes over exponentially beyond cluster capacity
    const overflowFactor = (concurrency - effectiveHeadroom) / effectiveHeadroom;
    const queueDelay = baseLatency * (overflowFactor * 1.6 + Math.pow(overflowFactor, 1.35) * 1.2);
    avgLatency = Math.round(baseLatency * 1.28 + queueDelay);
    p95Latency = Math.round(avgLatency * 1.45 + (overflowFactor * 180));
    saturationRatio = Number((concurrency / effectiveHeadroom).toFixed(2));
  }

  // 30-second standard audio segment benchmark
  const audioDurationSec = 30;
  const rtf = Number(((avgLatency / 1000) / audioDurationSec).toFixed(3));
  const throughputRps = Number(((concurrency * 1000) / avgLatency).toFixed(1));

  // Determine saturation and status
  const isSaturated = saturationRatio >= 1.0 || p95Latency > slaTargetMs;

  let status: 'optimal' | 'moderate' | 'warning' | 'saturated';
  let statusLabel: string;
  let bottleneckReason: string;

  if (saturationRatio >= 1.4 || p95Latency > slaTargetMs * 1.3) {
    status = 'saturated';
    statusLabel = 'Cluster Saturated';
    bottleneckReason = `Severe queue contention: load exceeds safe concurrency (${Math.round(effectiveHeadroom)}). p95 (${p95Latency}ms) breached SLA (${slaTargetMs}ms).`;
  } else if (saturationRatio >= 1.0 || p95Latency > slaTargetMs) {
    status = 'warning';
    statusLabel = 'Saturation Knee';
    bottleneckReason = `Approaching GPU compute & memory bus saturation. Latency climbing non-linearly.`;
  } else if (saturationRatio >= 0.6) {
    status = 'moderate';
    statusLabel = 'Balanced Load';
    bottleneckReason = `Linear queuing. GPU compute cores efficiently saturated with low wait time.`;
  } else {
    status = 'optimal';
    statusLabel = 'Optimal Headroom';
    bottleneckReason = `Sub-linear wait time. Plenty of worker thread and VRAM headroom.`;
  }

  // GPU Memory calculation based on model footprint & concurrency buffer
  const baseVram: Record<ModelId, number> = {
    'whisper-large-v3': 5200,
    'distil-whisper-v3': 2200,
    'whisper-medium': 2600,
    'whisper-small': 1100,
    'whisper-base': 450,
    'whisper-tiny': 280,
  };
  const vramMultiplier = (quantization === 'fp32' ? 1.9 : quantization === 'fp16' ? 1.0 : quantization === 'int8' ? 0.58 : 0.4);
  const gpuMemoryMb = Math.round(baseVram[model] * vramMultiplier + (concurrency * 32));

  return {
    modelId: model,
    modelName,
    concurrency,
    avgLatencyMs: avgLatency,
    p95LatencyMs: p95Latency,
    rtf,
    throughputRps,
    gpuMemoryMb,
    isSaturated,
    saturationRatio,
    status,
    statusLabel,
    bottleneckReason,
  };
}

/**
 * Generates the full 2D matrix (Models x Concurrency) for heatmap rendering.
 */
export function generateSaturationMatrix(
  engine: ServingEngine = 'faster-whisper',
  quantization: Quantization = 'int8',
  slaTargetMs: number = 800
): HeatmapCellData[] {
  const result: HeatmapCellData[] = [];

  for (const model of HEATMAP_MODELS) {
    for (const concurrency of HEATMAP_CONCURRENCY_LEVELS) {
      result.push(calculateHeatmapLatency(model, concurrency, engine, quantization, slaTargetMs));
    }
  }

  return result;
}

/**
 * Finds the saturation knee for each model under the chosen configuration.
 */
export function detectModelSaturationKnee(
  model: ModelId,
  engine: ServingEngine = 'faster-whisper',
  quantization: Quantization = 'int8',
  slaTargetMs: number = 800
): ModelSaturationKnee {
  const cells = HEATMAP_CONCURRENCY_LEVELS.map(c => 
    calculateHeatmapLatency(model, c, engine, quantization, slaTargetMs)
  );

  const modelSpec = MODELS_CONFIG[model];
  const modelName = modelSpec ? modelSpec.name : model;

  // Find the first concurrency level where status becomes warning or saturated, or SLA breached
  const kneeCell = cells.find(c => c.status === 'warning' || c.status === 'saturated' || c.p95LatencyMs > slaTargetMs);
  const maxThroughput = Math.max(...cells.map(c => c.throughputRps));
  
  if (kneeCell) {
    const recommended = Math.max(1, Math.round(kneeCell.concurrency * 0.75));
    return {
      modelId: model,
      modelName,
      saturationConcurrency: kneeCell.concurrency,
      kneeLatencyMs: kneeCell.avgLatencyMs,
      isBreachedAtMaxLoad: cells[cells.length - 1].p95LatencyMs > slaTargetMs,
      maxThroughputRps: maxThroughput,
      recommendedMaxConcurrency: recommended,
      insight: `Saturates at ~${kneeCell.concurrency} concurrent streams (${kneeCell.avgLatencyMs}ms avg). Recommended concurrency budget: ≤ ${recommended}.`,
    };
  }

  // Model does not saturate up to max concurrency
  return {
    modelId: model,
    modelName,
    saturationConcurrency: 100,
    kneeLatencyMs: cells[cells.length - 1].avgLatencyMs,
    isBreachedAtMaxLoad: false,
    maxThroughputRps: maxThroughput,
    recommendedMaxConcurrency: 100,
    insight: `High headroom: maintains sub-SLA latency through 100 concurrent streams. Peak throughput: ${maxThroughput} req/s.`,
  };
}

/**
 * Returns color tokens according to latency status and severity.
 */
export function getLatencyColorToken(status: HeatmapCellData['status']) {
  switch (status) {
    case 'optimal':
      return {
        bg: 'bg-emerald-950/70 hover:bg-emerald-900/80',
        border: 'border-emerald-600/60',
        text: 'text-emerald-300',
        fill: '#10b981',
        badgeBg: 'bg-emerald-900/50',
      };
    case 'moderate':
      return {
        bg: 'bg-cyan-950/70 hover:bg-cyan-900/80',
        border: 'border-cyan-600/60',
        text: 'text-cyan-300',
        fill: '#06b6d4',
        badgeBg: 'bg-cyan-900/50',
      };
    case 'warning':
      return {
        bg: 'bg-amber-950/70 hover:bg-amber-900/80',
        border: 'border-amber-600/60',
        text: 'text-amber-300',
        fill: '#f59e0b',
        badgeBg: 'bg-amber-900/50',
      };
    case 'saturated':
      return {
        bg: 'bg-rose-950/80 hover:bg-rose-900/90',
        border: 'border-rose-600/70',
        text: 'text-rose-300',
        fill: '#f43f5e',
        badgeBg: 'bg-rose-900/50',
      };
  }
}
