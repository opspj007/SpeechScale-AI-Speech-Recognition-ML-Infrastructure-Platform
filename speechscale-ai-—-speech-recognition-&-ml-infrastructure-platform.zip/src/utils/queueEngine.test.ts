import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBackoffMs, sortQueueJobs, isJobTimedOut, matchWorkerForJob } from './queueEngine';
import { InferenceJob, WorkerInstance } from '../types';

test('calculateBackoffMs computes exponential increase capped at maximum', () => {
  assert.equal(calculateBackoffMs(0), 0);
  const r1 = calculateBackoffMs(1, 200, 5000);
  const r2 = calculateBackoffMs(2, 200, 5000);
  const r3 = calculateBackoffMs(3, 200, 5000);

  // r1: base 200 * 2^0 = 200 + jitter(37) = 237
  assert.ok(r1 >= 200 && r1 < 300);
  // r2: base 200 * 2^1 = 400 + jitter(74%50=24) = 424
  assert.ok(r2 >= 400 && r2 < 500);
  // r3: base 200 * 2^2 = 800
  assert.ok(r3 >= 800 && r3 < 900);

  // Capped at maxDelay
  const rHigh = calculateBackoffMs(10, 200, 5000);
  assert.ok(rHigh <= 5050);
});

test('sortQueueJobs prioritizes CRITICAL > HIGH > DEFAULT > BATCH and FIFO within priority', () => {
  const jobBatch: InferenceJob = {
    id: '1', audioName: 'a', audioDurationSec: 5, model: 'whisper-tiny', engine: 'pytorch-eager',
    quantization: 'fp16', priority: 'BATCH', beamSize: 1, temperature: 0, vadFilter: true,
    diarization: false, status: 'QUEUED', progressPercent: 0, createdAt: 100, retryCount: 0,
    maxRetries: 3, timeoutMs: 5000,
  };
  const jobDefault: InferenceJob = {
    ...jobBatch, id: '2', priority: 'DEFAULT', createdAt: 200,
  };
  const jobCritical: InferenceJob = {
    ...jobBatch, id: '3', priority: 'CRITICAL', createdAt: 300,
  };
  const jobHighEarly: InferenceJob = {
    ...jobBatch, id: '4', priority: 'HIGH', createdAt: 50,
  };
  const jobHighLate: InferenceJob = {
    ...jobBatch, id: '5', priority: 'HIGH', createdAt: 150,
  };

  const sorted = sortQueueJobs([jobBatch, jobDefault, jobCritical, jobHighLate, jobHighEarly]);
  const sortedIds = sorted.map(j => j.id);
  assert.deepEqual(sortedIds, ['3', '4', '5', '2', '1']);
});

test('isJobTimedOut correctly detects timeout expiration', () => {
  const now = 10000;
  const runningJob: InferenceJob = {
    id: 'job-1', audioName: 'a', audioDurationSec: 10, model: 'whisper-large-v3', engine: 'pytorch-eager',
    quantization: 'fp16', priority: 'DEFAULT', beamSize: 1, temperature: 0, vadFilter: true,
    diarization: false, status: 'INFERENCING', progressPercent: 40, createdAt: 2000, startedAt: 3000,
    retryCount: 0, maxRetries: 3, timeoutMs: 5000, // started at 3000 + 5000 = 8000
  };

  assert.equal(isJobTimedOut(runningJob, now), true); // 10000 - 3000 = 7000 > 5000 -> true
  assert.equal(isJobTimedOut(runningJob, 6000), false); // 6000 - 3000 = 3000 < 5000 -> false

  const completedJob: InferenceJob = { ...runningJob, status: 'COMPLETED' };
  assert.equal(isJobTimedOut(completedJob, now), false);
});

test('matchWorkerForJob prefers worker with preloaded model and free VRAM', () => {
  const workers: WorkerInstance[] = [
    {
      id: 'worker-cpu', name: 'CPU Worker', device: 'AMD EPYC CPU', vramTotalMb: 16000,
      vramUsedMb: 2000, computeLoadPercent: 10, status: 'IDLE', totalJobsProcessed: 10,
      failedJobs: 0, uptimeSec: 1000, recentLatenciesMs: [250],
    },
    {
      id: 'worker-gpu-1', name: 'Worker A100-1', device: 'NVIDIA A100-80GB', vramTotalMb: 80000,
      vramUsedMb: 12000, computeLoadPercent: 0, status: 'IDLE', loadedModel: 'whisper-tiny',
      totalJobsProcessed: 50, failedJobs: 0, uptimeSec: 5000, recentLatenciesMs: [250],
    },
    {
      id: 'worker-gpu-2', name: 'Worker A100-2', device: 'NVIDIA A100-80GB', vramTotalMb: 80000,
      vramUsedMb: 14000, computeLoadPercent: 0, status: 'IDLE', loadedModel: 'whisper-large-v3',
      totalJobsProcessed: 80, failedJobs: 0, uptimeSec: 8000, recentLatenciesMs: [250],
    },
  ];

  const targetJob: InferenceJob = {
    id: 'test', audioName: 'a', audioDurationSec: 30, model: 'whisper-large-v3', engine: 'faster-whisper',
    quantization: 'int8', priority: 'HIGH', beamSize: 1, temperature: 0, vadFilter: true,
    diarization: false, status: 'QUEUED', progressPercent: 0, createdAt: 100, retryCount: 0,
    maxRetries: 3, timeoutMs: 10000,
  };

  const matched = matchWorkerForJob(workers, targetJob);
  assert.ok(matched !== null);
  // Should match worker-gpu-2 because it already has whisper-large-v3 loaded!
  assert.equal(matched?.id, 'worker-gpu-2');
});
