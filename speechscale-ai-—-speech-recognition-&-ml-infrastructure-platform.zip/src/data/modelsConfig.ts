import { ModelId, ServingEngine, Quantization } from '../types';

export interface ModelSpec {
  id: ModelId;
  name: string;
  parameters: string;
  vramFp16: string;
  vramInt8: string;
  relativeSpeed: string;
  typicalRtf: number;
  werClean: number;
  werNoisy: number;
  recommendedBatch: number;
  description: string;
  architecture: string;
}

export const MODELS_CONFIG: Record<ModelId, ModelSpec> = {
  'whisper-large-v3': {
    id: 'whisper-large-v3',
    name: 'Whisper Large-v3',
    parameters: '1,550M',
    vramFp16: '9.8 GB',
    vramInt8: '4.9 GB',
    relativeSpeed: '1.0x (Baseline)',
    typicalRtf: 0.045,
    werClean: 1.8,
    werNoisy: 5.4,
    recommendedBatch: 16,
    description: 'State-of-the-art multilingual accuracy, 128 Mel channels, enhanced timestamp accuracy and robust noise handling.',
    architecture: 'Transformer (32 encoder layers, 32 decoder layers, 1280 hidden dim)',
  },
  'distil-whisper-v3': {
    id: 'distil-whisper-v3',
    name: 'Distil-Whisper-v3 (Large)',
    parameters: '756M',
    vramFp16: '4.2 GB',
    vramInt8: '2.1 GB',
    relativeSpeed: '5.8x faster',
    typicalRtf: 0.008,
    werClean: 2.1,
    werNoisy: 6.2,
    recommendedBatch: 32,
    description: 'Distilled student model from large-v3 retaining >98% accuracy while running 6x faster with 50% less VRAM.',
    architecture: 'Distilled Transformer (32 encoder layers, 2 decoder layers, speculative decoding)',
  },
  'whisper-medium': {
    id: 'whisper-medium',
    name: 'Whisper Medium',
    parameters: '769M',
    vramFp16: '4.8 GB',
    vramInt8: '2.4 GB',
    relativeSpeed: '2.2x faster',
    typicalRtf: 0.022,
    werClean: 2.9,
    werNoisy: 8.1,
    recommendedBatch: 32,
    description: 'Balanced production model for medium latency SLAs with strong multilingual support.',
    architecture: 'Transformer (24 encoder layers, 24 decoder layers, 1024 hidden dim)',
  },
  'whisper-small': {
    id: 'whisper-small',
    name: 'Whisper Small',
    parameters: '244M',
    vramFp16: '1.9 GB',
    vramInt8: '0.9 GB',
    relativeSpeed: '4.5x faster',
    typicalRtf: 0.010,
    werClean: 3.8,
    werNoisy: 11.2,
    recommendedBatch: 64,
    description: 'Lightweight model suitable for high-throughput batch transcoding and edge GPU nodes.',
    architecture: 'Transformer (12 encoder layers, 12 decoder layers, 768 hidden dim)',
  },
  'whisper-base': {
    id: 'whisper-base',
    name: 'Whisper Base',
    parameters: '74M',
    vramFp16: '0.8 GB',
    vramInt8: '0.4 GB',
    relativeSpeed: '10.5x faster',
    typicalRtf: 0.004,
    werClean: 5.6,
    werNoisy: 15.9,
    recommendedBatch: 128,
    description: 'Ultra-fast low-resource model for basic command-and-control and quick voice search.',
    architecture: 'Transformer (6 encoder layers, 6 decoder layers, 512 hidden dim)',
  },
  'whisper-tiny': {
    id: 'whisper-tiny',
    name: 'Whisper Tiny',
    parameters: '39M',
    vramFp16: '0.5 GB',
    vramInt8: '0.25 GB',
    relativeSpeed: '18.0x faster',
    typicalRtf: 0.002,
    werClean: 7.9,
    werNoisy: 21.4,
    recommendedBatch: 256,
    description: 'Minimal parameter footprint, runs on CPU or low-end edge accelerators with microsecond latency.',
    architecture: 'Transformer (4 encoder layers, 4 decoder layers, 384 hidden dim)',
  },
};

export const ENGINES_CONFIG: Record<ServingEngine, { name: string; backend: string; throughputGain: string; description: string }> = {
  'faster-whisper': {
    name: 'Faster-Whisper (CTranslate2)',
    backend: 'Custom C++ inference engine with INT8 matrix multiplication',
    throughputGain: 'up to 4.2x vs PyTorch',
    description: 'Memory-efficient CTranslate2 runtime utilizing cuBLAS INT8 GEMM kernels and dynamic continuous batching.',
  },
  'tensorrt-llm': {
    name: 'TensorRT-LLM (NVIDIA)',
    backend: 'NVIDIA TensorRT with In-flight Batching and FP8/INT8 kernels',
    throughputGain: 'up to 5.5x vs PyTorch',
    description: 'Kernel fusion, paged KV caching, and multi-stream execution optimized for modern NVIDIA Ada/Hopper architectures.',
  },
  'pytorch-eager': {
    name: 'PyTorch Eager (TorchScript / SDPA)',
    backend: 'Native PyTorch with FlashAttention / Scaled Dot-Product Attention',
    throughputGain: '1.0x baseline',
    description: 'Standard PyTorch implementation with torch.compile() and automatic mixed precision (AMP fp16).',
  },
  'onnx-runtime': {
    name: 'ONNX Runtime (DirectML / TensorRT EP)',
    backend: 'ONNX graph execution provider with graph rewrites and constant folding',
    throughputGain: 'up to 2.1x vs PyTorch',
    description: 'Hardware-agnostic graph runtime supporting CPU, AMD ROCm, and NVIDIA CUDA execution providers.',
  },
};

export const DATASET_EVALUATIONS = [
  {
    dataset: 'LibriSpeech (test-clean)',
    domain: 'Clean Studio Audiobooks',
    audioHours: '5.4 hrs',
    largeV3Wer: 1.8,
    distilWer: 2.1,
    mediumWer: 2.9,
    smallWer: 3.8,
    tinyWer: 7.9,
  },
  {
    dataset: 'LibriSpeech (test-other)',
    domain: 'Acoustic Noise & Accents',
    audioHours: '5.3 hrs',
    largeV3Wer: 3.7,
    distilWer: 4.3,
    mediumWer: 5.8,
    smallWer: 8.4,
    tinyWer: 16.2,
  },
  {
    dataset: 'Common Voice 15 (English)',
    domain: 'Crowdsourced Real-World Mics',
    audioHours: '28.0 hrs',
    largeV3Wer: 6.2,
    distilWer: 6.9,
    mediumWer: 8.7,
    smallWer: 12.1,
    tinyWer: 22.5,
  },
  {
    dataset: 'CallHome (Telephone 8kHz)',
    domain: 'Narrowband Conversational Speech',
    audioHours: '12.5 hrs',
    largeV3Wer: 11.4,
    distilWer: 12.6,
    mediumWer: 15.2,
    smallWer: 19.8,
    tinyWer: 33.1,
  },
  {
    dataset: 'FLEURS (Accented Global)',
    domain: 'Global Accented English Dialects',
    audioHours: '15.0 hrs',
    largeV3Wer: 4.9,
    distilWer: 5.6,
    mediumWer: 7.3,
    smallWer: 10.5,
    tinyWer: 19.4,
  },
];
