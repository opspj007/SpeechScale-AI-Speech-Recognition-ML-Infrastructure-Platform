import React, { useState } from 'react';
import { 
  BarChart3, 
  Play, 
  RotateCcw, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  Cpu, 
  Gauge, 
  Clock, 
  Layers, 
  TrendingUp, 
  Sliders,
  History,
  Info
} from 'lucide-react';
import { BenchmarkRun, ModelId, ServingEngine, Quantization } from '../types';
import { simulateBenchmarkRun } from '../utils/benchmarks';
import { MODELS_CONFIG } from '../data/modelsConfig';
import { LatencyHeatmap } from './LatencyHeatmap';

interface BenchmarkingSuiteProps {
  benchmarkHistory: BenchmarkRun[];
  onAddBenchmark: (run: BenchmarkRun) => void;
  onClearHistory: () => void;
}

export const BenchmarkingSuite: React.FC<BenchmarkingSuiteProps> = ({
  benchmarkHistory,
  onAddBenchmark,
  onClearHistory,
}) => {
  const [concurrency, setConcurrency] = useState<number>(20);
  const [requestsCount, setRequestsCount] = useState<number>(100);
  const [model, setModel] = useState<ModelId>('whisper-large-v3');
  const [engine, setEngine] = useState<ServingEngine>('faster-whisper');
  const [quantization, setQuantization] = useState<Quantization>('int8');
  const [slaTargetMs, setSlaTargetMs] = useState<number>(800);

  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [currentRun, setCurrentRun] = useState<BenchmarkRun | null>(
    benchmarkHistory[0] || null
  );

  const handleApplyHeatmapConfig = (
    selectedModel: ModelId,
    selectedConcurrency: number,
    selectedEngine: ServingEngine,
    selectedQuant: Quantization
  ) => {
    setModel(selectedModel);
    setConcurrency(selectedConcurrency);
    setEngine(selectedEngine);
    setQuantization(selectedQuant);
  };

  const handleStartBenchmark = () => {
    setIsRunning(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRunning(false);

          const result = simulateBenchmarkRun(
            concurrency,
            requestsCount,
            model,
            engine,
            quantization,
            slaTargetMs
          );
          setCurrentRun(result);
          onAddBenchmark(result);
          return 100;
        }
        return prev + 15;
      });
    }, 120);
  };

  // Bottleneck analyzer logic
  const analyzeBottlenecks = (run: BenchmarkRun) => {
    if (run.engine === 'pytorch-eager' && run.quantization === 'fp32') {
      return {
        type: 'Memory Bandwidth & Precision Bound',
        severity: 'HIGH',
        diagnosis: 'PyTorch Eager FP32 unquantized weights cause heavy VRAM memory bandwidth saturation during token-by-token autoregressive decoding.',
        fix: 'Switch serving backend to Faster-Whisper (CTranslate2) with INT8 quantization to cut latency by ~60% and double throughput.',
      };
    }
    if (run.concurrency >= 50 && run.avgGpuLoad > 90) {
      return {
        type: 'GPU Compute Saturation (Queuing Delay)',
        severity: 'MEDIUM',
        diagnosis: `At concurrency level ${run.concurrency}, queue wait time exceeds inference compute time. Worker thread contention on GPU streams.`,
        fix: 'Scale worker pool from 4 to 8 instances or enable TensorRT-LLM in-flight batching to pipeline concurrent requests.',
      };
    }
    if (run.model === 'whisper-large-v3' && run.p95Ms > run.slaTargetMs) {
      return {
        type: 'SLA Latency Budget Breach',
        severity: 'MEDIUM',
        diagnosis: `p95 Latency (${run.p95Ms}ms) breached SLA target of ${run.slaTargetMs}ms for 1.55B parameter model under load.`,
        fix: 'Evaluate Distil-Whisper-v3 which retains 98% accuracy while running 5.8x faster, or lower beam size to 1.',
      };
    }
    return {
      type: 'Optimal Pipeline Equilibrium',
      severity: 'OPTIMAL',
      diagnosis: 'Serving engine, quantization, and worker concurrency are well-balanced. Sub-millisecond queue latency with 99%+ SLA compliance.',
      fix: 'Current configuration meets high-throughput production SLA requirements.',
    };
  };

  const bottleneck = currentRun ? analyzeBottlenecks(currentRun) : null;

  return (
    <div className="space-y-6">
      {/* Configuration & Controls */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-base text-white">Repeatable Performance Benchmarking Pipeline</h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Evaluate p95 latency, throughput, resource utilization, and inference reliability under concurrent workloads
            </p>
          </div>

          <button
            onClick={handleStartBenchmark}
            disabled={isRunning}
            className="py-2.5 px-5 rounded-lg bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Running Benchmark ({progress}%)...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>Run Concurrent Load Benchmark</span>
              </>
            )}
          </button>
        </div>

        {/* Inputs Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          {/* Concurrency */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Concurrency</label>
            <select
              value={concurrency}
              onChange={(e) => setConcurrency(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              <option value="5">5 Concurrency</option>
              <option value="20">20 Concurrency</option>
              <option value="50">50 Concurrency</option>
              <option value="100">100 Concurrency</option>
            </select>
          </div>

          {/* Requests Count */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Workload Batch</label>
            <select
              value={requestsCount}
              onChange={(e) => setRequestsCount(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              <option value="50">50 Requests</option>
              <option value="100">100 Requests</option>
              <option value="250">250 Requests</option>
              <option value="500">500 Requests</option>
            </select>
          </div>

          {/* Model */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Whisper Model</label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value as ModelId)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              {Object.values(MODELS_CONFIG).map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          {/* Serving Engine */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Serving Engine</label>
            <select
              value={engine}
              onChange={(e) => setEngine(e.target.value as ServingEngine)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              <option value="faster-whisper">Faster-Whisper (CTranslate2)</option>
              <option value="tensorrt-llm">TensorRT-LLM</option>
              <option value="pytorch-eager">PyTorch Eager</option>
              <option value="onnx-runtime">ONNX Runtime</option>
            </select>
          </div>

          {/* Quantization */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Quantization</label>
            <select
              value={quantization}
              onChange={(e) => setQuantization(e.target.value as Quantization)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              <option value="int8">INT8 (Quantized)</option>
              <option value="fp16">FP16 (Half Precision)</option>
              <option value="fp32">FP32 (Single)</option>
              <option value="int4">INT4 (Ultra Compact)</option>
            </select>
          </div>

          {/* SLA Target */}
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">SLA Target (p95)</label>
            <select
              value={slaTargetMs}
              onChange={(e) => setSlaTargetMs(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
            >
              <option value="500">&lt; 500 ms</option>
              <option value="800">&lt; 800 ms (Standard)</option>
              <option value="1200">&lt; 1,200 ms</option>
              <option value="2000">&lt; 2,000 ms</option>
            </select>
          </div>
        </div>

        {/* Progress Bar when running */}
        {isRunning && (
          <div className="mt-4 space-y-1.5">
            <div className="flex justify-between text-xs text-cyan-400 font-mono">
              <span>Simulating {requestsCount} concurrent audio stream transcriptions...</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden">
              <div
                style={{ width: `${progress}%` }}
                className="bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-400 h-full transition-all duration-150"
              />
            </div>
          </div>
        )}
      </div>

      {/* Model Latency vs Concurrent Load Saturation Heatmap & Knee Analyzer */}
      <LatencyHeatmap
        currentEngine={engine}
        currentQuantization={quantization}
        currentSlaMs={slaTargetMs}
        onApplyConfig={handleApplyHeatmapConfig}
      />

      {/* Benchmark Results Display */}
      {currentRun && (
        <div className="space-y-6">
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {/* p95 Latency */}
            <div className={`p-4 rounded-xl border ${
              currentRun.p95Ms <= currentRun.slaTargetMs
                ? 'bg-emerald-950/20 border-emerald-800/60'
                : 'bg-red-950/20 border-red-800/60'
            }`}>
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>p95 Latency</span>
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                {currentRun.p95Ms} <span className="text-xs font-normal text-slate-400">ms</span>
              </div>
              <div className="flex items-center gap-1 text-[10px] mt-1 font-semibold">
                {currentRun.p95Ms <= currentRun.slaTargetMs ? (
                  <span className="text-emerald-400 flex items-center gap-0.5">
                    <CheckCircle2 className="w-3 h-3" /> SLA Passed (&lt;{currentRun.slaTargetMs}ms)
                  </span>
                ) : (
                  <span className="text-red-400 flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3" /> SLA Breached
                  </span>
                )}
              </div>
            </div>

            {/* p50 Median */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>p50 Median</span>
                <Zap className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                {currentRun.p50Ms} <span className="text-xs font-normal text-slate-400">ms</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                p90: {currentRun.p90Ms}ms &bull; p99: {currentRun.p99Ms}ms
              </div>
            </div>

            {/* Throughput RPS */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>Throughput</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {currentRun.throughputRps} <span className="text-xs font-normal text-slate-400">req/s</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                {currentRun.audioMinutesPerMinute} audio mins/min
              </div>
            </div>

            {/* Real Time Factor (RTF) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>Real Time Factor</span>
                <Gauge className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-purple-300 mt-1">
                {currentRun.meanRtf}x
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                {Math.round(1 / currentRun.meanRtf)}x faster than real-time
              </div>
            </div>

            {/* GPU Memory (VRAM) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>VRAM Allocation</span>
                <Layers className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-amber-300 mt-1">
                {(currentRun.avgVramMb / 1024).toFixed(1)} <span className="text-xs font-normal text-slate-400">GB</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                {currentRun.avgVramMb} MB active
              </div>
            </div>

            {/* Inference Reliability */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
              <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
                <span>Reliability</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">
                {currentRun.successRate}%
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                0 timeouts &bull; 0 retries
              </div>
            </div>
          </div>

          {/* Latency Waterfall & Percentile Curve Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Latency Waterfall Breakdown */}
            <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <h4 className="font-semibold text-sm text-white">End-to-End Latency Waterfall Breakdown</h4>
                </div>
                <span className="font-mono text-xs text-slate-400">Total: {currentRun.p50Ms}ms</span>
              </div>

              {/* Waterfall items */}
              <div className="space-y-3 text-xs">
                {[
                  { stage: '1. HTTP Gateway Ingest & Redis Stream XADD', ms: Math.round(currentRun.p50Ms * 0.08), color: 'bg-blue-500', desc: 'FastAPI async route + client socket transport' },
                  { stage: '2. Queue Wait & Worker Scheduling', ms: Math.round(currentRun.p50Ms * 0.12), color: 'bg-indigo-500', desc: 'Redis consumer group XREADGROUP + backoff check' },
                  { stage: '3. Audio Decoding & Silero-VAD Preprocessing', ms: Math.round(currentRun.p50Ms * 0.15), color: 'bg-cyan-500', desc: 'FFmpeg 16kHz resampling + silence suppression' },
                  { stage: '4. Transformer Acoustic Encoder Pass', ms: Math.round(currentRun.p50Ms * 0.28), color: 'bg-emerald-500', desc: 'Mel-spectrogram (128-ch) + 32-layer conv/attention' },
                  { stage: '5. Autoregressive Text Token Decoder', ms: Math.round(currentRun.p50Ms * 0.37), color: 'bg-purple-500', desc: 'Cross-attention KV-cache token sampling & beam search' },
                ].map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-medium text-slate-200">{item.stage}</span>
                      <span className="font-mono font-bold text-white">{item.ms} ms</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden flex">
                      <div
                        style={{ width: `${(item.ms / currentRun.p50Ms) * 100}%` }}
                        className={`${item.color} h-full rounded-full`}
                      />
                    </div>
                    <div className="text-[10px] text-slate-400">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Bottleneck Diagnostics & Optimization Recommendations */}
            <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3 border-b border-slate-800 pb-2">
                  <Info className="w-4 h-4 text-amber-400" />
                  <h4 className="font-semibold text-sm text-white">Performance Bottleneck Diagnosis</h4>
                </div>

                {bottleneck && (
                  <div className="space-y-3 text-xs">
                    <div className="p-3 rounded-lg border border-amber-900/60 bg-amber-950/20">
                      <div className="flex items-center justify-between text-xs font-semibold text-amber-300 mb-1">
                        <span>{bottleneck.type}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-900/80 font-mono">
                          {bottleneck.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        {bottleneck.diagnosis}
                      </p>
                    </div>

                    <div className="p-3 rounded-lg border border-cyan-900/60 bg-cyan-950/20">
                      <div className="text-xs font-semibold text-cyan-300 mb-1">
                        Recommended Architectural Action:
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        {bottleneck.fix}
                      </p>
                    </div>

                    <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                      <div className="font-semibold text-slate-300">Serving Config Under Test:</div>
                      <div>&bull; Model: {MODELS_CONFIG[currentRun.model].name}</div>
                      <div>&bull; Serving Engine: {currentRun.engine} ({currentRun.quantization})</div>
                      <div>&bull; Workload: {currentRun.requestsCount} requests @ {currentRun.concurrency} concurrent streams</div>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-800/80 mt-4 flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Run ID: {currentRun.id}</span>
                <span>{new Date(currentRun.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          </div>

          {/* Benchmark Runs Comparison Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-blue-400" />
                <h4 className="font-semibold text-sm text-white">Repeatable Benchmark Run History &amp; Comparisons</h4>
              </div>
              <button
                onClick={onClearHistory}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
              >
                Clear Runs
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Model</th>
                    <th className="py-2.5 px-3">Engine &amp; Quant</th>
                    <th className="py-2.5 px-3">Concurrency</th>
                    <th className="py-2.5 px-3">p50</th>
                    <th className="py-2.5 px-3">p95 Latency</th>
                    <th className="py-2.5 px-3">Throughput</th>
                    <th className="py-2.5 px-3">RTF</th>
                    <th className="py-2.5 px-3">VRAM</th>
                    <th className="py-2.5 px-3">SLA Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {benchmarkHistory.map((run) => (
                    <tr 
                      key={run.id}
                      onClick={() => setCurrentRun(run)}
                      className={`hover:bg-slate-800/40 cursor-pointer transition-colors ${
                        currentRun.id === run.id ? 'bg-blue-950/30' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-semibold text-white">
                        {run.model}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-400">
                        {run.engine} &bull; {run.quantization}
                      </td>
                      <td className="py-2.5 px-3 font-mono">
                        {run.concurrency} streams ({run.requestsCount} reqs)
                      </td>
                      <td className="py-2.5 px-3 font-mono">
                        {run.p50Ms}ms
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-white">
                        {run.p95Ms}ms
                      </td>
                      <td className="py-2.5 px-3 font-mono text-emerald-400">
                        {run.throughputRps} rps
                      </td>
                      <td className="py-2.5 px-3 font-mono text-purple-300">
                        {run.meanRtf}x
                      </td>
                      <td className="py-2.5 px-3 font-mono text-amber-300">
                        {run.avgVramMb} MB
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          run.p95Ms <= run.slaTargetMs
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-red-950 text-red-400 border border-red-800'
                        }`}>
                          {run.p95Ms <= run.slaTargetMs ? 'PASSED' : 'BREACHED'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
