import React, { useState, useEffect } from 'react';
import { 
  Gauge, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  TrendingUp, 
  Clock, 
  Layers, 
  Cpu, 
  Terminal,
  Filter
} from 'lucide-react';

export const GrafanaDashboard: React.FC = () => {
  const [timeRange, setTimeRange] = useState<string>('5m');
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);
  const [activePromql, setActivePromql] = useState<string>(
    'histogram_quantile(0.95, sum(rate(speechscale_inference_seconds_bucket[1m])) by (le, model))'
  );
  const [showRawMetrics, setShowRawMetrics] = useState<boolean>(false);

  // Time-series points generator
  const [latencySeries, setLatencySeries] = useState<number[]>([
    240, 255, 230, 260, 280, 275, 290, 310, 295, 305, 320, 280, 265, 290, 310
  ]);
  const [queueSeries, setQueueSeries] = useState<number[]>([
    2, 4, 3, 5, 8, 12, 9, 6, 4, 5, 7, 3, 2, 4, 3
  ]);
  const [gpuSeries, setGpuSeries] = useState<number[]>([
    58, 62, 60, 65, 74, 82, 78, 69, 64, 66, 70, 63, 61, 65, 68
  ]);

  // Live pulse updates if autoRefresh is on
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      setLatencySeries((prev) => {
        const last = prev[prev.length - 1];
        const next = Math.max(180, Math.min(480, last + (Math.random() - 0.48) * 35));
        return [...prev.slice(1), Math.round(next)];
      });
      setQueueSeries((prev) => {
        const last = prev[prev.length - 1];
        const next = Math.max(1, Math.min(25, last + Math.round((Math.random() - 0.48) * 3)));
        return [...prev.slice(1), next];
      });
      setGpuSeries((prev) => {
        const last = prev[prev.length - 1];
        const next = Math.max(45, Math.min(95, last + (Math.random() - 0.48) * 8));
        return [...prev.slice(1), Math.round(next)];
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const rawPrometheusMetrics = `# HELP speechscale_inference_seconds Speech-to-text inference latency in seconds
# TYPE speechscale_inference_seconds histogram
speechscale_inference_seconds_bucket{le="0.1",model="distil-whisper-v3",engine="faster-whisper"} 1420
speechscale_inference_seconds_bucket{le="0.25",model="distil-whisper-v3",engine="faster-whisper"} 3890
speechscale_inference_seconds_bucket{le="0.5",model="distil-whisper-v3",engine="faster-whisper"} 4210
speechscale_inference_seconds_bucket{le="0.8",model="whisper-large-v3",engine="faster-whisper"} 5120
speechscale_inference_seconds_bucket{le="1.2",model="whisper-large-v3",engine="faster-whisper"} 6830
speechscale_inference_seconds_bucket{le="+Inf",model="whisper-large-v3"} 6850
speechscale_inference_seconds_sum{model="whisper-large-v3"} 4219.45
speechscale_inference_seconds_count{model="whisper-large-v3"} 6850

# HELP speechscale_worker_gpu_vram_bytes VRAM allocation per worker
# TYPE speechscale_worker_gpu_vram_bytes gauge
speechscale_worker_gpu_vram_bytes{worker="worker-01",gpu="A100-80GB"} 14680064000
speechscale_worker_gpu_vram_bytes{worker="worker-02",gpu="A100-80GB"} 12582912000
speechscale_worker_gpu_vram_bytes{worker="worker-03",gpu="T4-16GB"} 4823449600

# HELP speechscale_redis_queue_depth Pending audio jobs in Redis Stream
# TYPE speechscale_redis_queue_depth gauge
speechscale_redis_queue_depth{priority="critical"} 0
speechscale_redis_queue_depth{priority="high"} 2
speechscale_redis_queue_depth{priority="default"} 5
speechscale_redis_queue_depth{priority="batch"} 18

# HELP speechscale_transcription_requests_total Total audio requests processed
# TYPE speechscale_transcription_requests_total counter
speechscale_transcription_requests_total{status="200",model="whisper-large-v3"} 12480
speechscale_transcription_requests_total{status="504_timeout",model="whisper-large-v3"} 2
speechscale_transcription_requests_total{status="retry_oom",model="whisper-large-v3"} 1`;

  return (
    <div className="space-y-6">
      {/* Grafana Navigation & PromQL Query Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-orange-600/20 border border-orange-500/40 flex items-center justify-center">
              <Gauge className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">Grafana ML Telemetry Dashboard</h3>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-orange-950 text-orange-400 border border-orange-800 font-mono">
                  Prometheus 2.45
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Live metrics scraped at 1s intervals from /metrics FastAPI Prometheus endpoint
              </p>
            </div>
          </div>

          {/* Time range & controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded p-0.5 text-xs">
              {(['5m', '15m', '1h', '6h', '24h'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setTimeRange(r)}
                  className={`px-2 py-1 rounded text-[11px] font-mono cursor-pointer transition-all ${
                    timeRange === r ? 'bg-orange-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>

            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono cursor-pointer transition-all ${
                autoRefresh
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-400'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${autoRefresh ? 'animate-spin' : ''}`} />
              <span>{autoRefresh ? 'Auto-refresh: 2s' : 'Paused'}</span>
            </button>

            <button
              onClick={() => setShowRawMetrics(!showRawMetrics)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>{showRawMetrics ? 'Hide /metrics' : 'View /metrics'}</span>
            </button>
          </div>
        </div>

        {/* PromQL Query Bar */}
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs font-mono">
          <span className="text-orange-400 font-bold px-1.5 py-0.5 rounded bg-orange-950/80 border border-orange-800/60 text-[10px]">
            PromQL
          </span>
          <input
            type="text"
            value={activePromql}
            onChange={(e) => setActivePromql(e.target.value)}
            className="flex-1 bg-transparent text-slate-200 focus:outline-none text-xs"
          />
        </div>
      </div>

      {/* Raw Metrics Dropdown */}
      {showRawMetrics && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 shadow-inner">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-2 font-mono">
            <span>GET https://api.speechscale.internal:8000/metrics</span>
            <span>HTTP 200 OK &bull; text/plain; version=0.0.4</span>
          </div>
          <pre className="text-[11px] font-mono text-emerald-300 max-h-52 overflow-y-auto bg-slate-900/90 p-3 rounded-lg border border-slate-800 select-text">
            {rawPrometheusMetrics}
          </pre>
        </div>
      )}

      {/* Grafana Grid Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Panel 1: p95 Inference Latency */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-semibold text-white">p95 Inference Latency (ms)</span>
              <Clock className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-white">
                {latencySeries[latencySeries.length - 1]} ms
              </span>
              <span className="text-xs text-emerald-400 font-mono font-medium">SLA: &lt; 800ms</span>
            </div>
          </div>

          {/* SVG Mini Time Series Sparkline */}
          <div className="h-24 w-full mt-3 flex items-end gap-1">
            {latencySeries.map((val, idx) => {
              const heightPercent = Math.min(100, (val / 500) * 100);
              return (
                <div key={idx} className="flex-1 h-full flex flex-col justify-end items-center group relative">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className="w-full bg-cyan-500/80 hover:bg-cyan-400 rounded-t transition-all duration-200"
                  />
                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-1 hidden group-hover:block bg-slate-950 text-cyan-300 font-mono text-[10px] px-1 py-0.5 rounded border border-slate-700 whitespace-nowrap z-10">
                    {val}ms
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-2 pt-2 border-t border-slate-800/80">
            <span>-{timeRange}</span>
            <span>Now</span>
          </div>
        </div>

        {/* Panel 2: Queue Depth (Redis Stream) */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-semibold text-white">Redis Queue Depth (Pending)</span>
              <Layers className="w-4 h-4 text-blue-400" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-blue-400">
                {queueSeries[queueSeries.length - 1]} jobs
              </span>
              <span className="text-xs text-slate-400 font-mono">Consumer Lag &lt; 0.2s</span>
            </div>
          </div>

          {/* SVG Sparkline */}
          <div className="h-24 w-full mt-3 flex items-end gap-1">
            {queueSeries.map((val, idx) => {
              const heightPercent = Math.min(100, (val / 20) * 100);
              return (
                <div key={idx} className="flex-1 h-full flex flex-col justify-end items-center group relative">
                  <div
                    style={{ height: `${Math.max(10, heightPercent)}%` }}
                    className="w-full bg-blue-500/80 hover:bg-blue-400 rounded-t transition-all duration-200"
                  />
                  <div className="absolute bottom-full mb-1 hidden group-hover:block bg-slate-950 text-blue-300 font-mono text-[10px] px-1 py-0.5 rounded border border-slate-700 whitespace-nowrap z-10">
                    {val} jobs
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-2 pt-2 border-t border-slate-800/80">
            <span>-{timeRange}</span>
            <span>Now</span>
          </div>
        </div>

        {/* Panel 3: GPU Compute Load % */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-semibold text-white">Cluster GPU Compute %</span>
              <Cpu className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-emerald-400">
                {gpuSeries[gpuSeries.length - 1]}%
              </span>
              <span className="text-xs text-slate-400 font-mono">4x A100-80GB Pool</span>
            </div>
          </div>

          {/* SVG Sparkline */}
          <div className="h-24 w-full mt-3 flex items-end gap-1">
            {gpuSeries.map((val, idx) => {
              const heightPercent = val;
              return (
                <div key={idx} className="flex-1 h-full flex flex-col justify-end items-center group relative">
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className="w-full bg-emerald-500/80 hover:bg-emerald-400 rounded-t transition-all duration-200"
                  />
                  <div className="absolute bottom-full mb-1 hidden group-hover:block bg-slate-950 text-emerald-300 font-mono text-[10px] px-1 py-0.5 rounded border border-slate-700 whitespace-nowrap z-10">
                    {val}%
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-2 pt-2 border-t border-slate-800/80">
            <span>-{timeRange}</span>
            <span>Now</span>
          </div>
        </div>
      </div>

      {/* Prometheus AlertManager Rules & Status Grid */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-red-400" />
            <h4 className="font-semibold text-sm text-white">
              Prometheus AlertManager Rule Evaluations
            </h4>
          </div>
          <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> 4/4 Rules Green
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            {
              name: 'HighP95LatencyBreach',
              condition: 'p95_latency > 800ms for 2m',
              status: 'OK',
              severity: 'P1 - High',
              color: 'text-emerald-400 border-slate-800 bg-slate-950/80',
            },
            {
              name: 'RedisQueueBacklogCritical',
              condition: 'queue_depth > 50 for 1m',
              status: 'OK',
              severity: 'P2 - Medium',
              color: 'text-emerald-400 border-slate-800 bg-slate-950/80',
            },
            {
              name: 'WorkerOOMRiskAlert',
              condition: 'gpu_vram_used > 92% for 30s',
              status: 'OK',
              severity: 'P2 - Medium',
              color: 'text-emerald-400 border-slate-800 bg-slate-950/80',
            },
            {
              name: 'HighInferenceTimeoutRate',
              condition: 'rate(timeouts[5m]) > 0.02',
              status: 'OK',
              severity: 'P1 - High',
              color: 'text-emerald-400 border-slate-800 bg-slate-950/80',
            },
          ].map((alert, idx) => (
            <div key={idx} className={`p-3 rounded-lg border ${alert.color}`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-white">{alert.name}</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold">
                  {alert.status}
                </span>
              </div>
              <div className="text-[11px] font-mono text-slate-400 mb-1">{alert.condition}</div>
              <div className="text-[10px] text-slate-400 font-sans">{alert.severity}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
