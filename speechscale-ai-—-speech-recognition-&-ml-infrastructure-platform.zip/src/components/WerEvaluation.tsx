import React, { useState } from 'react';
import { 
  FileCheck2, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Layers, 
  RotateCcw, 
  HelpCircle,
  TrendingDown,
  Sparkles,
  BarChart2,
  GitCompare,
  ArrowRight,
  Trophy,
  Sliders,
  Percent,
  Cpu,
  Zap,
  Info
} from 'lucide-react';
import { computeWER, computeCER } from '../utils/wer';
import { compareModelTranscriptions } from '../utils/modelComparison';
import { DATASET_EVALUATIONS, MODELS_CONFIG } from '../data/modelsConfig';
import { SAMPLE_AUDIOS } from '../data/sampleAudios';
import { ModelId } from '../types';

type SupportedModelKey = 'whisper-large-v3' | 'distil-whisper-v3' | 'whisper-medium' | 'whisper-small' | 'whisper-tiny';

const COMPARISON_MODELS: { id: SupportedModelKey; name: string; tag: string }[] = [
  { id: 'whisper-large-v3', name: 'Whisper Large-v3', tag: '1.55B Baseline SOTA' },
  { id: 'distil-whisper-v3', name: 'Distil-Whisper-v3', tag: '756M 5.8x Faster' },
  { id: 'whisper-medium', name: 'Whisper Medium', tag: '769M Balanced' },
  { id: 'whisper-small', name: 'Whisper Small', tag: '244M High Throughput' },
  { id: 'whisper-tiny', name: 'Whisper Tiny', tag: '39M Ultra Lightweight' },
];

export const WerEvaluation: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'single' | 'sideBySide'>('sideBySide');
  const [activeSampleIndex, setActiveSampleIndex] = useState<number>(0);
  const sample = SAMPLE_AUDIOS[activeSampleIndex];

  // Single model state
  const [referenceText, setReferenceText] = useState<string>(sample.referenceText);
  const [selectedModel, setSelectedModel] = useState<SupportedModelKey>('whisper-tiny');
  const [hypothesisText, setHypothesisText] = useState<string>(sample.modelTranscripts['whisper-tiny']);

  // Side-by-side comparison state
  const [modelA, setModelA] = useState<SupportedModelKey>('whisper-large-v3');
  const [modelB, setModelB] = useState<SupportedModelKey>('distil-whisper-v3');
  const [customTranscriptA, setCustomTranscriptA] = useState<string>(sample.modelTranscripts['whisper-large-v3']);
  const [customTranscriptB, setCustomTranscriptB] = useState<string>(sample.modelTranscripts['distil-whisper-v3']);

  // Single model live WER
  const werResult = computeWER(referenceText, hypothesisText);

  // Side-by-side comparison analysis
  const comparisonAnalysis = compareModelTranscriptions(
    referenceText,
    customTranscriptA,
    customTranscriptB
  );

  const handleSelectSample = (idx: number) => {
    setActiveSampleIndex(idx);
    const s = SAMPLE_AUDIOS[idx];
    setReferenceText(s.referenceText);
    setHypothesisText(s.modelTranscripts[selectedModel]);
    setCustomTranscriptA(s.modelTranscripts[modelA]);
    setCustomTranscriptB(s.modelTranscripts[modelB]);
  };

  const handleSelectModel = (modelKey: SupportedModelKey) => {
    setSelectedModel(modelKey);
    setHypothesisText(sample.modelTranscripts[modelKey]);
  };

  const handleSelectModelA = (key: SupportedModelKey) => {
    setModelA(key);
    setCustomTranscriptA(sample.modelTranscripts[key]);
  };

  const handleSelectModelB = (key: SupportedModelKey) => {
    setModelB(key);
    setCustomTranscriptB(sample.modelTranscripts[key]);
  };

  const handleSwapModels = () => {
    const prevA = modelA;
    const prevTextA = customTranscriptA;
    setModelA(modelB);
    setCustomTranscriptA(customTranscriptB);
    setModelB(prevA);
    setCustomTranscriptB(prevTextA);
  };

  const specA = MODELS_CONFIG[modelA];
  const specB = MODELS_CONFIG[modelB];

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-base text-white">
                Word Error Rate (WER) &amp; Acoustic Accuracy Evaluation
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Evaluate transcription quality across Whisper variants using Levenshtein distance alignment, word error rates, and side-by-side differential acoustic comparison.
            </p>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('sideBySide')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'sideBySide'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <GitCompare className="w-3.5 h-3.5 text-cyan-400" />
              <span>Side-by-Side Model Comparison</span>
            </button>
            <button
              onClick={() => setActiveTab('single')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'single'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCheck2 className="w-3.5 h-3.5 text-slate-400" />
              <span>Single Model Diff Studio</span>
            </button>
          </div>
        </div>

        {/* Corpora Selection Strip */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-slate-400 text-[11px] font-medium shrink-0">Evaluation Audio Sample:</span>
            {SAMPLE_AUDIOS.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => handleSelectSample(idx)}
                className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  activeSampleIndex === idx
                    ? 'bg-cyan-600 text-white border-cyan-500 shadow-sm'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                {s.title}
              </button>
            ))}
          </div>

          <div className="text-[11px] text-slate-400 font-mono shrink-0">
            Acoustic: <span className="text-slate-300">{sample.acousticCondition}</span> &bull; {sample.durationSec}s
          </div>
        </div>
      </div>

      {/* SIDE-BY-SIDE MODEL COMPARISON TAB */}
      {activeTab === 'sideBySide' ? (
        <div className="space-y-6">
          {/* Model Pickers & Comparative Outcome Banner */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
            {/* Header of Section */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <GitCompare className="w-4 h-4 text-cyan-400" />
                <h4 className="font-bold text-sm text-white">Dual-Model Accuracy Benchmarking</h4>
                <span className="text-xs text-slate-400">&bull; Identical Reference Audio: {sample.title}</span>
              </div>

              <button
                onClick={handleSwapModels}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Swap Model A and Model B"
              >
                <RotateCcw className="w-3 h-3 text-slate-400" />
                <span>Swap A &harr; B</span>
              </button>
            </div>

            {/* Model Selectors Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Model A Selector Card */}
              <div className="bg-slate-950/80 border border-indigo-900/50 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                    <span className="font-bold text-indigo-300">Model A</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {specA?.parameters} &bull; {specA?.relativeSpeed}
                  </span>
                </div>

                <select
                  value={modelA}
                  onChange={(e) => handleSelectModelA(e.target.value as SupportedModelKey)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {COMPARISON_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} — {m.tag}
                    </option>
                  ))}
                </select>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>Architecture: {specA?.architecture.split('(')[0].trim()}</span>
                  <span>Typical RTF: <strong className="text-slate-200 font-mono">{specA?.typicalRtf}x</strong></span>
                </div>
              </div>

              {/* Model B Selector Card */}
              <div className="bg-slate-950/80 border border-cyan-900/50 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-500"></span>
                    <span className="font-bold text-cyan-300">Model B</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {specB?.parameters} &bull; {specB?.relativeSpeed}
                  </span>
                </div>

                <select
                  value={modelB}
                  onChange={(e) => handleSelectModelB(e.target.value as SupportedModelKey)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  {COMPARISON_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} — {m.tag}
                    </option>
                  ))}
                </select>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>Architecture: {specB?.architecture.split('(')[0].trim()}</span>
                  <span>Typical RTF: <strong className="text-slate-200 font-mono">{specB?.typicalRtf}x</strong></span>
                </div>
              </div>
            </div>

            {/* Differential Benchmark Summary Strip */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {/* Winner KPI */}
              <div className="space-y-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Accuracy Winner</span>
                <div className="flex items-center gap-1.5">
                  <Trophy className={`w-4 h-4 ${
                    comparisonAnalysis.winner === 'modelA' ? 'text-indigo-400' :
                    comparisonAnalysis.winner === 'modelB' ? 'text-cyan-400' : 'text-slate-400'
                  }`} />
                  <span className="font-bold text-white text-sm">
                    {comparisonAnalysis.winner === 'modelA' ? specA.name :
                     comparisonAnalysis.winner === 'modelB' ? specB.name : 'Parity (Tie)'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {comparisonAnalysis.winner !== 'tie' ? `${comparisonAnalysis.winnerMargin}% lower WER margin` : 'Identical error rate'}
                </div>
              </div>

              {/* WER Delta */}
              <div className="space-y-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">WER Delta (A vs B)</span>
                <div className={`text-base font-bold font-mono ${
                  comparisonAnalysis.werDelta < 0 ? 'text-emerald-400' :
                  comparisonAnalysis.werDelta > 0 ? 'text-rose-400' : 'text-slate-300'
                }`}>
                  {comparisonAnalysis.werDelta > 0 ? `+${comparisonAnalysis.werDelta}%` : `${comparisonAnalysis.werDelta}%`}
                </div>
                <div className="text-[10px] text-slate-400">
                  {comparisonAnalysis.werA.wer}% vs {comparisonAnalysis.werB.wer}%
                </div>
              </div>

              {/* Inter-Model Agreement Rate */}
              <div className="space-y-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Transcript Concordance</span>
                <div className="text-base font-bold font-mono text-cyan-300">
                  {comparisonAnalysis.agreementRate}%
                </div>
                <div className="text-[10px] text-slate-400">
                  Shared word match rate
                </div>
              </div>

              {/* CER Comparison */}
              <div className="space-y-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Char Error (CER)</span>
                <div className="text-base font-bold font-mono text-white">
                  {comparisonAnalysis.werA.cer}% <span className="text-xs font-normal text-slate-500">vs</span> {comparisonAnalysis.werB.cer}%
                </div>
                <div className="text-[10px] text-slate-400">
                  Delta: {comparisonAnalysis.cerDelta > 0 ? `+${comparisonAnalysis.cerDelta}%` : `${comparisonAnalysis.cerDelta}%`}
                </div>
              </div>
            </div>
          </div>

          {/* Side-by-Side Transcripts & Diff Highlighting */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Model A Transcript Column */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                  <h4 className="font-semibold text-sm text-white">{specA.name}</h4>
                </div>
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    comparisonAnalysis.werA.wer <= 3.0 ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    comparisonAnalysis.werA.wer <= 8.0 ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' :
                    'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    WER: {comparisonAnalysis.werA.wer}%
                  </span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-400">Raw Model Transcription Output</label>
                <textarea
                  rows={4}
                  value={customTranscriptA}
                  onChange={(e) => setCustomTranscriptA(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans leading-relaxed"
                />
              </div>

              {/* Model A Token Alignment Diff */}
              <div className="space-y-1.5 pt-2">
                <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
                  <span>Alignment Diff vs. Ground Truth</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    H: {comparisonAnalysis.werA.hits} &bull; S: {comparisonAnalysis.werA.substitutions} &bull; D: {comparisonAnalysis.werA.deletions} &bull; I: {comparisonAnalysis.werA.insertions}
                  </span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex flex-wrap gap-1.5 text-xs min-h-20 leading-relaxed">
                  {comparisonAnalysis.werA.alignments.map((item, idx) => {
                    if (item.type === 'match') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-emerald-950/40 text-emerald-300 border border-emerald-800/40">
                          {item.refWord}
                        </span>
                      );
                    }
                    if (item.type === 'substitution') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-700/60 font-semibold" title={`Substituted: ${item.refWord} -> ${item.hypWord}`}>
                          <span className="line-through text-amber-400/60 mr-1">{item.refWord}</span>
                          &rarr; {item.hypWord}
                        </span>
                      );
                    }
                    if (item.type === 'deletion') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700/60 line-through" title={`Deleted word: ${item.refWord}`}>
                          {item.refWord}
                        </span>
                      );
                    }
                    return (
                      <span key={idx} className="px-1.5 py-0.5 rounded bg-blue-950/60 text-blue-300 border border-blue-700/60 font-medium" title={`Inserted word: ${item.hypWord}`}>
                        +{item.hypWord}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Model B Transcript Column */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-500"></span>
                  <h4 className="font-semibold text-sm text-white">{specB.name}</h4>
                </div>
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    comparisonAnalysis.werB.wer <= 3.0 ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    comparisonAnalysis.werB.wer <= 8.0 ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' :
                    'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    WER: {comparisonAnalysis.werB.wer}%
                  </span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-400">Raw Model Transcription Output</label>
                <textarea
                  rows={4}
                  value={customTranscriptB}
                  onChange={(e) => setCustomTranscriptB(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans leading-relaxed"
                />
              </div>

              {/* Model B Token Alignment Diff */}
              <div className="space-y-1.5 pt-2">
                <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
                  <span>Alignment Diff vs. Ground Truth</span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    H: {comparisonAnalysis.werB.hits} &bull; S: {comparisonAnalysis.werB.substitutions} &bull; D: {comparisonAnalysis.werB.deletions} &bull; I: {comparisonAnalysis.werB.insertions}
                  </span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex flex-wrap gap-1.5 text-xs min-h-20 leading-relaxed">
                  {comparisonAnalysis.werB.alignments.map((item, idx) => {
                    if (item.type === 'match') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-emerald-950/40 text-emerald-300 border border-emerald-800/40">
                          {item.refWord}
                        </span>
                      );
                    }
                    if (item.type === 'substitution') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-700/60 font-semibold" title={`Substituted: ${item.refWord} -> ${item.hypWord}`}>
                          <span className="line-through text-amber-400/60 mr-1">{item.refWord}</span>
                          &rarr; {item.hypWord}
                        </span>
                      );
                    }
                    if (item.type === 'deletion') {
                      return (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700/60 line-through" title={`Deleted word: ${item.refWord}`}>
                          {item.refWord}
                        </span>
                      );
                    }
                    return (
                      <span key={idx} className="px-1.5 py-0.5 rounded bg-blue-950/60 text-blue-300 border border-blue-700/60 font-medium" title={`Inserted word: ${item.hypWord}`}>
                        +{item.hypWord}
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Reference Ground Truth Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm space-y-2">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>Common Reference Ground Truth ({sample.title})</span>
              </label>
              <span className="text-slate-400 font-mono text-[11px]">
                {comparisonAnalysis.werA.refWordCount} words
              </span>
            </div>
            <textarea
              rows={2}
              value={referenceText}
              onChange={(e) => setReferenceText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-sans leading-relaxed"
              placeholder="Edit ground truth text to test live recalculation..."
            />
          </div>

          {/* Word-Level Differential Accuracy Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <h4 className="font-semibold text-sm text-white">
                  Token-by-Token Differential Alignment
                </h4>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {comparisonAnalysis.detailedDifferences.length} token alignments analyzed
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-3 w-12">#</th>
                    <th className="py-2 px-3">Ground Truth</th>
                    <th className="py-2 px-3 text-indigo-300">{specA.name}</th>
                    <th className="py-2 px-3 text-cyan-300">{specB.name}</th>
                    <th className="py-2 px-3">Differential Analysis</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {comparisonAnalysis.detailedDifferences.map((row, idx) => (
                    <tr 
                      key={idx} 
                      className={`transition-colors ${
                        row.classification === 'both_correct' 
                          ? 'hover:bg-slate-800/20' 
                          : row.classification === 'a_superior'
                          ? 'bg-indigo-950/20 hover:bg-indigo-950/30'
                          : row.classification === 'b_superior'
                          ? 'bg-cyan-950/20 hover:bg-cyan-950/30'
                          : 'bg-amber-950/20 hover:bg-amber-950/30'
                      }`}
                    >
                      <td className="py-2 px-3 font-mono text-slate-500 text-[11px]">
                        {row.index + 1}
                      </td>
                      <td className="py-2 px-3 font-semibold text-white">
                        {row.refFragment}
                      </td>
                      <td className={`py-2 px-3 font-mono ${
                        row.transcriptA.toLowerCase() === row.refFragment?.toLowerCase()
                          ? 'text-emerald-400'
                          : 'text-rose-400 font-semibold'
                      }`}>
                        {row.transcriptA}
                      </td>
                      <td className={`py-2 px-3 font-mono ${
                        row.transcriptB.toLowerCase() === row.refFragment?.toLowerCase()
                          ? 'text-emerald-400'
                          : 'text-rose-400 font-semibold'
                      }`}>
                        {row.transcriptB}
                      </td>
                      <td className="py-2 px-3 text-[11px]">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-mono mr-2 ${
                          row.classification === 'both_correct' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                          row.classification === 'a_superior' ? 'bg-indigo-950 text-indigo-300 border border-indigo-800' :
                          row.classification === 'b_superior' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' :
                          'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}>
                          {row.classification === 'both_correct' ? 'CONCORDANT' :
                           row.classification === 'a_superior' ? 'MODEL A WINS' :
                           row.classification === 'b_superior' ? 'MODEL B WINS' : 'BOTH ERRORED'}
                        </span>
                        <span className="text-slate-400">{row.analysisNote}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* SINGLE MODEL DIFF STUDIO (Original Tab) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Reference & Hypothesis Editors */}
          <div className="lg:col-span-7 space-y-4">
            {/* Reference Ground Truth */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2 shadow-sm">
              <div className="flex items-center justify-between text-xs">
                <label className="font-semibold text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Reference Text (Ground Truth Transcription)</span>
                </label>
                <span className="text-slate-400 font-mono text-[11px]">
                  {werResult.refWordCount} words
                </span>
              </div>
              <textarea
                rows={3}
                value={referenceText}
                onChange={(e) => setReferenceText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-sans leading-relaxed"
                placeholder="Paste or edit the reference human transcript..."
              />
            </div>

            {/* Model Hypothesis */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <label className="font-semibold text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  <span>Model ASR Hypothesis (Whisper Output)</span>
                </label>

                {/* Model Switcher */}
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded p-0.5">
                  {COMPARISON_MODELS.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => handleSelectModel(m.id)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-all ${
                        selectedModel === m.id
                          ? 'bg-cyan-600 text-white font-bold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {m.id.replace('whisper-', '')}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                rows={3}
                value={hypothesisText}
                onChange={(e) => setHypothesisText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-sans leading-relaxed"
                placeholder="Paste or edit model prediction output..."
              />
            </div>

            {/* Levenshtein Alignment Diff Visualizer */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <h4 className="font-semibold text-sm text-white">
                  Levenshtein Token Alignment Breakdown
                </h4>
                <div className="flex items-center gap-3 text-[10px] font-mono">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    Match
                  </span>
                  <span className="flex items-center gap-1 text-amber-400">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Substitution (S)
                  </span>
                  <span className="flex items-center gap-1 text-red-400">
                    <span className="w-2 h-2 rounded-full bg-red-500"></span>
                    Deletion (D)
                  </span>
                  <span className="flex items-center gap-1 text-blue-400">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    Insertion (I)
                  </span>
                </div>
              </div>

              {/* Word Alignment Diff Stream */}
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex flex-wrap gap-2 text-xs leading-loose min-h-24">
                {werResult.alignments.length === 0 ? (
                  <span className="text-slate-400 italic">No text provided to evaluate</span>
                ) : (
                  werResult.alignments.map((item, idx) => {
                    if (item.type === 'match') {
                      return (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-emerald-950/30 text-emerald-300 border border-emerald-800/40"
                        >
                          {item.refWord}
                        </span>
                      );
                    }
                    if (item.type === 'substitution') {
                      return (
                        <span
                          key={idx}
                          title={`Substituted: "${item.refWord}" replaced by "${item.hypWord}"`}
                          className="px-2 py-0.5 rounded bg-amber-950/50 text-amber-300 border border-amber-700/60 font-semibold"
                        >
                          <span className="line-through text-amber-400/70 mr-1">{item.refWord}</span>
                          &rarr; {item.hypWord}
                        </span>
                      );
                    }
                    if (item.type === 'deletion') {
                      return (
                        <span
                          key={idx}
                          title={`Deleted: Model missed word "${item.refWord}"`}
                          className="px-2 py-0.5 rounded bg-red-950/50 text-red-300 border border-red-700/60 line-through"
                        >
                          {item.refWord}
                        </span>
                      );
                    }
                    // Insertion
                    return (
                      <span
                        key={idx}
                        title={`Inserted: Model hallucinated/inserted extra word "${item.hypWord}"`}
                        className="px-2 py-0.5 rounded bg-blue-950/50 text-blue-300 border border-blue-700/60 font-medium"
                      >
                        +{item.hypWord}
                      </span>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Quantitative Metrics & Analysis */}
          <div className="lg:col-span-5 space-y-4">
            {/* Main WER KPI Card */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                <span className="font-semibold text-slate-300">Word Error Rate (WER)</span>
                <span className="font-mono text-[11px] text-cyan-400">Acoustic Score</span>
              </div>

              <div className="flex items-baseline gap-3">
                <div className={`text-4xl font-extrabold font-mono ${
                  werResult.wer <= 3.0 ? 'text-emerald-400' :
                  werResult.wer <= 8.0 ? 'text-cyan-400' :
                  werResult.wer <= 15.0 ? 'text-amber-400' :
                  'text-red-400'
                }`}>
                  {werResult.wer}%
                </div>
                <span className="text-xs text-slate-400">
                  {werResult.wer <= 3.0 ? 'Human-Level Transcriber' :
                   werResult.wer <= 8.0 ? 'High Production Quality' :
                   'Acoustic Degraded / Needs Post-Processing'}
                </span>
              </div>

              {/* Error Breakdown Bars */}
              <div className="grid grid-cols-4 gap-2 mt-5 text-center text-xs">
                <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
                  <div className="text-[10px] text-emerald-400 font-medium">Hits (H)</div>
                  <div className="text-base font-bold font-mono text-white mt-0.5">{werResult.hits}</div>
                </div>
                <div className="p-2 rounded-lg bg-amber-950/30 border border-amber-800/40">
                  <div className="text-[10px] text-amber-400 font-medium">Subs (S)</div>
                  <div className="text-base font-bold font-mono text-white mt-0.5">{werResult.substitutions}</div>
                </div>
                <div className="p-2 rounded-lg bg-red-950/30 border border-red-800/40">
                  <div className="text-[10px] text-red-400 font-medium">Dels (D)</div>
                  <div className="text-base font-bold font-mono text-white mt-0.5">{werResult.deletions}</div>
                </div>
                <div className="p-2 rounded-lg bg-blue-950/30 border border-blue-800/40">
                  <div className="text-[10px] text-blue-400 font-medium">Ins (I)</div>
                  <div className="text-base font-bold font-mono text-white mt-0.5">{werResult.insertions}</div>
                </div>
              </div>

              {/* CER & SER */}
              <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Character Error Rate (CER)</span>
                  <span className="text-base font-bold font-mono text-slate-200">{werResult.cer}%</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Sentence Error Rate (SER)</span>
                  <span className="text-base font-bold font-mono text-slate-200">{werResult.ser}%</span>
                </div>
              </div>
            </div>

            {/* Model Serving Trade-off Spotlight */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h4 className="font-semibold text-sm text-white">Accuracy vs Latency Trade-Off Spotlight</h4>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white">Whisper Large-v3</div>
                    <div className="text-[11px] text-slate-400">1.8% WER on Clean Audio</div>
                  </div>
                  <div className="text-right font-mono text-[11px]">
                    <span className="text-slate-300">p95: ~1,250ms</span>
                    <span className="text-slate-400 block">VRAM: 9.8 GB</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-800/60 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <span>Distil-Whisper-v3</span>
                      <span className="text-[9px] px-1 rounded bg-cyan-800 text-white font-bold">SWEET SPOT</span>
                    </div>
                    <div className="text-[11px] text-slate-300">2.1% WER (98.6% of Large-v3 accuracy)</div>
                  </div>
                  <div className="text-right font-mono text-[11px]">
                    <span className="text-cyan-300 font-bold">p95: ~220ms (5.8x faster)</span>
                    <span className="text-slate-400 block">VRAM: 4.2 GB</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white">Whisper Tiny</div>
                    <div className="text-[11px] text-slate-400">7.9% WER (Degrades on noisy speech)</div>
                  </div>
                  <div className="text-right font-mono text-[11px]">
                    <span className="text-emerald-400">p95: ~65ms (18x faster)</span>
                    <span className="text-slate-400 block">VRAM: 0.5 GB</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Evaluation Corpora Matrix Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-purple-400" />
            <h4 className="font-semibold text-sm text-white">
              Standard Speech Corpora Multi-Model WER Benchmark
            </h4>
          </div>
          <span className="text-xs text-slate-400">Normalized lowercased without punctuation</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Dataset / Corpora</th>
                <th className="py-2.5 px-3">Acoustic Domain</th>
                <th className="py-2.5 px-3">Test Hours</th>
                <th className="py-2.5 px-3 text-cyan-400">Large-v3 WER</th>
                <th className="py-2.5 px-3 text-cyan-300">Distil-v3 WER</th>
                <th className="py-2.5 px-3">Medium WER</th>
                <th className="py-2.5 px-3">Small WER</th>
                <th className="py-2.5 px-3">Tiny WER</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {DATASET_EVALUATIONS.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-semibold text-white font-mono">
                    {row.dataset}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">
                    {row.domain}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-400">
                    {row.audioHours}
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-400">
                    {row.largeV3Wer}%
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-cyan-300">
                    {row.distilWer}%
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">
                    {row.mediumWer}%
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-400">
                    {row.smallWer}%
                  </td>
                  <td className="py-2.5 px-3 font-mono text-amber-400">
                    {row.tinyWer}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
