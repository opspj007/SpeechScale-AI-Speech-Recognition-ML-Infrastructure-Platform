import React, { useState, useMemo } from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell, 
  PieChart, 
  Pie 
} from 'recharts';
import { 
  AlertOctagon, 
  AlertTriangle, 
  Clock, 
  Cpu, 
  Database, 
  RotateCcw, 
  Search, 
  ShieldAlert, 
  ChevronRight, 
  Sparkles, 
  CheckCircle2, 
  Info, 
  Layers, 
  Terminal,
  ArrowRight,
  Filter
} from 'lucide-react';
import { InferenceJob, WorkerInstance } from '../types';
import { 
  analyzeClusterErrors, 
  ErrorCategory, 
  ClassifiedFailedJob 
} from '../utils/errorBreakdown';
import { MODELS_CONFIG } from '../data/modelsConfig';

interface ErrorBreakdownProps {
  failedJobs: InferenceJob[];
  dlqJobs: InferenceJob[];
  workers: WorkerInstance[];
  onRedriveJob?: (jobId: string) => void;
  onRedriveAll?: () => void;
  onSimulateSampleError?: (category: ErrorCategory) => void;
}

export const ErrorBreakdown: React.FC<ErrorBreakdownProps> = ({
  failedJobs,
  dlqJobs,
  workers,
  onRedriveJob,
  onRedriveAll,
  onSimulateSampleError,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ErrorCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedJob, setSelectedJob] = useState<ClassifiedFailedJob | null>(null);

  // Combine failed and DLQ jobs
  const allFailedJobs = useMemo(() => {
    const combined = [...failedJobs, ...dlqJobs];
    // Deduplicate by ID
    const seen = new Set<string>();
    return combined.filter(j => {
      if (seen.has(j.id)) return false;
      seen.add(j.id);
      return true;
    });
  }, [failedJobs, dlqJobs]);

  // Analyze errors
  const metrics = useMemo(() => {
    return analyzeClusterErrors(allFailedJobs);
  }, [allFailedJobs]);

  // Filter classified jobs for drilldown table
  const filteredJobs = useMemo(() => {
    return metrics.classifiedJobs.filter((item) => {
      if (selectedCategory !== 'ALL' && item.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.job.id.toLowerCase().includes(q) ||
          item.job.audioName.toLowerCase().includes(q) ||
          item.errorTitle.toLowerCase().includes(q) ||
          item.job.model.toLowerCase().includes(q) ||
          (item.job.workerId && item.job.workerId.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [metrics.classifiedJobs, selectedCategory, searchQuery]);

  // Recharts data format for Category Bar Chart
  const barChartData = useMemo(() => {
    return metrics.groups.map((g) => ({
      name: g.category,
      label: g.label.split('(')[0].trim(),
      count: g.count,
      color: g.color,
    }));
  }, [metrics.groups]);

  // Recharts data format for Pie / Donut
  const pieChartData = useMemo(() => {
    return metrics.groups
      .filter((g) => g.count > 0)
      .map((g) => ({
        name: g.label.split('(')[0].trim(),
        value: g.count,
        color: g.color,
      }));
  }, [metrics.groups]);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <AlertOctagon className="w-5 h-5 text-rose-400" />
              <h3 className="font-bold text-base text-white">
                Cluster Incident &amp; Error Breakdown Analysis
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Categorize and drill down into failed audio inference jobs by failure signature (CUDA OOM, SLA timeouts, decode faults, rate limits) to detect cluster hardware bottlenecks.
            </p>
          </div>

          {/* Quick Simulation Injectors */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            <span className="text-[11px] text-slate-400">Inject Test Fault:</span>
            <button
              onClick={() => onSimulateSampleError?.('OOM')}
              className="px-2.5 py-1.5 rounded-md bg-rose-950/60 border border-rose-800/80 hover:bg-rose-900/60 text-rose-300 text-xs font-medium cursor-pointer transition-colors"
            >
              + CUDA OOM
            </button>
            <button
              onClick={() => onSimulateSampleError?.('TIMEOUT')}
              className="px-2.5 py-1.5 rounded-md bg-amber-950/60 border border-amber-800/80 hover:bg-amber-900/60 text-amber-300 text-xs font-medium cursor-pointer transition-colors"
            >
              + SLA Timeout
            </button>
            <button
              onClick={() => onSimulateSampleError?.('AUDIO_DECODE_ERROR')}
              className="px-2.5 py-1.5 rounded-md bg-cyan-950/60 border border-cyan-800/80 hover:bg-cyan-900/60 text-cyan-300 text-xs font-medium cursor-pointer transition-colors"
            >
              + Audio Decode
            </button>
            {onRedriveAll && (
              <button
                onClick={onRedriveAll}
                disabled={metrics.totalFailed === 0}
                className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 cursor-pointer transition-all ml-1"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                <span>Re-drive All Failed</span>
              </button>
            )}
          </div>
        </div>

        {/* High-Level Error Health KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-4">
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-3">
            <span className="text-slate-400 text-[10px] uppercase font-semibold">Total Incidents</span>
            <div className={`text-2xl font-bold font-mono mt-1 ${metrics.totalFailed > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {metrics.totalFailed}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">
              {metrics.totalFailed === 0 ? 'Nominal zero errors' : `${dlqJobs.length} in DLQ buffer`}
            </span>
          </div>

          <div 
            onClick={() => setSelectedCategory('OOM')}
            className={`rounded-lg p-3 border transition-all cursor-pointer ${
              selectedCategory === 'OOM' ? 'bg-rose-950/40 border-rose-600 ring-1 ring-rose-500' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-semibold text-rose-400">
              <span>CUDA OOM</span>
              <Cpu className="w-3.5 h-3.5" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {metrics.oomCount}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">KV-cache overflow</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('TIMEOUT')}
            className={`rounded-lg p-3 border transition-all cursor-pointer ${
              selectedCategory === 'TIMEOUT' ? 'bg-amber-950/40 border-amber-600 ring-1 ring-amber-500' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-semibold text-amber-400">
              <span>SLA Timeout</span>
              <Clock className="w-3.5 h-3.5" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {metrics.timeoutCount}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">&gt; 12.0s deadline</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('API_ERROR')}
            className={`rounded-lg p-3 border transition-all cursor-pointer ${
              selectedCategory === 'API_ERROR' ? 'bg-purple-950/40 border-purple-600 ring-1 ring-purple-500' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-semibold text-purple-400">
              <span>API / Runtime</span>
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {metrics.apiErrorCount}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">500 Server fault</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('AUDIO_DECODE_ERROR')}
            className={`rounded-lg p-3 border transition-all cursor-pointer ${
              selectedCategory === 'AUDIO_DECODE_ERROR' ? 'bg-cyan-950/40 border-cyan-600 ring-1 ring-cyan-500' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-semibold text-cyan-400">
              <span>Audio Decode</span>
              <Database className="w-3.5 h-3.5" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {metrics.decodeErrorCount}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Corrupt header/format</span>
          </div>

          <div 
            onClick={() => setSelectedCategory('RATE_LIMIT')}
            className={`rounded-lg p-3 border transition-all cursor-pointer ${
              selectedCategory === 'RATE_LIMIT' ? 'bg-yellow-950/40 border-yellow-600 ring-1 ring-yellow-500' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-semibold text-yellow-400">
              <span>Rate Limit (429)</span>
              <ShieldAlert className="w-3.5 h-3.5" />
            </div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {metrics.rateLimitCount}
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Stream burst cap</span>
          </div>
        </div>
      </div>

      {/* Main Charts: Error Distribution & Root Cause Diagnosis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Recharts Error Volume Bar Chart */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <h4 className="font-semibold text-sm text-white">Error Category Distribution</h4>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {metrics.totalFailed} total cluster failures recorded
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barChartData} margin={{ top: 10, right: 10, left: -20, bottom: 10 }}>
                <XAxis 
                  dataKey="label" 
                  stroke="#64748b" 
                  tick={{ fill: '#94a3b8', fontSize: 11 }} 
                  tickLine={{ stroke: '#334155' }}
                />
                <YAxis 
                  stroke="#64748b" 
                  tick={{ fill: '#94a3b8', fontSize: 11 }} 
                  tickLine={{ stroke: '#334155' }}
                  allowDecimals={false}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                  labelStyle={{ color: '#f8fafc', fontWeight: 'bold' }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {barChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Category Quick Filter Pills */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1 text-xs">
            <span className="text-slate-400 text-[11px] mr-1">Filter View:</span>
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                selectedCategory === 'ALL'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Types ({metrics.totalFailed})
            </button>
            {metrics.groups.map((g) => (
              <button
                key={g.category}
                onClick={() => setSelectedCategory(g.category)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                  selectedCategory === g.category
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: g.color }} />
                <span>{g.category}</span>
                <span className="font-mono text-[10px] text-slate-500">({g.count})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Cluster Health Diagnosis & Auto-Remediation */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h4 className="font-semibold text-sm text-white">Cluster Remediation Diagnosis</h4>
            </div>

            <div className="space-y-3 mt-3 text-xs">
              {metrics.dominantErrorCategory === 'OOM' && (
                <div className="p-3.5 rounded-lg border border-rose-800/80 bg-rose-950/20 space-y-2">
                  <div className="flex items-center justify-between text-rose-300 font-semibold">
                    <span className="flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-rose-400" />
                      Critical: CUDA VRAM Exhaustion
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-900/60 font-mono">HARDWARE BOUND</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11px]">
                    Multiple jobs failed with Out-Of-Memory exceptions on large models. Autoregressive attention decoder allocated more memory than available GPU VRAM.
                  </p>
                  <div className="p-2.5 bg-slate-950/80 rounded border border-rose-900/50 text-[11px] text-rose-200">
                    <strong>Recommended Remediation:</strong> Force INT8 quantization in inference pipeline, decrease beam size to 1 (greedy), or isolate 1.55B models to worker-01 (A100-80GB).
                  </div>
                </div>
              )}

              {metrics.dominantErrorCategory === 'TIMEOUT' && (
                <div className="p-3.5 rounded-lg border border-amber-800/80 bg-amber-950/20 space-y-2">
                  <div className="flex items-center justify-between text-amber-300 font-semibold">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-amber-400" />
                      Warning: Request SLA Deadlines Breached
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-900/60 font-mono">LATENCY BOUND</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11px]">
                    Inference processing exceeded the 12.0s HTTP gateway deadline. High Redis Stream queue depth causing jobs to wait beyond SLA tolerance.
                  </p>
                  <div className="p-2.5 bg-slate-950/80 rounded border border-amber-900/50 text-[11px] text-amber-200">
                    <strong>Recommended Remediation:</strong> Scale worker pool from 3 to 6 instances, enable TensorRT-LLM continuous batching, or partition audio clips into 15-second chunks.
                  </div>
                </div>
              )}

              {(!metrics.dominantErrorCategory || (metrics.dominantErrorCategory !== 'OOM' && metrics.dominantErrorCategory !== 'TIMEOUT')) && (
                <div className="p-3.5 rounded-lg border border-emerald-800/80 bg-emerald-950/20 space-y-2">
                  <div className="flex items-center justify-between text-emerald-300 font-semibold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Cluster Reliability State Nominal
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-900/60 font-mono">HEALTHY</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-[11px]">
                    No critical cluster-wide failure trends detected. Workers are executing jobs with sub-second latency and compliant retry backoffs.
                  </p>
                  <div className="p-2.5 bg-slate-950/80 rounded border border-emerald-900/50 text-[11px] text-emerald-200">
                    <strong>Status:</strong> Active worker pool has sufficient VRAM headroom across all streaming priority queues.
                  </div>
                </div>
              )}

              {/* Cluster Hardware Allocation Check */}
              <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800 text-[11px] space-y-1.5">
                <span className="font-semibold text-slate-300 block">Active Worker Readiness:</span>
                <div className="grid grid-cols-2 gap-2 text-slate-400 font-mono">
                  {workers.map((w) => (
                    <div key={w.id} className="flex justify-between items-center p-1.5 bg-slate-900/80 rounded border border-slate-800/60">
                      <span className="truncate">{w.id}</span>
                      <span className={w.status === 'OOM_RECOVERY' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                        {w.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/80 flex items-center justify-between">
            <span>Dead Letter Queue: {dlqJobs.length} quarantined</span>
            <span>Max Retries: 3 attempts</span>
          </div>
        </div>
      </div>

      {/* Drill-down Table & Forensic Inspector */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        {/* Table Control Strip */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-rose-400" />
            <h4 className="font-semibold text-sm text-white">Failed Jobs Forensic Drilldown</h4>
            <span className="text-xs text-slate-400 font-mono">
              ({filteredJobs.length} jobs matched)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search job ID, model, error..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-rose-500 w-56"
              />
            </div>
            {selectedCategory !== 'ALL' && (
              <button
                onClick={() => setSelectedCategory('ALL')}
                className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 cursor-pointer"
              >
                Clear Filter
              </button>
            )}
          </div>
        </div>

        {/* Failed Jobs Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Job ID</th>
                <th className="py-2.5 px-3">Audio Payload</th>
                <th className="py-2.5 px-3">Model &amp; Engine</th>
                <th className="py-2.5 px-3">Error Classification</th>
                <th className="py-2.5 px-3">Component</th>
                <th className="py-2.5 px-3">Retries</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredJobs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                    No failed jobs found in this category. Cluster healthy.
                  </td>
                </tr>
              ) : (
                filteredJobs.map((item) => {
                  const isSelected = selectedJob?.job.id === item.job.id;
                  return (
                    <tr
                      key={item.job.id}
                      onClick={() => setSelectedJob(item)}
                      className={`hover:bg-slate-800/30 transition-colors cursor-pointer ${
                        isSelected ? 'bg-rose-950/20' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono font-bold text-white">
                        {item.job.id}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="font-medium text-slate-200">{item.job.audioName}</span>
                        <span className="text-[10px] text-slate-400 block font-mono">{item.job.audioDurationSec}s</span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-300">
                        <div>{item.job.model}</div>
                        <div className="text-[10px] text-slate-500">{item.job.engine} &bull; {item.job.quantization}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                          item.category === 'OOM' ? 'bg-rose-950 text-rose-300 border-rose-800' :
                          item.category === 'TIMEOUT' ? 'bg-amber-950 text-amber-300 border-amber-800' :
                          item.category === 'AUDIO_DECODE_ERROR' ? 'bg-cyan-950 text-cyan-300 border-cyan-800' :
                          item.category === 'RATE_LIMIT' ? 'bg-yellow-950 text-yellow-300 border-yellow-800' :
                          'bg-purple-950 text-purple-300 border-purple-800'
                        }`}>
                          {item.category}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                          {item.errorTitle}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-mono">
                        {item.component}
                      </td>
                      <td className="py-2.5 px-3 font-mono">
                        {item.job.retryCount} / {item.job.maxRetries}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px]">
                        {item.timestampFormatted}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                          {onRedriveJob && (
                            <button
                              onClick={() => onRedriveJob(item.job.id)}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                              title="Re-enqueue job into Redis Stream"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>Re-drive</span>
                            </button>
                          )}
                          <button
                            onClick={() => setSelectedJob(item)}
                            className="px-2 py-1 rounded bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/80 text-rose-300 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                          >
                            <span>Inspect</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Selected Job Detailed Forensic Inspector Modal/Panel */}
        {selectedJob && (
          <div className="bg-slate-950 border border-rose-900/60 rounded-xl p-4 mt-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <h4 className="font-bold text-sm text-white font-mono">
                  Forensic Stack Trace: {selectedJob.job.id}
                </h4>
                <span className="text-xs text-slate-400 font-mono">
                  [{selectedJob.category}]
                </span>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="text-xs text-slate-400 hover:text-white px-2 py-0.5 rounded bg-slate-800 cursor-pointer"
              >
                Close Inspector
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block font-mono">ERROR MESSAGE</span>
                  <div className="font-mono text-rose-300 font-semibold mt-1">
                    {selectedJob.errorTitle}
                  </div>
                </div>

                <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block font-mono">ROOT CAUSE</span>
                  <p className="text-slate-300 mt-1 leading-relaxed">
                    {selectedJob.rootCause}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block font-mono">RECOMMENDED FIX</span>
                  <p className="text-cyan-300 mt-1 leading-relaxed">
                    {selectedJob.recommendedRemediation}
                  </p>
                </div>

                <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800 flex items-center justify-between font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400 block text-[10px]">FAILED WORKER</span>
                    <span className="text-white font-bold">{selectedJob.job.workerId || 'gateway-ingress'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">EXECUTION TIME</span>
                    <span className="text-white font-bold">{selectedJob.job.inferenceDurationMs || 0} ms</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">RETRIES EXHAUSTED</span>
                    <span className="text-amber-400 font-bold">{selectedJob.job.retryCount} / {selectedJob.job.maxRetries}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
