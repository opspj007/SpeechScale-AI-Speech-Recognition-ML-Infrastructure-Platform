import React, { useState } from 'react';
import { 
  Code2, 
  Layers, 
  Server, 
  Database, 
  Cpu, 
  Copy, 
  Check, 
  Box, 
  ArrowRight,
  ShieldCheck,
  FileCode,
  Gauge
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const [activeCodeTab, setActiveCodeTab] = useState<'fastapi' | 'worker' | 'docker' | 'benchmark'>('fastapi');
  const [copied, setCopied] = useState<boolean>(false);

  const codeSnippets = {
    fastapi: `# app/api/inference.py
# SpeechScale AI - Production FastAPI Asynchronous Inference Endpoint
import uuid
import time
import json
from fastapi import FastAPI, UploadFile, File, BackgroundTasks, HTTPException, Depends
from pydantic import BaseModel, Field
import redis.asyncio as aioredis
from prometheus_client import Counter, Histogram

app = FastAPI(title="SpeechScale AI Inference Gateway", version="1.0.0")
redis_client = aioredis.from_url("redis://redis-cluster:6379/0", decode_responses=True)

INFERENCE_REQUESTS = Counter(
    "speechscale_transcription_requests_total", 
    "Total audio transcription requests", 
    ["status", "model"]
)
INFERENCE_LATENCY = Histogram(
    "speechscale_inference_seconds", 
    "End-to-end request latency", 
    ["model", "engine"],
    buckets=[0.05, 0.1, 0.25, 0.5, 0.8, 1.2, 2.0, 5.0]
)

class InferenceRequestPayload(BaseModel):
    model: str = Field(default="whisper-large-v3")
    engine: str = Field(default="faster-whisper")
    quantization: str = Field(default="int8")
    priority: str = Field(default="HIGH")
    vad_filter: bool = True
    beam_size: int = 1
    timeout_sec: float = 12.0

@app.post("/v1/audio/transcriptions/async")
async def dispatch_speech_inference(
    payload: InferenceRequestPayload,
    audio_file: UploadFile = File(...)
):
    job_id = str(uuid.uuid4())
    audio_bytes = await audio_file.read()
    
    # Store audio payload in fast Redis buffer or S3
    await redis_client.set(f"audio:raw:{job_id}", audio_bytes, ex=3600)
    
    # Queue task into priority Redis Stream
    stream_key = f"stream:audio_tasks:{payload.priority.lower()}"
    task_metadata = {
        "job_id": job_id,
        "filename": audio_file.filename,
        "model": payload.model,
        "engine": payload.engine,
        "quantization": payload.quantization,
        "vad_filter": str(payload.vad_filter),
        "beam_size": payload.beam_size,
        "timeout_sec": payload.timeout_sec,
        "created_at": time.time(),
        "retry_count": 0
    }
    
    # XADD with MAXLEN to prevent unbound stream growth
    await redis_client.xadd(stream_key, task_metadata, maxlen=50000)
    INFERENCE_REQUESTS.labels(status="queued", model=payload.model).inc()
    
    return {
        "job_id": job_id,
        "status": "QUEUED",
        "stream": stream_key,
        "poll_url": f"/v1/audio/jobs/{job_id}"
    }`,

    worker: `# app/workers/whisper_worker.py
# SpeechScale AI - Distributed PyTorch & Faster-Whisper Inference Worker
import os
import time
import asyncio
import logging
import torch
from faster_whisper import WhisperModel
import redis.asyncio as aioredis

logger = logging.getLogger("speechscale.worker")
logging.basicConfig(level=logging.INFO, format='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}')

class SpeechScaleWorker:
    def __init__(self, worker_id: str, device: str = "cuda", compute_type: str = "int8"):
        self.worker_id = worker_id
        self.device = device
        self.compute_type = compute_type
        self.redis = None
        self.loaded_model = None
        self.current_model_id = None
        
    async def initialize(self):
        self.redis = aioredis.from_url(os.getenv("REDIS_URL", "redis://redis-cluster:6379/0"))
        # Preload default large-v3 model with CTranslate2 INT8 kernels
        self.load_model("whisper-large-v3")
        logger.info(f"Worker {self.worker_id} initialized on {torch.cuda.get_device_name(0)}")

    def load_model(self, model_id: str):
        if self.current_model_id == model_id:
            return
        logger.info(f"Loading weights for {model_id} onto GPU...")
        self.loaded_model = WhisperModel(
            model_id, 
            device=self.device, 
            compute_type=self.compute_type,
            cpu_threads=4,
            num_workers=2
        )
        self.current_model_id = model_id

    async def run_inference_loop(self):
        # Priority order consumer polling: critical -> high -> default -> batch
        streams = {
            "stream:audio_tasks:critical": ">",
            "stream:audio_tasks:high": ">",
            "stream:audio_tasks:default": ">",
            "stream:audio_tasks:batch": ">",
        }
        
        while True:
            try:
                # XREADGROUP block for 500ms
                entries = await self.redis.xreadgroup(
                    groupname="speechscale_workers",
                    consumername=self.worker_id,
                    streams=streams,
                    count=1,
                    block=500
                )
                if not entries:
                    continue
                    
                stream_name, messages = entries[0]
                message_id, data = messages[0]
                await self.process_job(stream_name, message_id, data)
                
            except torch.cuda.OutOfMemoryError as e:
                logger.error(f"CUDA OOM encountered on worker {self.worker_id}! Initiating recovery...")
                torch.cuda.empty_cache()
                await self.handle_worker_oom()
            except Exception as e:
                logger.error(f"Worker unhandled failure: {str(e)}", exc_info=True)

    async def process_job(self, stream: str, msg_id: str, task: dict):
        job_id = task["job_id"]
        start_time = time.time()
        
        # Audio decode & Silero-VAD segments
        audio_bytes = await self.redis.get(f"audio:raw:{job_id}")
        
        # Run Whisper inference with word timestamps
        segments, info = self.loaded_model.transcribe(
            audio_bytes, 
            beam_size=int(task.get("beam_size", 1)),
            vad_filter=task.get("vad_filter") == "True",
            word_timestamps=True
        )
        
        results = [{"start": s.start, "end": s.end, "text": s.text} for s in segments]
        latency = (time.time() - start_time) * 1000
        
        # Store in PostgreSQL & publish completion event
        await self.save_result(job_id, results, latency)
        # ACK stream item
        await self.redis.xack(stream, "speechscale_workers", msg_id)`,

    docker: `# docker-compose.yml
# SpeechScale AI - Production Microservices Infrastructure Stack
version: '3.8'

services:
  fastapi-gateway:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "8000:8000"
    environment:
      - REDIS_URL=redis://redis-cluster:6379/0
      - DATABASE_URL=postgresql://speechscale:secret@postgres:5432/speechscale_db
    depends_on:
      - redis-cluster
      - postgres
    deploy:
      replicas: 3

  redis-cluster:
    image: redis:7.2-alpine
    command: redis-server --appendonly yes --maxmemory 4gb --maxmemory-policy noeviction
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: speechscale_db
      POSTGRES_USER: speechscale
      POSTGRES_PASSWORD: secret
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  worker-gpu-node:
    build:
      context: .
      dockerfile: Dockerfile.worker
    deploy:
      replicas: 4
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    environment:
      - NVIDIA_VISIBLE_DEVICES=all
      - CUDA_VISIBLE_DEVICES=0
      - REDIS_URL=redis://redis-cluster:6379/0

  prometheus:
    image: prom/prometheus:v2.45.0
    volumes:
      - ./infra/prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana:10.0.3
    ports:
      - "3000:3000"
    volumes:
      - ./infra/grafana-dashboards:/var/lib/grafana/dashboards

volumes:
  redis_data:
  pgdata:`,

    benchmark: `# scripts/benchmark_pipeline.py
# SpeechScale AI - Automated SLA & Latency Performance Benchmarking Suite
import asyncio
import time
import httpx
import numpy as np

async def run_benchmark(concurrency=20, total_requests=100, target_url="http://localhost:8000"):
    latencies = []
    semaphore = asyncio.Semaphore(concurrency)
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        async def submit_request(req_id):
            async with semaphore:
                t0 = time.perf_counter()
                with open("tests/assets/audio_30s.wav", "rb") as f:
                    resp = await client.post(
                        f"{target_url}/v1/audio/transcriptions/sync",
                        files={"audio_file": f},
                        data={"model": "whisper-large-v3", "engine": "faster-whisper"}
                    )
                elapsed = (time.perf_counter() - t0) * 1000
                latencies.append(elapsed)
                
        tasks = [submit_request(i) for i in range(total_requests)]
        await asyncio.gather(*tasks)

    # Compute SLA Percentiles
    p50 = np.percentile(latencies, 50)
    p95 = np.percentile(latencies, 95)
    p99 = np.percentile(latencies, 99)
    throughput = total_requests / (sum(latencies) / 1000 / concurrency)

    print("==================================================")
    print("SPEECHSCALE AI - SLA BENCHMARK REPORT")
    print(f"Concurrency: {concurrency} workers | Total Reqs: {total_requests}")
    print(f"p50 Median Latency: {p50:.1f} ms")
    print(f"p95 Latency (SLA):  {p95:.1f} ms {'[PASS]' if p95 < 800 else '[FAIL]'}")
    print(f"p99 Tail Latency:   {p99:.1f} ms")
    print(f"Throughput:         {throughput:.1f} requests/sec")
    print("==================================================")

if __name__ == "__main__":
    asyncio.run(run_benchmark())`
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeSnippets[activeCodeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Architecture Interactive Flowchart */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-base text-white">
              End-to-End Speech Recognition &amp; ML Infrastructure Platform Architecture
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            FastAPI &bull; PyTorch &bull; Whisper &bull; Redis &bull; PostgreSQL &bull; Docker &bull; Prometheus
          </span>
        </div>

        {/* Visual Architecture Topology Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          {/* Step 1: Ingestion */}
          <div className="p-3.5 rounded-lg border border-cyan-800/60 bg-cyan-950/20 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-cyan-300">
              <span>1. Ingestion Layer</span>
              <Server className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs text-white font-mono font-medium">FastAPI Gateway</div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Async non-blocking REST endpoints, multipart audio streaming, JWT auth, and Prometheus metrics wrapper.
            </p>
          </div>

          {/* Step 2: Queue */}
          <div className="p-3.5 rounded-lg border border-blue-800/60 bg-blue-950/20 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-blue-300">
              <span>2. Message Broker</span>
              <Layers className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs text-white font-mono font-medium">Redis Streams</div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Priority streams (critical, high, default, batch) with consumer groups (<code className="text-blue-300">XREADGROUP</code>) and DLQ.
            </p>
          </div>

          {/* Step 3: Compute */}
          <div className="p-3.5 rounded-lg border border-purple-800/60 bg-purple-950/20 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-purple-300">
              <span>3. Inference Engine</span>
              <Cpu className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs text-white font-mono font-medium">PyTorch &amp; Whisper</div>
            <p className="text-[11px] text-slate-400 leading-tight">
              CTranslate2 INT8 &amp; TensorRT-LLM GPU workers, CUDA streams, Silero-VAD silence stripping, and word alignments.
            </p>
          </div>

          {/* Step 4: Storage */}
          <div className="p-3.5 rounded-lg border border-emerald-800/60 bg-emerald-950/20 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-emerald-300">
              <span>4. Persistence</span>
              <Database className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs text-white font-mono font-medium">PostgreSQL 16 &amp; S3</div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Relational job metadata, transcript segments, word-level confidence tokens, and MinIO/S3 raw audio buckets.
            </p>
          </div>

          {/* Step 5: Observability */}
          <div className="p-3.5 rounded-lg border border-orange-800/60 bg-orange-950/20 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-orange-300">
              <span>5. Telemetry</span>
              <Gauge className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs text-white font-mono font-medium">Prometheus &amp; Grafana</div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Real-time p95/p99 latency histograms, GPU VRAM tracking, queue backlogs, and AlertManager firing rules.
            </p>
          </div>
        </div>
      </div>

      {/* Code Inspector Tabs */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        {/* Code Tabs Header */}
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {[
              { id: 'fastapi' as const, label: 'FastAPI Gateway (inference.py)', icon: FileCode },
              { id: 'worker' as const, label: 'PyTorch Worker (whisper_worker.py)', icon: Cpu },
              { id: 'docker' as const, label: 'Container Stack (docker-compose.yml)', icon: Box },
              { id: 'benchmark' as const, label: 'Benchmarking Pipeline (benchmark.py)', icon: Gauge },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCodeTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition-all cursor-pointer ${
                  activeCodeTab === tab.id
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono cursor-pointer transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
        </div>

        {/* Code Block */}
        <div className="p-4 bg-slate-950 max-h-[500px] overflow-y-auto font-mono text-xs text-slate-200 select-text leading-relaxed">
          <pre>{codeSnippets[activeCodeTab]}</pre>
        </div>
      </div>
    </div>
  );
};
