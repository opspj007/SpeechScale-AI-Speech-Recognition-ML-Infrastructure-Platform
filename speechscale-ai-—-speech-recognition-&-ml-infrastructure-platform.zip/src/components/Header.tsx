import React from 'react';
import { 
  Mic2, 
  Server, 
  BarChart3, 
  FileCheck2,
  Activity,
  AlertOctagon
} from 'lucide-react';

export type TabType = 'inference' | 'orchestrator' | 'benchmarks' | 'wer' | 'errors';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  activeWorkerCount: number;
  totalWorkerCount: number;
  queueDepth: number;
  activeJobsCount: number;
  failedJobsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeWorkerCount,
  totalWorkerCount,
  queueDepth,
  activeJobsCount,
  failedJobsCount = 0,
}) => {
  const tabs = [
    { id: 'inference' as TabType, label: 'Inference Studio', icon: Mic2, badge: activeJobsCount > 0 ? `${activeJobsCount}` : undefined },
    { id: 'orchestrator' as TabType, label: 'Worker Fleet & Queues', icon: Server, badge: queueDepth > 0 ? `${queueDepth}` : undefined },
    { id: 'benchmarks' as TabType, label: 'Latency & Saturation', icon: BarChart3 },
    { id: 'wer' as TabType, label: 'Quality & Model Comparison', icon: FileCheck2 },
    { id: 'errors' as TabType, label: 'Error Breakdown', icon: AlertOctagon, badge: failedJobsCount > 0 ? `${failedJobsCount}` : undefined },
  ];

  return (
    <header className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-6">
          {/* Brand Identity */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-[1px] shadow-sm">
              <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center">
                <Activity className="w-4 h-4 text-cyan-400" />
              </div>
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-2">
                <span className="font-bold text-base text-white tracking-tight">SpeechScale</span>
                <span className="text-[11px] font-mono text-cyan-400/90 hidden sm:inline">v2.4</span>
              </div>
              <div className="text-[11px] text-slate-400 hidden md:block">
                Whisper Speech Inference &amp; Cluster Orchestration
              </div>
            </div>
          </div>

          {/* Clean Segmented Navigation */}
          <nav className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800/80 rounded-lg overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      isActive ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Refined Cluster Health Summary (Quiet Typography) */}
          <div className="hidden lg:flex items-center gap-4 text-xs shrink-0">
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
              <span className="text-slate-400">Cluster:</span>
              <span className="font-mono text-slate-200 font-semibold">{activeWorkerCount}/{totalWorkerCount} Ready</span>
            </div>
            <span className="text-slate-800">|</span>
            <div className="flex items-center gap-1 text-slate-400">
              <span>Queue:</span>
              <span className={`font-mono font-semibold ${queueDepth > 0 ? 'text-amber-400' : 'text-slate-200'}`}>
                {queueDepth}
              </span>
            </div>
            <span className="text-slate-800">|</span>
            <div className="text-[11px] font-mono text-slate-400">
              SLA p95 &lt; 800ms
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
