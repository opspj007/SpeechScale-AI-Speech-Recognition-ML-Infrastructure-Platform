import React, { useState, useMemo, useEffect } from 'react';
import { 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  ZAxis, 
  Tooltip, 
  LineChart, 
  Line, 
  CartesianGrid, 
  ReferenceLine, 
  Legend 
} from 'recharts';
import { 
  Layers, 
  AlertTriangle, 
  TrendingUp, 
  Zap, 
  Sliders, 
  Info, 
  CheckCircle2, 
  ShieldAlert, 
  Gauge, 
  Cpu,
  ArrowRight
} from 'lucide-react';
import { ModelId, ServingEngine, Quantization } from '../types';
import { 
  HEATMAP_CONCURRENCY_LEVELS, 
  HEATMAP_MODELS, 
  HeatmapCellData, 
  generateSaturationMatrix, 
  detectModelSaturationKnee, 
  getLatencyColorToken 
} from '../utils/saturationHeatmap';
import { MODELS_CONFIG } from '../data/modelsConfig';

interface LatencyHeatmapProps {
  currentEngine: ServingEngine;
  currentQuantization: Quantization;
  currentSlaMs: number;
  onApplyConfig?: (model: ModelId, concurrency: number, engine: ServingEngine, quantization: Quantization) => void;
}

type MetricMode = 'avg' | 'p95' | 'rtf' | 'throughput';

export const LatencyHeatmap: React.FC<LatencyHeatmapProps> = ({
  currentEngine,
  currentQuantization,
  currentSlaMs,
  onApplyConfig,
}) => {
  const [engine, setEngine] = useState<ServingEngine>(currentEngine);
  const [quantization, setQuantization] = useState<Quantization>(currentQuantization);
  const [slaTargetMs, setSlaTargetMs] = useState<number>(currentSlaMs);
  const [metricMode, setMetricMode] = useState<MetricMode>('avg');
  const [activeTab, setActiveTab] = useState<'matrix' | 'curves'>('matrix');
  const [selectedCell, setSelectedCell] = useState<HeatmapCellData | null>(null);

  // Synchronize when parent configuration changes
  useEffect(() => {
    setEngine(currentEngine);
  }, [currentEngine]);

  useEffect(() => {
    setQuantization(currentQuantization);
  }, [currentQuantization]);

  useEffect(() => {
    setSlaTargetMs(currentSlaMs);
  }, [currentSlaMs]);

  // Generate heatmap matrix data based on active engine & quantization
  const matrixData = useMemo(() => {
    return generateSaturationMatrix(engine, quantization, slaTargetMs);
  }, [engine, quantization, slaTargetMs]);

  // Compute model saturation knees
  const saturationKnees = useMemo(() => {
    return HEATMAP_MODELS.map(m => detectModelSaturationKnee(m, engine, quantization, slaTargetMs));
  }, [engine, quantization, slaTargetMs]);

  // Transform data for the Recharts Saturation Knee Curve (LineChart)
  // X: Concurrency, Y: Latency for each model
  const curveData = useMemo(() => {
    return HEATMAP_CONCURRENCY_LEVELS.map(c => {
      const point: Record<string, number | string> = { concurrency: `${c} streams`, rawConcurrency: c };
      for (const m of HEATMAP_MODELS) {
        const cell = matrixData.find(d => d.modelId === m && d.concurrency === c);
        if (cell) {
          point[m] = metricMode === 'avg' 
            ? cell.avgLatencyMs 
            : metricMode === 'p95' 
            ? cell.p95LatencyMs 
            : metricMode === 'rtf' 
            ? cell.rtf * 1000 
            : cell.throughputRps;
        }
      }
      return point;
    });
  }, [matrixData, metricMode]);

  // Model line colors for the Recharts curve
  const MODEL_COLORS: Record<ModelId, string> = {
    'whisper-large-v3': '#f43f5e', // Rose
    'distil-whisper-v3': '#06b6d4', // Cyan
    'whisper-medium': '#a855f7',    // Purple
    'whisper-small': '#3b82f6',     // Blue
    'whisper-base': '#10b981',      // Emerald
    'whisper-tiny': '#eab308',      // Amber
  };

  const getMetricLabel = (cell: HeatmapCellData) => {
    switch (metricMode) {
      case 'avg':
        return `${cell.avgLatencyMs}ms`;
      case 'p95':
        return `${cell.p95LatencyMs}ms`;
      case 'rtf':
        return `${cell.rtf}x`;
      case 'throughput':
        return `${cell.throughputRps} rps`;
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-5">
      {/* Header & Controls Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-base text-white">
              Model Latency vs. Concurrent Load Saturation Heatmap
            </h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800">
              GPU Saturation Analyzer
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Evaluate latency degradation across Whisper variants under concurrent load. Identify cluster saturation knees where queue contention exceeds GPU compute bandwidth.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 p-1 rounded-lg self-start lg:self-center">
          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'matrix'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Heatmap Matrix
          </button>
          <button
            onClick={() => setActiveTab('curves')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'curves'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Saturation Curves
          </button>
        </div>
      </div>

      {/* Dynamic Filters & Tuning Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/70 p-3 rounded-lg border border-slate-800/80 text-xs">
        {/* Engine */}
        <div>
          <label className="text-slate-400 font-medium block mb-1">Serving Engine</label>
          <select
            value={engine}
            onChange={(e) => setEngine(e.target.value as ServingEngine)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-cyan-500"
          >
            <option value="faster-whisper">Faster-Whisper (CTranslate2)</option>
            <option value="tensorrt-llm">TensorRT-LLM (In-Flight Batching)</option>
            <option value="pytorch-eager">PyTorch Eager (TorchScript)</option>
            <option value="onnx-runtime">ONNX Runtime EP</option>
          </select>
        </div>

        {/* Quantization */}
        <div>
          <label className="text-slate-400 font-medium block mb-1">Precision / Quantization</label>
          <select
            value={quantization}
            onChange={(e) => setQuantization(e.target.value as Quantization)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-cyan-500"
          >
            <option value="int8">INT8 (Quantized cuBLAS)</option>
            <option value="fp16">FP16 (Half Precision)</option>
            <option value="fp32">FP32 (Single Precision)</option>
            <option value="int4">INT4 (Ultra Low Footprint)</option>
          </select>
        </div>

        {/* Display Metric */}
        <div>
          <label className="text-slate-400 font-medium block mb-1">Cell Metric</label>
          <select
            value={metricMode}
            onChange={(e) => setMetricMode(e.target.value as MetricMode)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-cyan-500"
          >
            <option value="avg">Average Latency (ms)</option>
            <option value="p95">p95 Latency (ms)</option>
            <option value="rtf">Real-Time Factor (RTF)</option>
            <option value="throughput">Throughput (req/s)</option>
          </select>
        </div>

        {/* SLA Target */}
        <div>
          <label className="text-slate-400 font-medium block mb-1">SLA Latency Target</label>
          <select
            value={slaTargetMs}
            onChange={(e) => setSlaTargetMs(Number(e.target.value))}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-cyan-500"
          >
            <option value="500">&lt; 500 ms (Strict Real-time)</option>
            <option value="800">&lt; 800 ms (Standard Production)</option>
            <option value="1200">&lt; 1,200 ms (Relaxed SLA)</option>
            <option value="2000">&lt; 2,000 ms (Batch Ingestion)</option>
          </select>
        </div>
      </div>

      {/* Legend & Status Guide */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-950/40 px-3 py-2 rounded-lg border border-slate-800/60">
        <div className="flex flex-wrap items-center gap-4 text-[11px]">
          <span className="text-slate-400 font-medium">Latency Status:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
            <span className="text-slate-300">Optimal (&lt; {Math.round(slaTargetMs * 0.45)}ms)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-cyan-500" />
            <span className="text-slate-300">Balanced ({Math.round(slaTargetMs * 0.45)}-{Math.round(slaTargetMs * 0.75)}ms)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" />
            <span className="text-slate-300">Saturation Knee ({Math.round(slaTargetMs * 0.75)}-{slaTargetMs}ms)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" />
            <span className="text-rose-300 font-semibold">Saturated / SLA Breach (&gt; {slaTargetMs}ms)</span>
          </div>
        </div>

        <div className="text-[11px] text-slate-400">
          Showing 6 Whisper architectures &times; 6 concurrent load stages (36 cluster permutations)
        </div>
      </div>

      {/* Main View Area */}
      {activeTab === 'matrix' ? (
        <div className="space-y-4">
          {/* Recharts Heatmap Matrix & Interactive Grid */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs min-w-[700px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px]">
                  <th className="py-2.5 px-3 bg-slate-950/80 w-44">Whisper Model</th>
                  {HEATMAP_CONCURRENCY_LEVELS.map((c) => (
                    <th key={c} className="py-2.5 px-3 text-center bg-slate-950/80">
                      <div className="font-bold text-slate-200">{c} Streams</div>
                      <div className="text-[10px] text-slate-500 font-sans">
                        {c === 1 ? 'Sequential' : c <= 10 ? 'Low Concurrency' : c <= 20 ? 'Standard Load' : c <= 50 ? 'Peak Load' : 'Stress Load'}
                      </div>
                    </th>
                  ))}
                  <th className="py-2.5 px-3 text-center bg-slate-950/80 w-36">Saturation Point</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {HEATMAP_MODELS.map((m) => {
                  const modelSpec = MODELS_CONFIG[m];
                  const knee = saturationKnees.find(k => k.modelId === m);

                  return (
                    <tr key={m} className="hover:bg-slate-800/30 transition-colors">
                      {/* Model metadata column */}
                      <td className="py-2.5 px-3 bg-slate-950/40">
                        <div className="font-semibold text-white text-xs flex items-center gap-1.5">
                          <span 
                            className="w-2 h-2 rounded-full flex-shrink-0" 
                            style={{ backgroundColor: MODEL_COLORS[m] }}
                          />
                          {modelSpec ? modelSpec.name : m}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {modelSpec?.parameters} &bull; {modelSpec?.relativeSpeed}
                        </div>
                      </td>

                      {/* Concurrency cells */}
                      {HEATMAP_CONCURRENCY_LEVELS.map((c) => {
                        const cell = matrixData.find(d => d.modelId === m && d.concurrency === c)!;
                        const colorTokens = getLatencyColorToken(cell.status);
                        const isSelected = selectedCell?.modelId === m && selectedCell?.concurrency === c;

                        return (
                          <td 
                            key={c} 
                            className="p-1.5 text-center cursor-pointer"
                            onClick={() => setSelectedCell(cell)}
                          >
                            <div 
                              className={`rounded-lg p-2 transition-all border ${colorTokens.bg} ${colorTokens.border} ${
                                isSelected ? 'ring-2 ring-cyan-400 shadow-md shadow-cyan-500/20 scale-102' : ''
                              }`}
                              title={`${cell.modelName} @ ${c} concurrency: ${cell.avgLatencyMs}ms (p95: ${cell.p95LatencyMs}ms)`}
                            >
                              <div className={`font-mono font-bold text-xs ${colorTokens.text}`}>
                                {getMetricLabel(cell)}
                              </div>
                              <div className="text-[10px] text-slate-300 font-sans mt-0.5 flex items-center justify-center gap-1">
                                <span>{cell.throughputRps} rps</span>
                                {cell.status === 'saturated' && (
                                  <AlertTriangle className="w-2.5 h-2.5 text-rose-400 inline" />
                                )}
                              </div>
                            </div>
                          </td>
                        );
                      })}

                      {/* Saturation Knee summary column */}
                      <td className="py-2.5 px-3 text-center bg-slate-950/40">
                        {knee && (
                          <div className="space-y-0.5">
                            <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              knee.saturationConcurrency >= 100
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                : knee.saturationConcurrency >= 50
                                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                                : knee.saturationConcurrency >= 20
                                ? 'bg-amber-950 text-amber-400 border border-amber-800'
                                : 'bg-rose-950 text-rose-400 border border-rose-800'
                            }`}>
                              {knee.saturationConcurrency >= 100 ? '> 100 Streams' : `@ ${knee.saturationConcurrency} Streams`}
                            </span>
                            <div className="text-[10px] text-slate-400">
                              Peak {knee.maxThroughputRps} req/s
                            </div>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Selected Cell Deep Dive & Benchmark Applicator */}
          {selectedCell && (
            <div className="bg-slate-950 border border-cyan-800/60 rounded-xl p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: MODEL_COLORS[selectedCell.modelId] }}
                  />
                  <h4 className="font-bold text-sm text-white">
                    {selectedCell.modelName} &bull; {selectedCell.concurrency} Concurrent Streams
                  </h4>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    selectedCell.status === 'optimal'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : selectedCell.status === 'moderate'
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                      : selectedCell.status === 'warning'
                      ? 'bg-amber-950 text-amber-400 border border-amber-800'
                      : 'bg-rose-950 text-rose-400 border border-rose-800'
                  }`}>
                    {selectedCell.statusLabel}
                  </span>
                </div>

                {onApplyConfig && (
                  <button
                    onClick={() => onApplyConfig(selectedCell.modelId, selectedCell.concurrency, engine, quantization)}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <span>Load Into Benchmark Runner</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Average Latency</span>
                  <span className="text-base font-bold font-mono text-white">{selectedCell.avgLatencyMs} ms</span>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">p95 Latency</span>
                  <span className={`text-base font-bold font-mono ${
                    selectedCell.p95LatencyMs <= slaTargetMs ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {selectedCell.p95LatencyMs} ms
                  </span>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Real-Time Factor</span>
                  <span className="text-base font-bold font-mono text-purple-300">{selectedCell.rtf}x</span>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Throughput</span>
                  <span className="text-base font-bold font-mono text-emerald-400">{selectedCell.throughputRps} rps</span>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Estimated VRAM</span>
                  <span className="text-base font-bold font-mono text-amber-300">{selectedCell.gpuMemoryMb} MB</span>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">SLA Target</span>
                  <span className="text-base font-bold font-mono text-slate-300">&lt; {slaTargetMs} ms</span>
                </div>
              </div>

              {/* Bottleneck Diagnostic Explanation */}
              <div className="text-xs text-slate-300 bg-slate-900/90 p-3 rounded-lg border border-slate-800 flex items-start gap-2">
                <Info className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Saturation Analysis: </span>
                  {selectedCell.bottleneckReason}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Saturation Curves View using Recharts LineChart */
        <div className="space-y-4">
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curveData} margin={{ top: 15, right: 30, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis 
                  dataKey="concurrency" 
                  stroke="#64748b" 
                  tick={{ fill: '#94a3b8', fontSize: 11 }}
                  tickLine={{ stroke: '#334155' }}
                />
                <YAxis 
                  stroke="#64748b" 
                  tick={{ fill: '#94a3b8', fontSize: 11 }}
                  tickLine={{ stroke: '#334155' }}
                  label={{ 
                    value: metricMode === 'avg' 
                      ? 'Avg Latency (ms)' 
                      : metricMode === 'p95' 
                      ? 'p95 Latency (ms)' 
                      : metricMode === 'rtf' 
                      ? 'RTF x 1000' 
                      : 'Throughput (req/s)', 
                    angle: -90, 
                    position: 'insideLeft', 
                    fill: '#64748b', 
                    fontSize: 11 
                  }}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  labelStyle={{ color: '#f8fafc', fontWeight: 'bold' }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }} 
                />

                {/* SLA Target Reference Line */}
                {(metricMode === 'avg' || metricMode === 'p95') && (
                  <ReferenceLine 
                    y={slaTargetMs} 
                    stroke="#f43f5e" 
                    strokeDasharray="4 4" 
                    label={{ 
                      value: `SLA Threshold (${slaTargetMs}ms)`, 
                      fill: '#f43f5e', 
                      fontSize: 11, 
                      position: 'top' 
                    }} 
                  />
                )}

                {/* Model Latency Curves */}
                {HEATMAP_MODELS.map((m) => (
                  <Line
                    key={m}
                    type="monotone"
                    dataKey={m}
                    name={MODELS_CONFIG[m]?.name || m}
                    stroke={MODEL_COLORS[m]}
                    strokeWidth={2.5}
                    dot={{ r: 4, strokeWidth: 1.5, fill: '#090d16' }}
                    activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="text-xs text-slate-400 bg-slate-950/60 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>
                <strong>Inflection Point / Saturation Knee:</strong> Notice how <span className="text-rose-400 font-semibold">Whisper Large-v3</span> curves sharply upward beyond 20 concurrent streams, while <span className="text-cyan-400 font-semibold">Distil-Whisper-v3</span> maintains flat, stable latency through 50 streams.
              </span>
            </span>
          </div>
        </div>
      )}

      {/* Model Saturation Knee Cards Grid */}
      <div className="space-y-2 pt-2 border-t border-slate-800">
        <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
          <span>Cluster Sizing &amp; Saturation Knee Findings ({engine} &bull; {quantization.toUpperCase()})</span>
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
          {saturationKnees.map((knee) => (
            <div 
              key={knee.modelId}
              className="bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 rounded-lg p-3 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span 
                      className="w-2.5 h-2.5 rounded-full" 
                      style={{ backgroundColor: MODEL_COLORS[knee.modelId] }}
                    />
                    <span className="font-semibold text-white">{knee.modelName}</span>
                  </div>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                    knee.saturationConcurrency >= 100
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : knee.saturationConcurrency >= 50
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    Knee: {knee.saturationConcurrency}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {knee.insight}
                </p>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-2 mt-2 border-t border-slate-800/60">
                <span>Safe Limit: &le; {knee.recommendedMaxConcurrency} workers</span>
                <span>Max RPS: {knee.maxThroughputRps}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
