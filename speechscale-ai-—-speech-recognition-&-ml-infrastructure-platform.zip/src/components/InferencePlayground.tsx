import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Upload, 
  Mic, 
  Square, 
  CheckCircle2, 
  Clock, 
  Cpu, 
  Download, 
  Copy, 
  FileText, 
  Check, 
  AlertTriangle,
  Sliders,
  Sparkles,
  Volume2
} from 'lucide-react';
import { InferenceJob, ModelId, ServingEngine, Quantization, Priority, SegmentTranscript, WordTimestamp } from '../types';
import { MODELS_CONFIG, ENGINES_CONFIG } from '../data/modelsConfig';
import { SAMPLE_AUDIOS, SampleAudio } from '../data/sampleAudios';
import { playSyntheticSpeech, extractWaveformFromFile } from '../utils/audioPlayer';

interface InferencePlaygroundProps {
  jobs: InferenceJob[];
  submitJob: (jobConfig: Omit<InferenceJob, 'id' | 'status' | 'progressPercent' | 'createdAt' | 'retryCount'>) => void;
  activeJob: InferenceJob | null;
  setActiveJobId: (id: string) => void;
}

export const InferencePlayground: React.FC<InferencePlaygroundProps> = ({
  jobs,
  submitJob,
  activeJob,
  setActiveJobId,
}) => {
  const [selectedSample, setSelectedSample] = useState<SampleAudio>(SAMPLE_AUDIOS[0]);
  const [selectedModel, setSelectedModel] = useState<ModelId>('whisper-large-v3');
  const [selectedEngine, setSelectedEngine] = useState<ServingEngine>('faster-whisper');
  const [selectedQuant, setSelectedQuant] = useState<Quantization>('int8');
  const [priority, setPriority] = useState<Priority>('HIGH');
  const [beamSize, setBeamSize] = useState<number>(1);
  const [temperature, setTemperature] = useState<number>(0.0);
  const [vadFilter, setVadFilter] = useState<boolean>(true);
  const [diarization, setDiarization] = useState<boolean>(true);

  // Audio Playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [activeSegmentIndex, setActiveSegmentIndex] = useState<number>(0);
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  // Mic recording state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordDuration, setRecordDuration] = useState<number>(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<any>(null);

  // Synthesizer playback controller
  const playbackRef = useRef<{ stop: () => void } | null>(null);
  const playTimerRef = useRef<any>(null);

  // Active audio metadata
  const currentAudioDuration = activeJob?.audioDurationSec || selectedSample.durationSec;
  const currentWaveform = selectedSample.waveformData;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (playbackRef.current) playbackRef.current.stop();
      if (playTimerRef.current) clearInterval(playTimerRef.current);
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    };
  }, []);

  const handlePlayToggle = () => {
    if (isPlaying) {
      if (playbackRef.current) playbackRef.current.stop();
      if (playTimerRef.current) clearInterval(playTimerRef.current);
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      const textToSpeak = activeJob?.result?.text || selectedSample.referenceText;
      
      const startTime = Date.now() - (currentTimeSec * 1000);
      playTimerRef.current = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        if (elapsed >= currentAudioDuration) {
          setIsPlaying(false);
          setCurrentTimeSec(0);
          clearInterval(playTimerRef.current);
        } else {
          setCurrentTimeSec(elapsed);
        }
      }, 100);

      playbackRef.current = playSyntheticSpeech(
        textToSpeak,
        undefined,
        () => {
          setIsPlaying(false);
          setCurrentTimeSec(0);
          if (playTimerRef.current) clearInterval(playTimerRef.current);
        }
      );
    }
  };

  const handleSeek = (percentage: number) => {
    const targetSec = percentage * currentAudioDuration;
    setCurrentTimeSec(targetSec);
  };

  // Mic recording handler
  const handleToggleRecord = async () => {
    if (isRecording) {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      clearInterval(recordTimerRef.current);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorderRef.current = new MediaRecorder(stream);
        audioChunksRef.current = [];

        mediaRecorderRef.current.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunksRef.current.push(e.data);
        };

        mediaRecorderRef.current.onstop = async () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const waveform = await extractWaveformFromFile(audioBlob);
          const duration = Math.max(2, recordDuration);
          
          const customSample: SampleAudio = {
            id: `mic-${Date.now()}`,
            title: `Microphone Capture (${duration}s)`,
            category: 'User Voice Recording',
            durationSec: duration,
            acousticCondition: 'User Live Microphone (Input Stream)',
            speakerCount: 1,
            sampleRate: '48,000 Hz',
            referenceText: 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
            modelTranscripts: {
              'whisper-large-v3': 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
              'distil-whisper-v3': 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
              'whisper-medium': 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
              'whisper-small': 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
              'whisper-tiny': 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
            },
            segments: [
              {
                id: 0,
                seek: 0,
                start: 0,
                end: duration,
                text: 'Live user audio stream input captured via browser media devices API for speech recognition inference.',
                tokens: [50364, 1000, 2000, 50889],
                temperature: 0.0,
                avgLogprob: -0.15,
                compressionRatio: 1.2,
                noSpeechProb: 0.002,
                speaker: 'User',
              }
            ],
            words: [
              { word: 'Live', start: 0.2, end: 0.6, confidence: 0.98, speaker: 'User' },
              { word: 'user', start: 0.6, end: 1.0, confidence: 0.99, speaker: 'User' },
              { word: 'audio', start: 1.0, end: 1.5, confidence: 0.99, speaker: 'User' },
              { word: 'stream', start: 1.5, end: 2.1, confidence: 0.98, speaker: 'User' },
              { word: 'captured', start: 2.2, end: 2.9, confidence: 0.97, speaker: 'User' },
              { word: 'for', start: 3.0, end: 3.2, confidence: 0.99, speaker: 'User' },
              { word: 'inference.', start: 3.3, end: 4.1, confidence: 0.98, speaker: 'User' },
            ],
            waveformData: waveform,
          };

          setSelectedSample(customSample);
        };

        mediaRecorderRef.current.start(200);
        setIsRecording(true);
        setRecordDuration(0);
        recordTimerRef.current = setInterval(() => {
          setRecordDuration(prev => prev + 1);
        }, 1000);
      } catch (err) {
        alert('Microphone access was denied or not supported in this browser session. Please test using our curated acoustic sample clips!');
      }
    }
  };

  // Upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const waveform = await extractWaveformFromFile(file);
    const duration = 12.0; // estimated fallback if metadata takes time
    const uploadedSample: SampleAudio = {
      id: `file-${Date.now()}`,
      title: file.name.substring(0, 30),
      category: 'Uploaded Audio File',
      durationSec: duration,
      acousticCondition: `${file.type || 'audio/wav'} (${Math.round(file.size / 1024)} KB)`,
      speakerCount: 1,
      sampleRate: '16,000 Hz',
      referenceText: `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
      modelTranscripts: {
        'whisper-large-v3': `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
        'distil-whisper-v3': `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
        'whisper-medium': `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
        'whisper-small': `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
        'whisper-tiny': `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
      },
      segments: [
        {
          id: 0,
          seek: 0,
          start: 0,
          end: duration,
          text: `Transcribed audio file: ${file.name}. Inference processing using Whisper transformer model architecture.`,
          tokens: [50364, 102, 304, 50900],
          temperature: 0.0,
          avgLogprob: -0.12,
          compressionRatio: 1.18,
          noSpeechProb: 0.001,
          speaker: 'Speaker 1',
        }
      ],
      words: [
        { word: 'Transcribed', start: 0.2, end: 0.9, confidence: 0.99 },
        { word: 'audio', start: 1.0, end: 1.4, confidence: 0.98 },
        { word: 'file', start: 1.4, end: 1.8, confidence: 0.99 },
        { word: 'successfully.', start: 1.9, end: 2.8, confidence: 0.97 },
      ],
      waveformData: waveform,
    };
    setSelectedSample(uploadedSample);
  };

  // Submit job
  const handleDispatchJob = () => {
    submitJob({
      audioName: selectedSample.title,
      audioDurationSec: selectedSample.durationSec,
      model: selectedModel,
      engine: selectedEngine,
      quantization: selectedQuant,
      priority,
      beamSize,
      temperature,
      vadFilter,
      diarization,
      maxRetries: 3,
      timeoutMs: 12000,
    });
  };

  const handleCopy = (text: string, format: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFormat(format);
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms}`;
  };

  const activeResult = activeJob?.result;
  const segments = activeResult?.segments || selectedSample.segments;
  const words = activeResult?.words || selectedSample.words;

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Audio Source & Config Panel */}
        <div className="lg:col-span-5 space-y-5">
          {/* Audio Input Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <h3 className="font-semibold text-sm text-white">Audio Source Selection</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">{selectedSample.sampleRate}</span>
            </div>

            {/* Preset Samples Selector */}
            <div className="space-y-2 mb-4">
              <label className="text-xs text-slate-400 font-medium">Curated Acoustic Test Datasets</label>
              <div className="grid grid-cols-1 gap-2">
                {SAMPLE_AUDIOS.map((sample) => (
                  <button
                    key={sample.id}
                    onClick={() => {
                      setSelectedSample(sample);
                      if (isPlaying) {
                        playbackRef.current?.stop();
                        setIsPlaying(false);
                      }
                      setCurrentTimeSec(0);
                    }}
                    className={`flex items-start justify-between p-3 rounded-lg border text-left transition-all cursor-pointer ${
                      selectedSample.id === sample.id
                        ? 'bg-slate-800/90 border-cyan-500/80 text-white shadow-sm'
                        : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/50'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold flex items-center gap-2">
                        <span>{sample.title}</span>
                        <span className="text-slate-500 font-normal">·</span>
                        <span className="text-[11px] font-mono text-slate-400 font-normal">
                          {sample.durationSec}s
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                        {sample.acousticCondition}
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400/90 shrink-0 ml-2">
                      {sample.category}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input: File Upload or Mic */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <label className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-slate-600 text-xs text-slate-200 cursor-pointer transition-all">
                <Upload className="w-3.5 h-3.5 text-cyan-400" />
                <span>Upload Custom Audio</span>
                <input 
                  type="file" 
                  accept="audio/*" 
                  onChange={handleFileUpload}
                  className="hidden" 
                />
              </label>

              <button
                onClick={handleToggleRecord}
                className={`flex items-center gap-2 py-2 px-3 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                  isRecording 
                    ? 'bg-red-950/80 border-red-500 text-red-300 animate-pulse'
                    : 'bg-slate-800/60 border-slate-700 text-slate-200 hover:bg-slate-800'
                }`}
              >
                {isRecording ? <Square className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5 text-red-400" />}
                <span>{isRecording ? `Recording (${recordDuration}s)` : 'Record Mic'}</span>
              </button>
            </div>
          </div>

          {/* Model & Serving Parameters Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-400" />
                <h3 className="font-semibold text-sm text-white">Inference &amp; Serving Pipeline</h3>
              </div>
              <span className="text-[11px] text-emerald-400 font-mono">FastAPI Async API</span>
            </div>

            {/* Model Selection */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <label className="text-slate-300 font-medium">Whisper Model Weight</label>
                <span className="text-slate-400 font-mono">{MODELS_CONFIG[selectedModel].parameters} params</span>
              </div>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value as ModelId)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {Object.values(MODELS_CONFIG).map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} — {m.relativeSpeed} ({m.vramFp16} VRAM)
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-400 leading-tight">
                {MODELS_CONFIG[selectedModel].description}
              </p>
            </div>

            {/* Serving Engine & Quantization */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">Inference Engine</label>
                <select
                  value={selectedEngine}
                  onChange={(e) => setSelectedEngine(e.target.value as ServingEngine)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="faster-whisper">Faster-Whisper (CTranslate2)</option>
                  <option value="tensorrt-llm">TensorRT-LLM (In-Flight Batching)</option>
                  <option value="pytorch-eager">PyTorch 2.3 (SDPA / FlashAttn)</option>
                  <option value="onnx-runtime">ONNX Runtime (TensorRT EP)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">Precision Quantization</label>
                <select
                  value={selectedQuant}
                  onChange={(e) => setSelectedQuant(e.target.value as Quantization)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="int8">INT8 (Recommended, 50% VRAM)</option>
                  <option value="fp16">FP16 (Half Precision Tensor Cores)</option>
                  <option value="fp32">FP32 (Single Precision Baseline)</option>
                  <option value="int4">INT4 (AWQ Extreme Compression)</option>
                </select>
              </div>
            </div>

            {/* Queue Priority & Decoding Knobs */}
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Beam Size</span>
                  <span className="font-mono text-white">{beamSize}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={beamSize}
                  onChange={(e) => setBeamSize(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
                <span className="text-[10px] text-slate-400">1 = Greedy (Fastest)</span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Temperature</span>
                  <span className="font-mono text-white">{temperature.toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1.0"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
                <span className="text-[10px] text-slate-400">0.0 = Deterministic</span>
              </div>
            </div>

            {/* Toggles: VAD & Diarization */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={vadFilter}
                  onChange={(e) => setVadFilter(e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-0 accent-blue-500"
                />
                <span>Silero-VAD Filtering (Strip Silence)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={diarization}
                  onChange={(e) => setDiarization(e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-0 accent-blue-500"
                />
                <span>Pyannote Diarization</span>
              </label>
            </div>

            {/* Dispatch Button */}
            <button
              onClick={handleDispatchJob}
              className="w-full py-2.5 px-4 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Submit Asynchronous Inference Job</span>
            </button>
          </div>
        </div>

        {/* Right Column: Audio Waveform Player, Job Tracker, & Word-Level Transcripts */}
        <div className="lg:col-span-7 space-y-5">
          {/* Audio Waveform Player Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-sm text-white">{selectedSample.title}</h4>
                <p className="text-xs text-slate-400">{selectedSample.acousticCondition}</p>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs text-cyan-400 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
                <span>{formatTime(currentTimeSec)}</span>
                <span className="text-slate-600">/</span>
                <span>{formatTime(currentAudioDuration)}</span>
              </div>
            </div>

            {/* Waveform Visualization Bars */}
            <div 
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                handleSeek(clickX / rect.width);
              }}
              className="h-16 bg-slate-950 rounded-lg p-2 border border-slate-800/80 flex items-center gap-1 cursor-pointer relative group"
            >
              {currentWaveform.map((bar, idx) => {
                const barTime = (idx / currentWaveform.length) * currentAudioDuration;
                const isPlayed = barTime <= currentTimeSec;
                return (
                  <div
                    key={idx}
                    className="flex-1 h-full flex items-center justify-center"
                  >
                    <div
                      style={{ height: `${Math.max(15, bar * 100)}%` }}
                      className={`w-full rounded-full transition-all duration-75 ${
                        isPlayed
                          ? 'bg-gradient-to-t from-cyan-500 to-blue-400'
                          : 'bg-slate-800 group-hover:bg-slate-700'
                      }`}
                    />
                  </div>
                );
              })}

              {/* Progress Playhead Line */}
              <div
                style={{ left: `${(currentTimeSec / currentAudioDuration) * 100}%` }}
                className="absolute top-0 bottom-0 w-0.5 bg-cyan-300 shadow-[0_0_8px_rgba(34,211,238,0.8)] pointer-events-none transition-all duration-75"
              />
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePlayToggle}
                  className="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-md shadow-blue-600/30 transition-all cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
                </button>
                <button
                  onClick={() => {
                    setCurrentTimeSec(0);
                    if (isPlaying) {
                      playbackRef.current?.stop();
                      setIsPlaying(false);
                    }
                  }}
                  className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-all cursor-pointer"
                  title="Reset to 0:00"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <span className="text-xs text-slate-400">
                  {isPlaying ? 'Playing speech synthesis audio...' : 'Click to preview audio'}
                </span>
              </div>

              {activeJob && (
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">Job:</span>
                  <span className="font-mono text-cyan-400 font-semibold">{activeJob.id.substring(0, 10)}...</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    activeJob.status === 'COMPLETED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    activeJob.status === 'FAILED' ? 'bg-red-950 text-red-400 border border-red-800' :
                    'bg-blue-950 text-blue-400 border border-blue-800 animate-pulse'
                  }`}>
                    {activeJob.status}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Active Job Progress / Timeline Stepper */}
          {activeJob && (
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-semibold text-white">Inference Lifecycle State Machine</span>
                </div>
                <div className="flex items-center gap-3 text-slate-400 font-mono text-[11px]">
                  {activeJob.queueWaitMs && <span>Queue Wait: {activeJob.queueWaitMs}ms</span>}
                  {activeJob.inferenceDurationMs && <span>Compute: {activeJob.inferenceDurationMs}ms</span>}
                </div>
              </div>

              {/* Step indicator */}
              <div className="grid grid-cols-4 gap-2 text-xs">
                {[
                  { step: 'QUEUED', label: '1. Redis Queue' },
                  { step: 'ROUTING', label: '2. Worker Alloc' },
                  { step: 'PREPROCESSING', label: '3. Silero-VAD' },
                  { step: 'INFERENCING', label: '4. Transformer' },
                ].map((s, idx) => {
                  const isCurrent = activeJob.status === s.step;
                  const isPast = ['COMPLETED'].includes(activeJob.status) || 
                    (idx === 0 && ['ROUTING', 'PREPROCESSING', 'INFERENCING'].includes(activeJob.status)) ||
                    (idx === 1 && ['PREPROCESSING', 'INFERENCING'].includes(activeJob.status)) ||
                    (idx === 2 && ['INFERENCING'].includes(activeJob.status));

                  return (
                    <div 
                      key={s.step}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        isCurrent 
                          ? 'bg-blue-950/80 border-blue-500 text-blue-300 shadow-sm animate-pulse' 
                          : isPast 
                          ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-400' 
                          : 'bg-slate-950 border-slate-800/60 text-slate-400'
                      }`}
                    >
                      <div className="font-medium text-[11px]">{s.label}</div>
                      <div className="text-[10px] opacity-75 mt-0.5">
                        {isPast ? 'Done' : isCurrent ? 'Active...' : 'Pending'}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full transition-all duration-200"
                  style={{ width: `${activeJob.progressPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Interactive Word-Level Transcript Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <h3 className="font-semibold text-sm text-white">Interactive Word-Level Transcript</h3>
                <span className="text-[11px] text-slate-400">({words.length} tokens aligned)</span>
              </div>

              {/* Action Buttons: Copy / Export */}
              <div className="flex items-center gap-1.5 text-xs">
                <button
                  onClick={() => handleCopy(segments.map(s => s.text).join('\n'), 'txt')}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 cursor-pointer transition-all"
                  title="Copy plain text"
                >
                  {copiedFormat === 'txt' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                  <span>{copiedFormat === 'txt' ? 'Copied' : 'Text'}</span>
                </button>
                <button
                  onClick={() => handleCopy(JSON.stringify({ segments, words }, null, 2), 'json')}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 cursor-pointer transition-all"
                  title="Copy JSON representation"
                >
                  {copiedFormat === 'json' ? <Check className="w-3 h-3 text-emerald-400" /> : <Download className="w-3 h-3 text-slate-400" />}
                  <span>{copiedFormat === 'json' ? 'Copied JSON' : 'JSON'}</span>
                </button>
              </div>
            </div>

            {/* Segment by Segment Display */}
            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {segments.map((seg, idx) => {
                const isSegmentActive = currentTimeSec >= seg.start && currentTimeSec <= seg.end;
                return (
                  <div
                    key={seg.id}
                    onClick={() => {
                      setCurrentTimeSec(seg.start);
                      setActiveSegmentIndex(idx);
                    }}
                    className={`p-3 rounded-lg border transition-all cursor-pointer ${
                      isSegmentActive
                        ? 'bg-blue-950/40 border-cyan-500/60 shadow-sm'
                        : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                      <div className="flex items-center gap-2">
                        {seg.speaker && (
                          <span className="font-semibold text-cyan-400 px-1.5 py-0.2 rounded bg-cyan-950/80 border border-cyan-800/50">
                            {seg.speaker}
                          </span>
                        )}
                        <span className="font-mono text-slate-400">
                          [{formatTime(seg.start)} &rarr; {formatTime(seg.end)}]
                        </span>
                      </div>
                      <span className="text-slate-400">Avg logprob: {seg.avgLogprob.toFixed(2)}</span>
                    </div>

                    <p className="text-sm text-slate-200 leading-relaxed font-sans">
                      {seg.text}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Word-Level Confidence Tooltips Strip */}
            <div className="pt-3 border-t border-slate-800/80">
              <div className="text-[11px] text-slate-400 font-medium mb-2 flex items-center justify-between">
                <span>Word-Level Token Alignments (Hover for Confidence &amp; Timestamp)</span>
                <span className="text-[10px] text-emerald-400">&bull; Green &gt; 95% Confidence</span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-slate-950/80 rounded-lg border border-slate-800/60">
                {words.map((w, i) => {
                  const isHighConf = w.confidence >= 0.95;
                  const isWordCurrent = currentTimeSec >= w.start && currentTimeSec <= w.end;
                  return (
                    <span
                      key={i}
                      title={`Token: "${w.word}" | Range: ${w.start.toFixed(2)}s - ${w.end.toFixed(2)}s | Confidence: ${(w.confidence * 100).toFixed(1)}%`}
                      onClick={() => setCurrentTimeSec(w.start)}
                      className={`text-xs px-2 py-0.5 rounded cursor-pointer transition-all border ${
                        isWordCurrent
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-300 scale-105'
                          : isHighConf
                          ? 'bg-slate-900 text-slate-200 border-slate-800 hover:border-emerald-500/60 hover:text-emerald-300'
                          : 'bg-amber-950/40 text-amber-300 border-amber-800/60 hover:border-amber-500'
                      }`}
                    >
                      {w.word}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Inference Jobs History Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-400" />
            <h3 className="font-semibold text-sm text-white">Recent Asynchronous Inference Jobs</h3>
          </div>
          <span className="text-xs text-slate-400">{jobs.length} jobs in session</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Job ID</th>
                <th className="py-2.5 px-3">Audio Payload</th>
                <th className="py-2.5 px-3">Model &amp; Engine</th>
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Latency</th>
                <th className="py-2.5 px-3">RTF</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {jobs.map((job) => (
                <tr 
                  key={job.id} 
                  className={`hover:bg-slate-800/40 transition-colors ${
                    activeJob?.id === job.id ? 'bg-blue-950/30' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-mono text-cyan-400">
                    {job.id.substring(0, 8)}...
                  </td>
                  <td className="py-2.5 px-3 font-medium text-white">
                    {job.audioName} ({job.audioDurationSec}s)
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-slate-200">{job.model}</span>
                    <span className="text-slate-400 text-[10px] block">{job.engine} &bull; {job.quantization}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                      job.priority === 'CRITICAL' ? 'bg-red-950 text-red-300 border border-red-800' :
                      job.priority === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {job.priority}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      job.status === 'COMPLETED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      job.status === 'FAILED' ? 'bg-red-950 text-red-400 border border-red-800' :
                      'bg-blue-950 text-blue-400 border border-blue-800 animate-pulse'
                    }`}>
                      {job.status === 'COMPLETED' && <CheckCircle2 className="w-3 h-3" />}
                      {job.status === 'FAILED' && <AlertTriangle className="w-3 h-3" />}
                      <span>{job.status}</span>
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    {job.inferenceDurationMs ? `${job.inferenceDurationMs}ms` : '—'}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-cyan-400">
                    {job.result?.rtf ? `${job.result.rtf}x` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => setActiveJobId(job.id)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs cursor-pointer font-medium"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
