import React, { useState } from 'react';
import { 
  Server, 
  Layers, 
  Cpu, 
  AlertCircle, 
  RefreshCw, 
  Plus, 
  Minus, 
  Flame, 
  Terminal, 
  Search, 
  RotateCcw,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Zap,
  Sliders,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Play,
  Activity,
  Gauge
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Line, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceLine 
} from 'recharts';
import { 
  WorkerInstance, 
  StructuredLog, 
  Priority, 
  InferenceJob, 
  AutoscalingConfig, 
  AutoscalerState,
  AutoscalingMetric,
  QueueHistoryPoint
} from '../types';
import { computeWorkerAvgLatency, getWorkerLatencyHealth } from '../utils/workerHealth';

interface WorkerOrchestratorProps {
  workers: WorkerInstance[];
  queuedJobs: InferenceJob[];
  dlqJobs: InferenceJob[];
  logs: StructuredLog[];
  queueHistory: QueueHistoryPoint[];
  autoscalingConfig: AutoscalingConfig;
  autoscalerState: AutoscalerState;
  onUpdateAutoscalingConfig: (config: Partial<AutoscalingConfig>) => void;
  onTriggerSpike: () => void;
  onScaleWorker: (delta: number) => void;
  onSimulateOom: (workerId: string) => void;
  onSimulateTimeout: (workerId: string) => void;
  onToggleThrottle?: (workerId: string) => void;
  onRedriveDlq: () => void;
  onClearLogs: () => void;
}

export const WorkerOrchestrator: React.FC<WorkerOrchestratorProps> = ({
  workers,
  queuedJobs,
  dlqJobs,
  logs,
  queueHistory,
  autoscalingConfig,
  autoscalerState,
  onUpdateAutoscalingConfig,
  onTriggerSpike,
  onScaleWorker,
  onSimulateOom,
  onSimulateTimeout,
  onToggleThrottle,
  onRedriveDlq,
  onClearLogs,
}) => {
  const [logFilter, setLogFilter] = useState<'ALL' | 'INFO' | 'WARN' | 'ERROR'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showConfigDetails, setShowConfigDetails] = useState<boolean>(true);

  // Group queued jobs by priority
  const criticalQueue = queuedJobs.filter(j => j.priority === 'CRITICAL');
  const highQueue = queuedJobs.filter(j => j.priority === 'HIGH');
  const defaultQueue = queuedJobs.filter(j => j.priority === 'DEFAULT');
  const batchQueue = queuedJobs.filter(j => j.priority === 'BATCH');

  // Filter logs
  const filteredLogs = logs.filter(log => {
    if (logFilter !== 'ALL' && log.level !== logFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        log.message.toLowerCase().includes(q) ||
        (log.job_id && log.job_id.toLowerCase().includes(q)) ||
        (log.worker_id && log.worker_id.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // Calculate sustained progress percent for UI
  const targetDuration = autoscalerState.currentStage === 'EVALUATING_SCALE_DOWN'
    ? autoscalingConfig.scaleDownDurationSec
    : autoscalingConfig.scaleUpDurationSec;
  const sustainedPercent = Math.min(100, Math.round((autoscalerState.secondsSustained / Math.max(1, targetDuration)) * 100));

  return (
    <div className="space-y-6">
      {/* Top Overview Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Active Worker Pool</span>
            <Server className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono flex items-baseline justify-between">
            <span>
              {workers.filter(w => w.status === 'BUSY' || w.status === 'IDLE').length} / {workers.length}
            </span>
            <span className="text-xs font-normal text-slate-400">
              [Min: {autoscalingConfig.minWorkers} / Max: {autoscalingConfig.maxWorkers}]
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">NVIDIA A100 / T4 &bull; PyTorch Workers</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Redis Stream Queue Depth</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-400 font-mono">
            {queuedJobs.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Threshold: &gt; {autoscalingConfig.scaleUpThreshold} ({autoscalingConfig.metric})
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Dead Letter Queue (DLQ)</span>
            <ShieldAlert className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-2xl font-bold text-red-400 font-mono">
            {dlqJobs.length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Jobs exceeding max 3 retries</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Auto-Scaler (HPA) Status</span>
            <Zap className={`w-4 h-4 ${autoscalingConfig.enabled ? 'text-amber-400' : 'text-slate-600'}`} />
          </div>
          <div className="text-base font-bold font-mono text-white mt-1 flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${
              !autoscalingConfig.enabled ? 'bg-slate-500' :
              autoscalerState.currentStage === 'EVALUATING_SCALE_UP' ? 'bg-amber-400 animate-ping' :
              autoscalerState.currentStage === 'COOLDOWN' ? 'bg-blue-400' :
              'bg-emerald-400'
            }`} />
            <span className="truncate">{autoscalingConfig.enabled ? autoscalerState.currentStage : 'DISABLED'}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 truncate">
            {autoscalerState.lastActionReason}
          </p>
        </div>
      </div>

      {/* Auto-Scaling Rules Configuration & Simulation Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center">
              <Sliders className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">
                  Horizontal Pod Autoscaler (HPA) &amp; Dynamic Scaling Rules
                </h3>
                <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded font-bold border ${
                  autoscalingConfig.enabled 
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-800' 
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  {autoscalingConfig.enabled ? 'Auto-Scaling Active' : 'Auto-Scaling Disabled'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Define rules to evaluate queue depth and GPU compute thresholds sustained over time
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Enable */}
            <label className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-xs cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoscalingConfig.enabled}
                onChange={(e) => onUpdateAutoscalingConfig({ enabled: e.target.checked })}
                className="rounded border-slate-700 text-blue-600 focus:ring-0 accent-blue-500 cursor-pointer"
              />
              <span className="text-slate-200 font-medium">Enable Auto-Scaling</span>
            </label>

            {/* Ingestion Spike Button */}
            <button
              onClick={onTriggerSpike}
              className="py-1.5 px-3 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-orange-600/20 transition-all cursor-pointer"
              title="Add 25 burst jobs into the Redis Stream queue to trigger auto-scaling"
            >
              <Zap className="w-3.5 h-3.5 fill-white" />
              <span>Simulate Queue Spike (+25 Jobs)</span>
            </button>
          </div>
        </div>

        {/* Live Autoscaler Evaluation Progress Banner */}
        {autoscalingConfig.enabled && (
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 space-y-2">
            <div className="flex flex-wrap items-center justify-between text-xs gap-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-300">Live Evaluation:</span>
                <span className="font-mono text-cyan-400">
                  {autoscalerState.lastActionReason}
                </span>
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
                <span>Current Queue: <strong className="text-white">{queuedJobs.length}</strong></span>
                <span>&bull;</span>
                <span>Threshold: <strong className="text-white">{autoscalingConfig.scaleUpThreshold}</strong></span>
                {autoscalerState.secondsSustained > 0 && (
                  <>
                    <span>&bull;</span>
                    <span className="text-amber-400 font-bold">
                      Sustained: {autoscalerState.secondsSustained}s / {targetDuration}s
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Evaluation Duration Progress Bar */}
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
              <div
                style={{ width: `${sustainedPercent}%` }}
                className={`h-full transition-all duration-300 ${
                  autoscalerState.currentStage === 'EVALUATING_SCALE_UP'
                    ? 'bg-amber-400'
                    : autoscalerState.currentStage === 'EVALUATING_SCALE_DOWN'
                    ? 'bg-blue-400'
                    : 'bg-emerald-500'
                }`}
              />
            </div>
          </div>
        )}

        {/* Rule Presets */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-slate-400 text-[11px] shrink-0 font-medium">Quick Presets:</span>
          {[
            {
              name: 'Fast Auto-Scale (Queue > 5 for 5s)',
              cfg: { scaleUpThreshold: 5, scaleUpDurationSec: 5, scaleUpStep: 1, scaleUpCooldownSec: 10, scaleDownThreshold: 1, scaleDownDurationSec: 8 }
            },
            {
              name: 'Production Balanced (Queue > 15 for 15s)',
              cfg: { scaleUpThreshold: 15, scaleUpDurationSec: 15, scaleUpStep: 1, scaleUpCooldownSec: 15, scaleDownThreshold: 2, scaleDownDurationSec: 15 }
            },
            {
              name: 'High-Throughput Spike Guard (Queue > 50 for 30s)',
              cfg: { scaleUpThreshold: 50, scaleUpDurationSec: 30, scaleUpStep: 2, scaleUpCooldownSec: 30, scaleDownThreshold: 5, scaleDownDurationSec: 20 }
            },
          ].map((preset, idx) => (
            <button
              key={idx}
              onClick={() => onUpdateAutoscalingConfig(preset.cfg)}
              className="px-2.5 py-1 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer whitespace-nowrap text-[11px]"
            >
              {preset.name}
            </button>
          ))}
        </div>

        {/* Detailed Configuration Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs pt-2">
          {/* Scale Up Trigger */}
          <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between font-semibold text-emerald-400 border-b border-slate-800 pb-1.5">
              <span className="flex items-center gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>Scale-Up Rule</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">Trigger</span>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">Evaluation Metric</label>
              <select
                value={autoscalingConfig.metric}
                onChange={(e) => onUpdateAutoscalingConfig({ metric: e.target.value as AutoscalingMetric })}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200"
              >
                <option value="QUEUE_DEPTH">Redis Queue Depth (Pending Jobs)</option>
                <option value="GPU_LOAD_PERCENT">Cluster GPU Compute Load (%)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Threshold (&gt;=)</label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={autoscalingConfig.scaleUpThreshold}
                  onChange={(e) => onUpdateAutoscalingConfig({ scaleUpThreshold: Math.max(1, Number(e.target.value)) })}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Sustained Window</label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="1"
                    max="300"
                    value={autoscalingConfig.scaleUpDurationSec}
                    onChange={(e) => onUpdateAutoscalingConfig({ scaleUpDurationSec: Math.max(1, Number(e.target.value)) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                  />
                  <span className="text-slate-400 text-[10px]">sec</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Scale Step (+)</label>
                <select
                  value={autoscalingConfig.scaleUpStep}
                  onChange={(e) => onUpdateAutoscalingConfig({ scaleUpStep: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200"
                >
                  <option value="1">+1 Worker</option>
                  <option value="2">+2 Workers</option>
                  <option value="3">+3 Workers</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Cooldown</label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="5"
                    max="300"
                    value={autoscalingConfig.scaleUpCooldownSec}
                    onChange={(e) => onUpdateAutoscalingConfig({ scaleUpCooldownSec: Math.max(5, Number(e.target.value)) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                  />
                  <span className="text-slate-400 text-[10px]">sec</span>
                </div>
              </div>
            </div>
          </div>

          {/* Scale Down Trigger */}
          <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between font-semibold text-blue-400 border-b border-slate-800 pb-1.5">
              <span className="flex items-center gap-1">
                <ArrowDownRight className="w-4 h-4" />
                <span>Scale-Down Rule</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">Drain</span>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">Idle Condition</label>
              <div className="text-[11px] text-slate-300 font-mono bg-slate-900 p-1.5 rounded border border-slate-800">
                {autoscalingConfig.metric} &lt;= {autoscalingConfig.scaleDownThreshold}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Threshold (&lt;=)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={autoscalingConfig.scaleDownThreshold}
                  onChange={(e) => onUpdateAutoscalingConfig({ scaleDownThreshold: Math.max(0, Number(e.target.value)) })}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Idle Window</label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="1"
                    max="300"
                    value={autoscalingConfig.scaleDownDurationSec}
                    onChange={(e) => onUpdateAutoscalingConfig({ scaleDownDurationSec: Math.max(1, Number(e.target.value)) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                  />
                  <span className="text-slate-400 text-[10px]">sec</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Drain Step (-)</label>
                <select
                  value={autoscalingConfig.scaleDownStep}
                  onChange={(e) => onUpdateAutoscalingConfig({ scaleDownStep: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200"
                >
                  <option value="1">-1 Worker</option>
                  <option value="2">-2 Workers</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px]">Cooldown</label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="5"
                    max="300"
                    value={autoscalingConfig.scaleDownCooldownSec}
                    onChange={(e) => onUpdateAutoscalingConfig({ scaleDownCooldownSec: Math.max(5, Number(e.target.value)) })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono"
                  />
                  <span className="text-slate-400 text-[10px]">sec</span>
                </div>
              </div>
            </div>
          </div>

          {/* Cluster Capacity Bounds */}
          <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between font-semibold text-purple-400 border-b border-slate-800 pb-1.5">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Cluster Bounds</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">Limits</span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Min Worker Instances</span>
                <span className="text-white font-mono">{autoscalingConfig.minWorkers}</span>
              </div>
              <input
                type="range"
                min="1"
                max="4"
                value={autoscalingConfig.minWorkers}
                onChange={(e) => onUpdateAutoscalingConfig({ minWorkers: Number(e.target.value) })}
                className="w-full accent-purple-500"
              />
              <span className="text-[10px] text-slate-400">Always maintained baseline</span>
            </div>

            <div className="space-y-1 pt-1 border-t border-slate-800/80">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Max Worker Instances</span>
                <span className="text-white font-mono">{autoscalingConfig.maxWorkers}</span>
              </div>
              <input
                type="range"
                min="4"
                max="12"
                value={autoscalingConfig.maxWorkers}
                onChange={(e) => onUpdateAutoscalingConfig({ maxWorkers: Number(e.target.value) })}
                className="w-full accent-purple-500"
              />
              <span className="text-[10px] text-slate-400">Cloud quota &amp; GPU ceiling</span>
            </div>
          </div>

          {/* Kubernetes HPA Manifest Preview */}
          <div className="p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 space-y-2 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between font-semibold text-cyan-400 border-b border-slate-800 pb-1.5">
                <span>Kubernetes HPA Spec</span>
                <span className="text-[10px] font-mono text-slate-400">YAML</span>
              </div>
              <pre className="text-[10px] font-mono text-slate-300 mt-2 bg-slate-900 p-2 rounded leading-tight select-text overflow-x-auto">
{`apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: speechscale-worker-hpa
spec:
  minReplicas: ${autoscalingConfig.minWorkers}
  maxReplicas: ${autoscalingConfig.maxWorkers}
  metrics:
  - type: External
    external:
      metric:
        name: speechscale_redis_queue_depth
      target:
        type: AverageValue
        averageValue: "${autoscalingConfig.scaleUpThreshold}"`}
              </pre>
            </div>
            <div className="text-[10px] text-slate-400">
              Synced with Prometheus custom metrics API adapter
            </div>
          </div>
        </div>
      </div>

      {/* Real-Time Queue Depth vs. Time Chart (Recharts) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-600/20 border border-cyan-500/40 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">
                  Real-Time Queue Depth vs. Time (Traffic Spikes &amp; Autoscaling)
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono">
                  Live recharts
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Visualizing Redis Stream queue depth, traffic spikes, scale-up thresholds, and worker fleet capacity reactions over time
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-950 border border-slate-800">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
              <span className="text-slate-400">Queue Depth:</span>
              <span className="font-bold text-cyan-300">{queuedJobs.length} jobs</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-950 border border-slate-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
              <span className="text-slate-400">Active Workers:</span>
              <span className="font-bold text-emerald-300">{workers.length} nodes</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-950 border border-amber-900/60 text-amber-300">
              <span className="w-2 h-0.5 border-t-2 border-dashed border-amber-400"></span>
              <span>Scale-Up Threshold: &gt; {autoscalingConfig.scaleUpThreshold}</span>
            </div>
          </div>
        </div>

        {/* Recharts Chart Container */}
        <div className="h-64 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={queueHistory} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="queueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="time" 
                stroke="#64748b" 
                tick={{ fontSize: 10, fill: '#94a3b8' }} 
                tickLine={{ stroke: '#334155' }}
              />
              <YAxis 
                yAxisId="queue" 
                stroke="#06b6d4" 
                tick={{ fontSize: 10, fill: '#38bdf8' }}
                tickLine={{ stroke: '#0369a1' }}
                domain={[0, 'auto']}
              />
              <YAxis 
                yAxisId="workers" 
                orientation="right" 
                stroke="#10b981" 
                tick={{ fontSize: 10, fill: '#34d399' }}
                tickLine={{ stroke: '#059669' }}
                domain={[0, autoscalingConfig.maxWorkers + 2]}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#020617', 
                  borderColor: '#334155', 
                  borderRadius: '8px', 
                  fontSize: '11px',
                  fontFamily: 'monospace',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)'
                }}
                labelStyle={{ color: '#94a3b8', marginBottom: '4px' }}
              />
              <Legend 
                wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} 
              />
              <ReferenceLine 
                y={autoscalingConfig.scaleUpThreshold} 
                yAxisId="queue" 
                stroke="#f59e0b" 
                strokeDasharray="4 4" 
                strokeWidth={1.5}
                label={{ 
                  value: `Scale-Up Trigger (>${autoscalingConfig.scaleUpThreshold})`, 
                  fill: '#fbbf24', 
                  fontSize: 10, 
                  position: 'insideTopLeft' 
                }} 
              />
              <ReferenceLine 
                y={autoscalingConfig.scaleDownThreshold} 
                yAxisId="queue" 
                stroke="#3b82f6" 
                strokeDasharray="2 2" 
                strokeWidth={1}
                label={{ 
                  value: `Scale-Down Drain (<=${autoscalingConfig.scaleDownThreshold})`, 
                  fill: '#60a5fa', 
                  fontSize: 10, 
                  position: 'insideBottomLeft' 
                }} 
              />
              <Area 
                yAxisId="queue" 
                type="monotone" 
                dataKey="queueDepth" 
                name="Redis Queue Depth (Jobs)" 
                stroke="#06b6d4" 
                strokeWidth={2.5} 
                fillOpacity={1} 
                fill="url(#queueGradient)" 
                isAnimationActive={false}
              />
              <Line 
                yAxisId="workers" 
                type="stepAfter" 
                dataKey="activeWorkers" 
                name="Active Workers (Instances)" 
                stroke="#10b981" 
                strokeWidth={2} 
                dot={{ r: 2, fill: '#10b981' }} 
                activeDot={{ r: 5 }} 
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Main Grid: Redis Streams and Worker Instances */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Redis Priority Streams & DLQ */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-400" />
                <h3 className="font-semibold text-sm text-white">Redis Streams Ingestion Queues</h3>
              </div>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                Priority Weighted FIFO
              </span>
            </div>

            {/* Queues List */}
            <div className="space-y-3">
              {[
                { name: 'stream:audio_tasks:critical', label: 'Critical Tier (SLA < 400ms)', count: criticalQueue.length, color: 'border-red-500/50 bg-red-950/20 text-red-300', tag: 'Weight 100' },
                { name: 'stream:audio_tasks:high', label: 'High Priority (Customer Streaming)', count: highQueue.length, color: 'border-amber-500/50 bg-amber-950/20 text-amber-300', tag: 'Weight 75' },
                { name: 'stream:audio_tasks:default', label: 'Default Ingest (Standard Async)', count: defaultQueue.length, color: 'border-blue-500/50 bg-blue-950/20 text-blue-300', tag: 'Weight 50' },
                { name: 'stream:audio_tasks:batch', label: 'Bulk Batch (Nightly / Archival)', count: batchQueue.length, color: 'border-slate-700 bg-slate-950/60 text-slate-300', tag: 'Weight 25' },
              ].map((q) => (
                <div key={q.name} className={`p-3 rounded-lg border ${q.color} transition-all`}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-semibold">{q.label}</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-900 font-bold">
                      {q.count} jobs
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span className="truncate">{q.name}</span>
                    <span>{q.tag}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* DLQ Box */}
            <div className="mt-4 p-3 rounded-lg border border-red-900/60 bg-red-950/20">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-red-400">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Dead Letter Queue (dlq:failed_jobs)</span>
                </div>
                <span className="text-xs font-mono font-bold text-red-300">{dlqJobs.length}</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-2.5">
                Poison pill audio inputs or 3x consecutive timeout failures isolated for forensic debugging.
              </p>
              <button
                onClick={onRedriveDlq}
                disabled={dlqJobs.length === 0}
                className="w-full py-1.5 px-3 rounded bg-red-900/50 hover:bg-red-800/60 disabled:opacity-40 disabled:pointer-events-none text-red-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-red-700/60"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Re-drive All DLQ Items to Queue</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Active Worker Pool Grid & Fault Injection */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <h3 className="font-semibold text-sm text-white">Worker Orchestrator &amp; GPU Fleet</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onScaleWorker(-1)}
                  disabled={workers.length <= autoscalingConfig.minWorkers}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 text-xs cursor-pointer"
                  title="Manual scale down"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="text-xs font-mono text-slate-300">{workers.length} nodes</span>
                <button
                  onClick={() => onScaleWorker(1)}
                  disabled={workers.length >= autoscalingConfig.maxWorkers}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 text-xs cursor-pointer"
                  title="Manual scale up"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Workers Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {workers.map((worker) => {
                const isBusy = worker.status === 'BUSY';
                const isOom = worker.status === 'OOM_RECOVERY';
                const vramPercent = Math.round((worker.vramUsedMb / worker.vramTotalMb) * 100);
                const recentLatencies = worker.recentLatenciesMs && worker.recentLatenciesMs.length > 0
                  ? worker.recentLatenciesMs
                  : [240, 250, 245, 260, 255, 270, 265, 250, 245, 250];
                const avgLatency = computeWorkerAvgLatency(recentLatencies);
                const healthStatus = getWorkerLatencyHealth(avgLatency, 800);

                // Compute gauge position (0 - 1000ms mapped to 0% - 100%)
                const gaugeMarkerPercent = Math.min(100, Math.max(3, Math.round((avgLatency / 1000) * 100)));

                return (
                  <div 
                    key={worker.id}
                    className={`p-3.5 rounded-lg border transition-all ${
                      isOom ? 'border-red-600/70 bg-red-950/30' :
                      worker.isThrottled ? 'border-amber-500/80 bg-amber-950/20 shadow-sm' :
                      isBusy ? 'border-blue-500/60 bg-blue-950/20 shadow-sm' :
                      'border-slate-800 bg-slate-950/60'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${
                          isOom ? 'bg-red-500 animate-ping' :
                          worker.isThrottled ? 'bg-amber-400 animate-pulse' :
                          isBusy ? 'bg-blue-400 animate-pulse' :
                          'bg-emerald-400'
                        }`} />
                        <span className="font-semibold text-white">{worker.name}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {worker.isThrottled && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-800 animate-pulse">
                            THROTTLED
                          </span>
                        )}
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          isOom ? 'bg-red-950 text-red-300 border border-red-800' :
                          isBusy ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          'bg-slate-800 text-slate-300'
                        }`}>
                          {worker.status}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-400 font-mono mb-2 flex items-center justify-between">
                      <span>{worker.device}</span>
                      <span className="text-cyan-400">{worker.loadedModel || 'whisper-large-v3'}</span>
                    </div>

                    {/* VRAM Progress */}
                    <div className="space-y-1 mb-2.5">
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                        <span>VRAM Usage: {vramPercent}%</span>
                        <span>{worker.vramUsedMb} / {worker.vramTotalMb} MB</span>
                      </div>
                      <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                        <div
                          style={{ width: `${vramPercent}%` }}
                          className={`h-full rounded-full transition-all duration-300 ${
                            vramPercent > 85 ? 'bg-red-500' :
                            vramPercent > 60 ? 'bg-amber-400' : 'bg-blue-500'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Latency Sparkline & Performance Degradation Gauge */}
                    <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-2.5 mb-2.5 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5">
                          <Activity className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="text-[11px] font-semibold text-slate-300">Avg Latency (Last 10 Jobs):</span>
                          <span className={`text-xs font-mono font-bold ${
                            healthStatus === 'CRITICAL' ? 'text-red-400' :
                            healthStatus === 'DEGRADED' ? 'text-amber-400' :
                            'text-emerald-400'
                          }`}>
                            {avgLatency}ms
                          </span>
                        </div>
                        <span className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.5 rounded border ${
                          healthStatus === 'CRITICAL' ? 'bg-red-950/90 text-red-300 border-red-700' :
                          healthStatus === 'DEGRADED' ? 'bg-amber-950/90 text-amber-300 border-amber-700' :
                          'bg-emerald-950/90 text-emerald-300 border-emerald-700'
                        }`}>
                          {healthStatus}
                        </span>
                      </div>

                      {/* 10-bar Sparkline Histogram */}
                      <div className="relative">
                        {/* SLA Ceiling Reference Line at 80% (800ms) */}
                        <div 
                          className="absolute left-0 right-0 border-b border-dashed border-red-500/50 pointer-events-none z-10" 
                          style={{ bottom: '80%' }}
                          title="800ms SLA Target Line"
                        />

                        <div className="h-7 w-full flex items-end gap-1 px-1 bg-slate-900/60 rounded border border-slate-800/60 overflow-hidden">
                          {recentLatencies.slice(-10).map((latency, idx) => {
                            const barHeightPct = Math.min(100, Math.max(12, Math.round((latency / 1000) * 100)));
                            const barColor = latency > 800 ? 'bg-red-500 hover:bg-red-400' :
                                             latency > 480 ? 'bg-amber-500 hover:bg-amber-400' :
                                             'bg-emerald-500 hover:bg-emerald-400';
                            return (
                              <div
                                key={idx}
                                className="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer"
                              >
                                <div
                                  style={{ height: `${barHeightPct}%` }}
                                  className={`w-full rounded-t-sm transition-all duration-300 ${barColor}`}
                                />
                                {/* Bar Hover Tooltip */}
                                <div className="absolute bottom-full mb-1 hidden group-hover:flex flex-col items-center z-30 pointer-events-none">
                                  <div className="bg-slate-900 text-white text-[10px] font-mono px-2 py-0.5 rounded shadow-lg border border-slate-700 whitespace-nowrap">
                                    Job #{idx + 1}: {latency}ms
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Sparkline & Gauge Footer: Range indicators */}
                      <div className="space-y-1">
                        {/* Compact Latency Gauge Meter Bar (Healthy / Degraded / Critical zones) */}
                        <div className="relative w-full h-1.5 rounded-full overflow-hidden flex bg-slate-900">
                          <div className="w-[48%] h-full bg-emerald-500/60" title="Healthy (< 480ms)" />
                          <div className="w-[32%] h-full bg-amber-500/60" title="Degraded (480-800ms)" />
                          <div className="w-[20%] h-full bg-red-500/60" title="Critical (> 800ms)" />
                          {/* Marker Needle */}
                          <div 
                            style={{ left: `${gaugeMarkerPercent}%` }} 
                            className="absolute top-0 bottom-0 w-1 bg-white shadow-sm ring-1 ring-black -ml-0.5"
                            title={`Current Avg: ${avgLatency}ms`}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono">
                          <span className="flex items-center gap-1 text-slate-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                            &lt;480ms Normal
                          </span>
                          <span className="flex items-center gap-1 text-amber-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block"></span>
                            480-800ms
                          </span>
                          <span className="flex items-center gap-1 text-red-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-400 inline-block"></span>
                            &gt;800ms SLA Alert
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Actions: Fault Injection & Throttle Simulation */}
                    <div className="flex items-center gap-1.5 pt-2 border-t border-slate-800/60 text-[11px]">
                      <button
                        onClick={() => onSimulateOom(worker.id)}
                        disabled={isOom}
                        className="flex-1 py-1 px-1.5 rounded bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-800/40 text-[10px] font-medium flex items-center justify-center gap-1 cursor-pointer transition-all disabled:opacity-40"
                        title="Inject CUDA OOM error to test circuit breaker and job retry"
                      >
                        <Flame className="w-3 h-3 text-red-400" />
                        <span>OOM Fault</span>
                      </button>
                      <button
                        onClick={() => onSimulateTimeout(worker.id)}
                        disabled={isOom || !isBusy}
                        className="flex-1 py-1 px-1.5 rounded bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border border-amber-800/40 text-[10px] font-medium flex items-center justify-center gap-1 cursor-pointer transition-all disabled:opacity-40"
                        title="Simulate 10s request timeout"
                      >
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Timeout</span>
                      </button>
                      {onToggleThrottle && (
                        <button
                          onClick={() => onToggleThrottle(worker.id)}
                          className={`flex-1 py-1 px-1.5 rounded text-[10px] font-medium flex items-center justify-center gap-1 cursor-pointer transition-all border ${
                            worker.isThrottled
                              ? 'bg-amber-950 text-amber-200 border-amber-600'
                              : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700/80 hover:text-white'
                          }`}
                          title={worker.isThrottled ? "Clear simulated thermal throttling" : "Simulate GPU thermal throttling (+450ms penalty)"}
                        >
                          <Gauge className="w-3 h-3 text-amber-400" />
                          <span>{worker.isThrottled ? 'Clear Throttle' : 'Throttle'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Structured Error & Inference JSON Logs Terminal */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        {/* Terminal Header */}
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <h4 className="font-semibold text-white font-mono">Structured Telemetry &amp; Worker Logs</h4>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
              RFC-5424 JSON
            </span>
          </div>

          {/* Log Controls */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2" />
              <input
                type="text"
                placeholder="Search trace_id, job, worker..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded pl-7 pr-2 py-1 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 w-48"
              />
            </div>

            {/* Level Filter */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded p-0.5">
              {(['ALL', 'INFO', 'WARN', 'ERROR'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setLogFilter(level)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-all ${
                    logFilter === level
                      ? 'bg-blue-600 text-white font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>

            <button
              onClick={onClearLogs}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Logs Output Body */}
        <div className="p-3 font-mono text-xs max-h-64 overflow-y-auto space-y-1.5 bg-slate-950 select-text">
          {filteredLogs.length === 0 ? (
            <div className="text-slate-400 py-6 text-center">No logs matching filter criteria</div>
          ) : (
            filteredLogs.map((log) => {
              const isError = log.level === 'ERROR';
              const isWarn = log.level === 'WARN';
              return (
                <div 
                  key={log.id} 
                  className={`flex items-start gap-2 py-0.5 px-2 rounded hover:bg-slate-900/50 ${
                    isError ? 'text-red-400 bg-red-950/20' :
                    isWarn ? 'text-amber-300 bg-amber-950/20' :
                    'text-slate-300'
                  }`}
                >
                  <span className="text-slate-400 text-[10px] shrink-0">{log.timestamp}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold shrink-0 ${
                    isError ? 'bg-red-900/80 text-red-200' :
                    isWarn ? 'bg-amber-900/80 text-amber-200' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {log.level}
                  </span>
                  <span className="text-cyan-400 shrink-0">[{log.service}]</span>
                  {log.worker_id && <span className="text-slate-400 shrink-0">{log.worker_id}:</span>}
                  <span className="flex-1">{log.message}</span>
                  {log.metadata && (
                    <span className="text-slate-400 text-[10px] shrink-0">
                      {JSON.stringify(log.metadata)}
                    </span>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
